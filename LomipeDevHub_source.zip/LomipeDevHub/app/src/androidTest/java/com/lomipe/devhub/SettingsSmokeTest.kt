package com.lomipe.devhub

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.assertIsDisplayed
import com.lomipe.devhub.ui.MainActivity
import org.junit.Rule
import org.junit.Test

/** Needs an emulator/device: `./gradlew connectedDebugAndroidTest`. Not run in CI by default. */
class SettingsSmokeTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun settingsShowsTokenFormWhenSignedOut() {
        rule.onNodeWithText("Settings").performClick()
        rule.onNodeWithText("Validate and save").assertIsDisplayed()
    }
}
