package com.lomipe.devhub.core

import org.junit.Assert.*
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

fun zipOf(entries: List<Pair<String, ByteArray>>): ByteArray {
    val bo = ByteArrayOutputStream()
    ZipOutputStream(bo).use { z -> for ((n, b) in entries) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
    return bo.toByteArray()
}

fun art(id: Long = 7, size: Long = 0, digest: String? = null, expired: Boolean = false) =
    Artifact(id, "apk", size, expired, null, null, digest, 1, "sha")

class DownloadTest {
    private fun sha(b: ByteArray) = java.security.MessageDigest.getInstance("SHA-256").digest(b).hex()

    @Test fun redirectDropsAuthorizationOnOtherHost() = run0 {
        MockServer().use { s ->
            val zip = zipOf(listOf("a.apk" to "APK".toByteArray()))
            s.on("GET", "/repos/o/r/actions/artifacts/7/zip") { Rsp(302, ByteArray(0), mapOf("Location" to "http://127.0.0.2:${s.port}/blob/x?sig=SECRET")) }
            s.on("GET", "/blob/x") { Rsp(200, zip) }
            val dest = File(tempDir(), "a.zip")
            s.api("api-token-value").downloadArtifactZip("o/r", art(size = zip.size.toLong(), digest = "sha256:" + sha(zip)), dest)
            assertArrayEquals(zip, dest.readBytes())
            val first = s.requests.first { it.path.endsWith("/zip") }; val second = s.requests.first { it.path == "/blob/x" }
            assertEquals("Bearer api-token-value", first.headers["authorization"])
            assertNull(second.headers["authorization"]); assertEquals("127.0.0.2", second.host)
            assertFalse(File(dest.path + ".part").exists())
        }
    }

    @Test fun partialDownloadFailsAndLeavesNoFile() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/actions/artifacts/7/zip") { Rsp(200, ByteArray(100), declaredLength = 1000) }
            val dest = File(tempDir(), "p.zip")
            expectThrowsSuspend<IOException> { s.api().downloadArtifactZip("o/r", art(size = 1000), dest, attempts = 1) }
            assertFalse(dest.exists()); assertFalse(File(dest.path + ".part").exists())
        }
    }

    @Test fun checksumMismatchIsDetectedAndNotRetried() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/actions/artifacts/7/zip") { Rsp(200, ByteArray(50) { 1 }) }
            val dest = File(tempDir(), "c.zip")
            expectThrowsSuspend<ChecksumMismatch> { s.api().downloadArtifactZip("o/r", art(size = 50, digest = "sha256:" + "0".repeat(64)), dest) }
            assertFalse(dest.exists())
            assertEquals(1, s.requests.size)
        }
    }

    @Test fun serverErrorRetriesWithFreshRedirectThenSucceeds() = run0 {
        MockServer().use { s ->
            var n = 0
            s.on("GET", "/repos/o/r/actions/artifacts/7/zip") { n++; if (n == 1) Rsp(502, "{\"message\":\"bad gateway\"}") else Rsp(200, "OK".toByteArray()) }
            val dest = File(tempDir(), "r.zip")
            s.api().downloadArtifactZip("o/r", art(size = 2), dest)
            assertEquals(2, n); assertEquals("OK", dest.readText())
        }
    }

    @Test fun expiredArtifactIsRefusedWithoutRequest() = run0 {
        MockServer().use { s ->
            expectThrowsSuspend<IOException> { s.api().downloadArtifactZip("o/r", art(expired = true), File(tempDir(), "e.zip")) }
            assertEquals(0, s.requests.size)
        }
    }

    @Test fun endToEndArtifactToVerifiedApk() = run0 {
        MockServer().use { s ->
            val apk = ByteArray(2000) { (it % 251).toByte() }
            val manifest = "${sha(apk)}  Aisya_AddonForge_v43.apk\n"
            val zip = zipOf(listOf("Aisya_AddonForge_v43.apk" to apk, "Aisya_AddonForge_v43.apk.sha256" to manifest.toByteArray(), "build.log" to "log".toByteArray()))
            s.on("GET", "/repos/o/r/actions/runs/1/artifacts") {
                Rsp(200, Json.write(mapOf("artifacts" to listOf(
                    mapOf("id" to 7, "name" to "logs-only", "size_in_bytes" to 10, "expired" to true),
                    mapOf("id" to 8, "name" to "apk", "size_in_bytes" to zip.size, "expired" to false, "digest" to "sha256:" + sha(zip), "workflow_run" to mapOf("id" to 1, "head_sha" to "abc"))))))
            }
            s.on("GET", "/repos/o/r/actions/artifacts/8/zip") { Rsp(200, zip) }
            val api = s.api()
            val arts = api.listArtifacts("o/r", 1)
            assertTrue(arts[0].expired); assertEquals("abc", arts[1].headSha)
            val fetched = ArtifactService(api).fetch("o/r", arts[1], tempDir())
            val a = fetched.result.apks.single()
            assertEquals("Aisya_AddonForge_v43.apk", a.file.name)
            assertEquals(true, a.manifestMatches); assertEquals(sha(apk), a.sha256); assertFalse(a.looksSplit)
            assertEquals(1, fetched.result.ignoredEntries)
        }
    }

    @Test fun logsOnlyArtifactIsReportedAsNoApk() = run0 {
        MockServer().use { s ->
            val zip = zipOf(listOf("build.log" to "x".toByteArray()))
            s.on("GET", "/repos/o/r/actions/artifacts/9/zip") { Rsp(200, zip) }
            val e = expectThrowsSuspend<IOException> { ArtifactService(s.api()).fetch("o/r", art(id = 9, size = zip.size.toLong()), tempDir()) }
            assertTrue(e.message!!.contains("no .apk"))
        }
    }

    @Test fun releaseAssetDownloadUsesOctetAcceptAndFollowsRedirectWithoutAuth() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/releases/assets/4") { Rsp(302, ByteArray(0), mapOf("Location" to "http://127.0.0.2:${s.port}/cdn/4")) }
            s.on("GET", "/cdn/4") { Rsp(200, "data".toByteArray()) }
            val dest = File(tempDir(), "x.apk")
            s.api().downloadAsset("o/r", Asset(4, "x.apk", 4, "uploaded", null, null), dest)
            assertEquals("application/octet-stream", s.requests.first().headers["accept"])
            assertNull(s.requests.last().headers["authorization"]); assertEquals("data", dest.readText())
        }
    }

    /**
     * Verifies cancellation semantics (job ends cancelled, no partial files). Promptness of the abort depends on
     * HttpURLConnection.disconnect(): the desktop JDK drains the body first, Android's OkHttp-backed one aborts at once.
     */
    @Test fun cancellingTheCoroutineEndsCancelledAndLeavesNoPartialFiles() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/actions/artifacts/7/zip") { Rsp(200, ByteArray(10), declaredLength = 1000, stallMs = 1500) }
            val dest = File(tempDir(), "s.zip")
            val started = System.currentTimeMillis()
            val job = kotlinx.coroutines.GlobalScope.launch { s.api().downloadArtifactZip("o/r", art(size = 1000), dest, attempts = 1) }
            kotlinx.coroutines.delay(500)
            job.cancelAndJoin()
            if (System.currentTimeMillis() - started > 20_000) throw AssertionError("cancel hung")
            if (!job.isCancelled) throw AssertionError("job was not cancelled")
            if (dest.exists() || File(dest.path + ".part").exists()) throw AssertionError("partial files left behind")
        }
    }
}
