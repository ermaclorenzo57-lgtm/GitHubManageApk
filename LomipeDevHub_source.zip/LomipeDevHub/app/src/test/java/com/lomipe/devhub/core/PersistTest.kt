package com.lomipe.devhub.core

import org.junit.Assert.*
import org.junit.Test
import java.io.File

class PersistTest {
    @Test fun accountsGetIsolatedDirectories() {
        val p = AccountPaths(tempDir())
        val a = p.cache("Alice"); val b = p.cache("bob")
        File(a, "x").writeText("1")
        assertNotEquals(a, b); assertFalse(File(b, "x").exists())
        assertNotEquals(p.history("alice"), p.history("bob"))
        assertTrue(p.dir("../evil").canonicalPath.startsWith(p.dir("zz").parentFile.canonicalPath))
    }

    @Test fun uploadQueueSurvivesRecreationAndMarksRunningAsInterrupted() {
        val f = File(tempDir(), "q.json")
        UploadQueueStore(f).save(listOf(
            UploadRecord("1", "o/r", "main", "", "commit", "content://x/1", "a.zip", 10, "msg", "running", "token ghp_abcdefghijklmnopqrstuvwxyz0123456789"),
            UploadRecord("2", "o/r", "main", "d", "release", "content://x/2", "b.zip", 20, "m", "done", "ok")))
        val loaded = UploadQueueStore(f).load()
        assertEquals(listOf("interrupted", "done"), loaded.map { it.state })
        assertFalse(loaded[0].detail.contains("ghp_"))
        assertEquals("content://x/1", loaded[0].uri)
    }

    @Test fun corruptQueueFileDoesNotCrash() {
        val f = File(tempDir(), "q.json"); f.writeText("{{{")
        assertTrue(UploadQueueStore(f).load().isEmpty())
    }
}
