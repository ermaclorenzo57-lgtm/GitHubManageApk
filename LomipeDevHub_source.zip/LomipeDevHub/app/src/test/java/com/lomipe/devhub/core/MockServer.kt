package com.lomipe.devhub.core

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class Req(val method: String, val path: String, val query: String?, val headers: Map<String, String>, val body: ByteArray) {
    val host: String get() = headers["host"]?.substringBefore(':') ?: ""
}

class Rsp(
    val code: Int, val body: ByteArray = ByteArray(0), val headers: Map<String, String> = emptyMap(),
    /** If set, advertise this many bytes but only send [body] (simulates a cut connection). */
    val declaredLength: Long? = null,
    /** Keep the connection open this long after sending the body (simulates a stalled download). */
    val stallMs: Long = 0,
) {
    constructor(code: Int, text: String, headers: Map<String, String> = emptyMap()) : this(code, text.toByteArray(), headers)
}

/** Local stand-in for api.github.com. Bound to all loopback addresses so 127.0.0.1 and 127.0.0.2 act as two different hosts. */
class MockServer : AutoCloseable {
    val requests = CopyOnWriteArrayList<Req>()
    private val routes = CopyOnWriteArrayList<Triple<String, Regex, (Req) -> Rsp>>()
    private val server = HttpServer.create(InetSocketAddress(0), 0)
    val port: Int get() = server.address.port
    val base: String get() = "http://127.0.0.1:$port"

    init {
        server.executor = Executors.newCachedThreadPool()
        server.createContext("/") { ex -> handle(ex) }
        server.start()
    }

    fun on(method: String, path: String, handler: (Req) -> Rsp) { routes.add(0, Triple(method, Regex(path), handler)) }

    private fun handle(ex: HttpExchange) {
        try {
            val headers = ex.requestHeaders.entries.associate { it.key.lowercase() to (it.value.firstOrNull() ?: "") }
            val req = Req(ex.requestMethod, ex.requestURI.rawPath, ex.requestURI.rawQuery, headers, ex.requestBody.readAllBytes())
            requests.add(req)
            val r = routes.firstOrNull { it.first == req.method && it.second.matches(req.path) }?.third?.invoke(req) ?: Rsp(404, "{\"message\":\"Not Found\"}")
            r.headers.forEach { (k, v) -> ex.responseHeaders.add(k, v) }
            if (r.declaredLength != null) {
                ex.sendResponseHeaders(r.code, r.declaredLength)
                ex.responseBody.write(r.body); ex.responseBody.flush()
                if (r.stallMs > 0) Thread.sleep(r.stallMs)
            } else if (r.body.isEmpty()) {
                ex.sendResponseHeaders(r.code, -1)
            } else {
                ex.sendResponseHeaders(r.code, r.body.size.toLong())
                ex.responseBody.write(r.body)
            }
        } catch (_: Exception) {
        } finally {
            try { ex.close() } catch (_: Exception) {}
        }
    }

    fun api(token: String = "test-token-not-real"): GitHubApi =
        GitHubApi(GitHubHttp({ token }, HttpPolicy(base, base, requireHttps = false)))

    override fun close() { server.stop(0) }
}

inline fun <reified E : Throwable> expectThrows(block: () -> Unit): E {
    try { block() } catch (e: Throwable) {
        if (e is E) return e
        throw AssertionError("Expected ${E::class.java.simpleName} but got $e", e)
    }
    throw AssertionError("Expected ${E::class.java.simpleName} but nothing was thrown")
}

fun json(vararg pairs: Pair<String, Any?>): String = Json.write(mapOf(*pairs))
fun jsonHeaders() = mapOf("Content-Type" to "application/json")

/** Test wrapper that always returns Unit (JUnit 4 requires void test methods). */
fun run0(block: suspend kotlinx.coroutines.CoroutineScope.() -> Unit) { kotlinx.coroutines.runBlocking { block() } }

fun tempDir(): java.io.File = java.nio.file.Files.createTempDirectory("lomipe-test").toFile()

fun gitBlob(bytes: ByteArray): String {
    val md = java.security.MessageDigest.getInstance("SHA-1")
    md.update("blob ${bytes.size}\u0000".toByteArray()); md.update(bytes); return md.digest().hex()
}
