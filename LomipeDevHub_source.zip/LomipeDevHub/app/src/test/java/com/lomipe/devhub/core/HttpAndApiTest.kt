package com.lomipe.devhub.core

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class HttpAndApiTest {
    @Test fun authFailureIsMapped() = run0 {
        MockServer().use { s ->
            s.on("GET", "/user") { Rsp(401, "{\"message\":\"Bad credentials\"}") }
            val e = expectThrowsSuspend<ApiException> { s.api().getUser() }
            assertEquals(ErrorKind.AUTH, e.kind)
        }
    }

    @Test fun permissionErrorAndRateLimitAndSso() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/a") { Rsp(403, "{\"message\":\"Resource not accessible by personal access token\"}") }
            s.on("GET", "/repos/o/b") { Rsp(403, "{\"message\":\"API rate limit exceeded\"}", mapOf("X-RateLimit-Remaining" to "0", "X-RateLimit-Reset" to "1900000000")) }
            s.on("GET", "/repos/o/c") { Rsp(403, "{\"message\":\"x\"}", mapOf("X-GitHub-SSO" to "required; url=https://example")) }
            s.on("GET", "/repos/o/d") { Rsp(404, "{\"message\":\"Not Found\"}") }
            val api = s.api()
            assertEquals(ErrorKind.FORBIDDEN, expectThrowsSuspend<ApiException> { api.getRepo("o/a") }.kind)
            val rl = expectThrowsSuspend<ApiException> { api.getRepo("o/b") }
            assertEquals(ErrorKind.RATE_LIMIT, rl.kind); assertEquals(1900000000L, rl.resetEpochSeconds)
            assertTrue(expectThrowsSuspend<ApiException> { api.getRepo("o/c") }.message!!.contains("SSO"))
            assertEquals(ErrorKind.NOT_FOUND, expectThrowsSuspend<ApiException> { api.getRepo("o/d") }.kind)
        }
    }

    @Test fun paginationFollowsLinkHeader() = run0 {
        MockServer().use { s ->
            s.on("GET", "/user/repos") { r ->
                val page = Regex("(?:^|&)page=(\\d+)").find(r.query!!)!!.groupValues[1].toInt()
                val repo = mapOf("full_name" to "me/r$page", "private" to true, "default_branch" to "main", "permissions" to mapOf("push" to true))
                Rsp(200, Json.write(listOf(repo)), if (page < 3) mapOf("Link" to "<x>; rel=\"next\"") else emptyMap())
            }
            val api = s.api()
            val seen = ArrayList<String>(); var page = 1
            while (true) { val p = api.listRepos(page); seen += p.items.map { it.fullName }; if (!p.hasNext) break; page++ }
            assertEquals(listOf("me/r1", "me/r2", "me/r3"), seen)
        }
    }

    @Test fun tokenIsSentOnlyToTrustedHostAndUntrustedStartIsRefused() = run0 {
        MockServer().use { s ->
            s.on("GET", "/user") { Rsp(200, json("login" to "me")) }
            val api = s.api("secret-value-123")
            assertEquals("me", api.getUser().login)
            assertEquals("Bearer secret-value-123", s.requests.last().headers["authorization"])
            // Different host than api/uploads base -> refused before any request is made.
            val n = s.requests.size
            expectThrowsSuspend<IllegalArgumentException> { api.http.send("GET", "http://127.0.0.2:${s.port}/user") }
            assertEquals(n, s.requests.size)
        }
    }

    @Test fun httpsIsRequiredByDefault() = run0 {
        val http = GitHubHttp({ "t" })
        expectThrowsSuspend<IllegalArgumentException> { http.send("GET", "http://api.github.com/user") }
        Unit
    }

    @Test fun conditionalRequestUsesEtag() = run0 {
        MockServer().use { s ->
            var hits = 0
            s.on("GET", "/repos/o/r/actions/runs/5") { r ->
                hits++
                if (r.headers["if-none-match"] == "\"v1\"") Rsp(304, ByteArray(0), mapOf("ETag" to "\"v1\""))
                else Rsp(200, Json.write(mapOf("id" to 5, "status" to "in_progress")), mapOf("ETag" to "\"v1\""))
            }
            val api = s.api()
            assertEquals("in_progress", api.getRun("o/r", 5, etag = true).status)
            assertEquals("in_progress", api.getRun("o/r", 5, etag = true).status)
            assertEquals(2, hits)
            assertEquals("\"v1\"", s.requests.last().headers["if-none-match"])
        }
    }

    @Test fun runStatesJobsAndSteps() = run0 {
        MockServer().use { s ->
            val runs = listOf("queued" to null, "in_progress" to null, "completed" to "success", "completed" to "failure", "completed" to "cancelled")
                .mapIndexed { i, (st, c) -> mapOf("id" to (i + 1), "run_number" to (i + 10), "run_attempt" to 2, "status" to st, "conclusion" to c, "event" to "push", "head_branch" to "main", "head_sha" to "abc$i") }
            s.on("GET", "/repos/o/r/actions/runs") { Rsp(200, Json.write(mapOf("total_count" to 5, "workflow_runs" to runs))) }
            s.on("GET", "/repos/o/r/actions/runs/4/jobs") {
                Rsp(200, Json.write(mapOf("jobs" to listOf(mapOf("id" to 77, "name" to "build", "status" to "completed", "conclusion" to "failure",
                    "steps" to listOf(
                        mapOf("number" to 1, "name" to "Checkout", "status" to "completed", "conclusion" to "success"),
                        mapOf("number" to 2, "name" to "Build", "status" to "completed", "conclusion" to "failure"),
                        mapOf("number" to 3, "name" to "Upload", "status" to "completed", "conclusion" to "skipped")))))))
            }
            val api = s.api()
            val list = api.listRuns("o/r").items
            assertEquals(listOf(true, true, false, false, false), list.map { it.isActive })
            assertTrue(list[2].isSuccess); assertTrue(list[3].isFailure); assertFalse(list[4].isSuccess)
            assertEquals(2, list[0].attempt)
            val jobs = api.listJobs("o/r", 4)
            assertEquals(3, jobs[0].steps.size)
            val (job, step) = LogAnalyzer.failedStep(jobs)!!
            assertEquals("build", job.name); assertEquals("Build", step!!.name)
            assertEquals(3, jobs[0].completedSteps)
        }
    }

    @Test fun rerunCancelDispatchHitOfficialEndpoints() = run0 {
        MockServer().use { s ->
            s.on("POST", ".*") { Rsp(if (it.path.endsWith("dispatches")) 204 else 201) }
            val api = s.api()
            api.cancelRun("o/r", 9); api.rerun("o/r", 9); api.rerunFailed("o/r", 9)
            api.dispatch("o/r", 12, "main", mapOf("k" to "v"))
            val paths = s.requests.map { it.method + " " + it.path }
            assertEquals(listOf(
                "POST /repos/o/r/actions/runs/9/cancel", "POST /repos/o/r/actions/runs/9/rerun",
                "POST /repos/o/r/actions/runs/9/rerun-failed-jobs", "POST /repos/o/r/actions/workflows/12/dispatches"), paths)
            val body = Json.parse(String(s.requests.last().body)).asObj()!!
            assertEquals("main", body["ref"]); assertEquals("v", body.o("inputs")!!["k"])
        }
    }

    @Test fun jobLogIsRedactedAndTailTruncated() = run0 {
        MockServer().use { s ->
            val big = StringBuilder()
            repeat(5000) { big.append("line $it ok\n") }
            big.append("2026-01-01T00:00:00.0000000Z ##[error]Process completed with exit code 1 ghp_abcdefghijklmnopqrstuvwxyz0123456789\n")
            s.on("GET", "/repos/o/r/actions/jobs/3/logs") { Rsp(200, big.toString()) }
            val log = s.api().jobLog("o/r", 3, maxChars = 10_000)
            assertTrue(log.truncated); assertTrue(log.text.length <= 10_000)
            assertFalse(log.text.contains("ghp_abc"))
            assertTrue(LogAnalyzer.firstError(log.text)!!.contains("exit code 1"))
            assertEquals(1, LogAnalyzer.search(log.text, "exit code").size)
        }
    }

    @Test fun contentsPathsAreEncodedPerSegmentAndUnsafeOnesRejected() {
        assertEquals("a%20b/c%23d.txt", encodeRepoPath("a b/c#d.txt"))
        for (bad in listOf("", "/abs", "a/../b", "a//b", "a\\b", ".git/config", "dir/", "a/./b")) expectThrows<IllegalArgumentException> { validateRepoPath(bad) }
    }

    @Test fun redactorRemovesTokensAndSignedUrls() {
        val t = "Authorization: Bearer github_pat_11ABCDEFG0abcdefghijklmnopqrstuv and https://blob.example/x?sig=AbC123&se=2026 and ghs_abcdefghijklmnopqrstuvwxyz012345"
        val r = Redactor.redact(t)
        assertFalse(r.contains("github_pat_")); assertFalse(r.contains("AbC123")); assertFalse(r.contains("ghs_abc"))
        assertTrue(r.contains("https://blob.example/x?[redacted]"))
    }

    @Test fun jsonRoundTrip() {
        val v = Json.parse("""{"a":[1,2.5,"x\n\u00e9",true,null],"b":{"c":"d"}}""").asObj()!!
        assertEquals("x\n\u00e9", v["a"].asList()[2])
        assertEquals(v, Json.parse(Json.write(v)).asObj())
    }
}

suspend inline fun <reified E : Throwable> expectThrowsSuspend(crossinline block: suspend () -> Unit): E {
    try { block() } catch (e: Throwable) {
        if (e is E) return e
        throw AssertionError("Expected ${E::class.java.simpleName} but got $e", e)
    }
    throw AssertionError("Expected ${E::class.java.simpleName} but nothing was thrown")
}
