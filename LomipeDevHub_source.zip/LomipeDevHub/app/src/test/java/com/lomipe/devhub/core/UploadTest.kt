package com.lomipe.devhub.core

import org.junit.Assert.*
import org.junit.Test
import java.util.Base64
import java.util.Random

class UploadTest {
    private fun extractContent(body: ByteArray): ByteArray {
        val s = String(body, Charsets.ISO_8859_1)
        val k = s.indexOf("\"content\":\"") + 11
        val e = s.lastIndexOf("\"}")
        return Base64.getDecoder().decode(s.substring(k, e))
    }

    @Test fun blobShaMatchesGit() {
        // `printf 'hello\n' | git hash-object --stdin`
        assertEquals("ce013625030ba8dba906f756967f9e9ca394464a", gitBlobSha1(BytesSource("a", "hello\n".toByteArray())).first)
    }

    /** Acceptance case from the spec: a 39,306,752-byte ZIP uploaded as a branch commit. */
    @Test fun streamsLargeZipAsCommitWithExactContentLength() = run0 {
        val dir = tempDir()
        val f = java.io.File(dir, "AISYA_ADDONFORGE_V43_FULL.zip")
        val rnd = Random(43)
        f.outputStream().use { o -> val b = ByteArray(1 shl 16); var left = 39_306_752L; while (left > 0) { rnd.nextBytes(b); val n = minOf(left, b.size.toLong()).toInt(); o.write(b, 0, n); left -= n } }
        assertEquals(39_306_752L, f.length())
        MockServer().use { s ->
            var receivedBlob = ""
            var lenHeader = -1L; var chunked = false; var bodyLen = -1
            s.on("GET", "/repos/o/r/contents/.*") { Rsp(404, "{\"message\":\"Not Found\"}") }
            s.on("PUT", "/repos/o/r/contents/.*") { r ->
                lenHeader = r.headers["content-length"]?.toLong() ?: -1; chunked = r.headers.containsKey("transfer-encoding"); bodyLen = r.body.size
                receivedBlob = gitBlob(extractContent(r.body))
                Rsp(201, json("content" to mapOf("sha" to receivedBlob), "commit" to mapOf("sha" to "c0ffee")))
            }
            val progress = ArrayList<Long>()
            val res = Uploader(s.api()).commitFile("o/r", "main", "uploads/${f.name}", FileSource(f), "Upload", false) { progress += it }
            assertEquals(bodyLen.toLong(), lenHeader); assertFalse(chunked)
            assertEquals("c0ffee", res.commitSha); assertTrue(res.blobVerified); assertFalse(res.replaced)
            assertEquals(gitBlobSha1(FileSource(f)).first, receivedBlob)
            assertEquals(39_306_752L, progress.last())
            val put = s.requests.last()
            assertEquals("/repos/o/r/contents/uploads/AISYA_ADDONFORGE_V43_FULL.zip", put.path)
            assertEquals(sha256Of(f), res.sha256)
        }
        dir.deleteRecursively()
    }

    @Test fun existingFileRequiresConfirmationThenSendsSha() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/contents/a.txt") { Rsp(200, json("type" to "file", "sha" to "oldsha", "size" to 3, "name" to "a.txt", "path" to "a.txt")) }
            s.on("PUT", "/repos/o/r/contents/a.txt") { r -> Rsp(200, json("content" to mapOf("sha" to gitBlob("new".toByteArray())), "commit" to mapOf("sha" to "c2"))) }
            val up = Uploader(s.api())
            val src = BytesSource("a.txt", "new".toByteArray())
            val e = expectThrowsSuspend<OverwriteRequired> { up.commitFile("o/r", "main", "a.txt", src, "m", false) }
            assertEquals("oldsha", e.existingSha)
            assertTrue(s.requests.none { it.method == "PUT" })           // nothing written without confirmation
            val ok = up.commitFile("o/r", "main", "a.txt", src, "m", true)
            assertTrue(ok.replaced)
            val sent = Json.parse(String(s.requests.last().body)).asObj()!!
            assertEquals("oldsha", sent["sha"]); assertEquals("main", sent["branch"])
            assertEquals("new", String(Base64.getDecoder().decode(sent["content"] as String)))
        }
    }

    @Test fun conflictAndLookupFailuresAreNotSwallowed() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/contents/ok.txt") { Rsp(404, "{\"message\":\"Not Found\"}") }
            s.on("PUT", "/repos/o/r/contents/ok.txt") { Rsp(409, "{\"message\":\"ref changed\"}") }
            s.on("GET", "/repos/o/r/contents/bad.txt") { Rsp(500, "{\"message\":\"boom\"}") }
            val up = Uploader(s.api())
            assertEquals(ErrorKind.CONFLICT, expectThrowsSuspend<ApiException> { up.commitFile("o/r", "main", "ok.txt", BytesSource("x", "1".toByteArray()), "m", false) }.kind)
            assertEquals(ErrorKind.SERVER, expectThrowsSuspend<ApiException> { up.commitFile("o/r", "main", "bad.txt", BytesSource("x", "1".toByteArray()), "m", false) }.kind)
            assertTrue(s.requests.none { it.method == "PUT" && it.path.endsWith("bad.txt") })
        }
    }

    @Test fun tooLargeAndValidationAreReportedWithoutModeSwitch() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/contents/.*") { Rsp(404, "{}") }
            s.on("PUT", "/repos/o/r/contents/big.bin") { Rsp(413, "{\"message\":\"too big\"}") }
            s.on("PUT", "/repos/o/r/contents/v.bin") { Rsp(422, "{\"message\":\"invalid\"}") }
            val up = Uploader(s.api())
            assertEquals(ErrorKind.TOO_LARGE, expectThrowsSuspend<ApiException> { up.commitFile("o/r", "main", "big.bin", BytesSource("b", ByteArray(10)), "m", false) }.kind)
            assertEquals(ErrorKind.VALIDATION, expectThrowsSuspend<ApiException> { up.commitFile("o/r", "main", "v.bin", BytesSource("b", ByteArray(10)), "m", false) }.kind)
            assertTrue(s.requests.none { it.path.contains("/releases") })
        }
    }

    @Test fun unsafePathsRejectedBeforeAnyRequest() = run0 {
        MockServer().use { s ->
            val up = Uploader(s.api())
            expectThrowsSuspend<IllegalArgumentException> { up.commitFile("o/r", "main", "../x", BytesSource("x", ByteArray(1)), "m", false) }
            assertEquals(0, s.requests.size)
        }
    }

    @Test fun releaseUploadUsesUniqueNameStreamsBinaryAndNeverDeletes() = run0 {
        MockServer().use { s ->
            val data = ByteArray(300_000).also { Random(1).nextBytes(it) }
            s.on("GET", "/repos/o/r/releases/5/assets") { Rsp(200, Json.write(listOf(mapOf("id" to 1, "name" to "src.zip", "size" to 1)))) }
            s.on("POST", "/repos/o/r/releases/5/assets") { r ->
                Rsp(201, Json.write(mapOf("id" to 2, "name" to r.query!!.substringAfter("name="), "size" to r.body.size, "state" to "uploaded", "digest" to "sha256:" + java.security.MessageDigest.getInstance("SHA-256").digest(r.body).hex())))
            }
            val rel = Release(5, "t", null, true, false, null, "", emptyList())
            val res = Uploader(s.api()).uploadReleaseAssetChecked("o/r", rel, BytesSource("src.zip", data), "src.zip", {}, stamp = "20260101")
            assertEquals("src-20260101.zip", res.finalName); assertTrue(res.sizeVerified); assertEquals(true, res.digestVerified)
            assertTrue(s.requests.none { it.method == "DELETE" })
            val post = s.requests.last()
            assertEquals("application/octet-stream", post.headers["content-type"])
            assertEquals(data.size, post.body.size)
            assertTrue(post.host == "127.0.0.1")
        }
    }

    @Test fun uniqueAssetNameHandlesCollisions() {
        val u = Uploader(GitHubApi(GitHubHttp({ "" })))
        assertEquals("a.zip", u.uniqueAssetName("a.zip", listOf("b.zip"), "S"))
        assertEquals("a-S-2.zip", u.uniqueAssetName("a.zip", listOf("a.zip", "a-S.zip"), "S"))
        assertEquals("noext-S", u.uniqueAssetName("noext", listOf("noext"), "S"))
    }

    @Test fun correlationSingleAmbiguousNone() {
        fun run(id: Long, sha: String, ev: String = "push", wf: Long = 1, branch: String = "main", created: String = "2026-01-01T00:00:10Z") =
            Run(id, id, 1, "n", wf, "queued", null, ev, branch, sha, null, created, null, null, "")
        val runs = listOf(run(1, "aaa"), run(2, "bbb"), run(3, "bbb", wf = 2), run(4, "ccc", ev = "workflow_dispatch"))
        assertTrue(RunCorrelator.correlate(runs, "aaa", "push", "main") is RunCorrelator.Match.Single)
        assertTrue(RunCorrelator.correlate(runs, "bbb", "push", "main") is RunCorrelator.Match.Ambiguous)
        assertTrue(RunCorrelator.correlate(runs, "bbb", "push", "main", workflowId = 2) is RunCorrelator.Match.Single)
        assertTrue(RunCorrelator.correlate(runs, "zzz", "push", "main") is RunCorrelator.Match.None)
        assertTrue(RunCorrelator.correlate(runs, "ccc", "push", "main") is RunCorrelator.Match.None)   // wrong event is not "ours"
        assertTrue(RunCorrelator.correlateDispatch(runs, "main", 1, "2026-01-01T00:00:00Z") !is RunCorrelator.Match.None)
        assertTrue(RunCorrelator.correlateDispatch(runs, "main", 1, "2026-01-02T00:00:00Z") is RunCorrelator.Match.None)
    }

    @Test fun editWithStaleShaIsRejectedBeforeWriting() = run0 {
        MockServer().use { s ->
            s.on("GET", "/repos/o/r/contents/a.txt") { Rsp(200, json("type" to "file", "sha" to "NEWER", "size" to 3, "name" to "a.txt", "path" to "a.txt")) }
            val e = expectThrowsSuspend<ApiException> {
                Uploader(s.api()).commitFile("o/r", "main", "a.txt", BytesSource("a.txt", "x".toByteArray()), "m", true, expectedSha = "OLDER")
            }
            assertEquals(ErrorKind.CONFLICT, e.kind)
            assertTrue(s.requests.none { it.method == "PUT" })
        }
    }

    @Test fun lineDiffShowsAddedAndRemoved() {
        val d = LineDiff.diff("a\nb\nc", "a\nB\nc\nd")
        assertEquals(listOf(' ' to "a", '-' to "b", '+' to "B", ' ' to "c", '+' to "d"), d.map { it.kind to it.text })
        assertEquals(3, LineDiff.changed(d))
    }
}
