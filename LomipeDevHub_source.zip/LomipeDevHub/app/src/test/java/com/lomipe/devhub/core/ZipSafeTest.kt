package com.lomipe.devhub.core

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ZipSafeTest {
    private fun write(entries: List<Pair<String, ByteArray>>): File = File(tempDir(), "t.zip").also { it.writeBytes(zipOf(entries)) }
    private fun out() = File(tempDir(), "out")

    @Test fun zipSlipAndAbsoluteAndBackslashRejected() {
        for (name in listOf("../evil.apk", "a/../../evil.apk", "/abs.apk", "C:/x.apk", "a\\b.apk"))
            expectThrows<UnsafeZipException> { ZipSafe.extractApks(write(listOf(name to ByteArray(4))), out()) }
    }

    @Test fun nothingIsWrittenOutsideStaging() {
        val o = out()
        expectThrows<UnsafeZipException> { ZipSafe.extractApks(write(listOf("ok.apk" to ByteArray(4), "../../escape.apk" to ByteArray(4))), o) }
        assertEquals(0, o.listFiles()?.size ?: 0)
    }

    @Test fun duplicateNamesRejected() {
        val f = File(tempDir(), "d.zip")
        // ZipOutputStream refuses duplicates, so use different case (still a duplicate on case-insensitive file systems) and different dirs.
        f.writeBytes(zipOf(listOf("a/x.apk" to ByteArray(2), "b/X.apk" to ByteArray(2))))
        expectThrows<UnsafeZipException> { ZipSafe.extractApks(f, out()) }
    }

    @Test fun zipBombAndSizeLimitsEnforcedOnRealBytes() {
        val big = ByteArray(5 * 1024 * 1024)      // compresses to a few KB
        val f = write(listOf("bomb.apk" to big))
        expectThrows<UnsafeZipException> { ZipSafe.extractApks(f, out(), ExtractLimits(maxApkBytes = 1024 * 1024)) }
        expectThrows<UnsafeZipException> { ZipSafe.extractApks(f, out(), ExtractLimits(maxTotalBytes = 1024 * 1024)) }
        expectThrows<UnsafeZipException> { ZipSafe.extractApks(write((1..20).map { "f$it.txt" to ByteArray(1) }), out(), ExtractLimits(maxEntries = 10)) }
    }

    @Test fun multipleApksAreAllReturnedAndSplitsFlagged() {
        val r = ZipSafe.extractApks(write(listOf("app-release.apk" to ByteArray(3) { 1 }, "split_config.arm64_v8a.apk" to ByteArray(3) { 2 }, "notes.txt" to ByteArray(1))), out())
        assertEquals(listOf("app-release.apk", "split_config.arm64_v8a.apk"), r.apks.map { it.file.name })
        assertEquals(listOf(false, true), r.apks.map { it.looksSplit })
        assertNull(r.manifestText); assertNull(r.apks[0].manifestMatches)
    }

    @Test fun checksumManifestMatchesExactFileNameOnly() {
        val apk = ByteArray(10) { 5 }
        val good = java.security.MessageDigest.getInstance("SHA-256").digest(apk).hex()
        val r = ZipSafe.extractApks(write(listOf("a.apk" to apk, "b.apk" to apk, "SHA256SUMS" to "$good  a.apk\n".toByteArray())), out())
        assertEquals(true, r.apks.first { it.file.name == "a.apk" }.manifestMatches)
        assertNull(r.apks.first { it.file.name == "b.apk" }.manifestMatches)        // no entry for b.apk -> unknown, not "ok"
        val bad = ZipSafe.extractApks(write(listOf("a.apk" to apk, "a.apk.sha256" to ("0".repeat(64) + " *a.apk").toByteArray())), out())
        assertEquals(false, bad.apks[0].manifestMatches)
        assertEquals(good, Checksums.lookup("SHA256 (x/a.apk) = ${good.uppercase()}", "a.apk"))
        assertNull(Checksums.lookup("$good  xa.apk", "a.apk"))
    }

    @Test fun corruptZipIsRejected() {
        val bytes = zipOf(listOf("a.apk" to ByteArray(5000) { (it * 7).toByte() }))
        bytes[60] = (bytes[60] + 1).toByte()               // flip a byte in the entry data
        val f = File(tempDir(), "c.zip").also { it.writeBytes(bytes) }
        expectThrows<java.io.IOException> { ZipSafe.extractApks(f, out()) }
    }

    @Test fun stagingIsFreshEachTime() {
        val o = out(); o.mkdirs(); File(o, "stale.apk").writeText("old")
        ZipSafe.extractApks(write(listOf("n.apk" to ByteArray(1))), o)
        assertFalse(File(o, "stale.apk").exists())
    }
}
