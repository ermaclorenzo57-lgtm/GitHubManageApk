package com.lomipe.devhub.core

object LogAnalyzer {
    private val errorLine = Regex("(##\\[error\\])|(\\berror:)|(FAILURE:)|(\\bFAILED\\b)|(What went wrong)|(Exception\\b)", RegexOption.IGNORE_CASE)
    private val ts = Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z\\s?")

    /** First line that looks like an error, with up to two lines of context. No AI, just pattern matching. */
    fun firstError(log: String): String? {
        val lines = log.lines()
        val i = lines.indexOfFirst { errorLine.containsMatchIn(it) }
        if (i < 0) return null
        return lines.subList(i, minOf(lines.size, i + 3)).joinToString("\n") { ts.replace(it, "") }
    }

    fun search(log: String, query: String, limit: Int = 200): List<Pair<Int, String>> {
        if (query.isBlank()) return emptyList()
        return log.lines().withIndex().filter { it.value.contains(query, true) }.take(limit).map { (it.index + 1) to it.value }
    }

    fun failedStep(jobs: List<GhJob>): Pair<GhJob, Step?>? {
        val j = jobs.firstOrNull { it.conclusion == "failure" || it.conclusion == "timed_out" } ?: return null
        return j to j.steps.firstOrNull { it.conclusion == "failure" || it.conclusion == "timed_out" }
    }
}

/** Line diff (LCS) for the commit preview. Large inputs fall back to a summary instead of burning CPU/memory. */
object LineDiff {
    data class Line(val kind: Char, val text: String)   // ' ' same, '-' removed, '+' added

    fun diff(old: String, new: String, maxLines: Int = 3000): List<Line> {
        val a = if (old.isEmpty()) emptyList() else old.split("\n")
        val b = if (new.isEmpty()) emptyList() else new.split("\n")
        if (a.size > maxLines || b.size > maxLines)
            return listOf(Line(' ', "File too large for a line diff (${a.size} -> ${b.size} lines)"))
        val dp = Array(a.size + 1) { IntArray(b.size + 1) }
        for (i in a.size - 1 downTo 0) for (j in b.size - 1 downTo 0)
            dp[i][j] = if (a[i] == b[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
        val out = ArrayList<Line>(); var i = 0; var j = 0
        while (i < a.size && j < b.size) {
            if (a[i] == b[j]) { out += Line(' ', a[i]); i++; j++ }
            else if (dp[i + 1][j] >= dp[i][j + 1]) out += Line('-', a[i++]) else out += Line('+', b[j++])
        }
        while (i < a.size) out += Line('-', a[i++])
        while (j < b.size) out += Line('+', b[j++])
        return out
    }

    fun changed(d: List<Line>) = d.count { it.kind != ' ' }
}
