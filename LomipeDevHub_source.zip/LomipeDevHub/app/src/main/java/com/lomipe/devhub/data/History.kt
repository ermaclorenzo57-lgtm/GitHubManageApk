package com.lomipe.devhub.data

import com.lomipe.devhub.core.*
import java.io.File

data class HistoryEntry(
    val id: String, val repo: String, val runId: Long, val attempt: Int, val commit: String,
    val artifactId: Long, val artifactName: String, val apkName: String, val size: Long,
    val sha256: String, val hashSource: String,      // "manifest-verified" | "locally-calculated"
    val packageName: String?, val versionName: String?, val versionCode: Long, val signer: String?,
    val validation: String, val savedUri: String, val privatePath: String, val savedAt: Long, val note: String,
)

class HistoryStore(private val file: File) {
    fun load(): List<HistoryEntry> {
        if (!file.exists()) return emptyList()
        return try {
            Json.parse(file.readText()).asList().mapNotNull { it.asObj() }.map {
                HistoryEntry(it.s("id") ?: "", it.s("repo") ?: "", it.l("runId"), it.l("attempt").toInt(), it.s("commit") ?: "",
                    it.l("artifactId"), it.s("artifactName") ?: "", it.s("apkName") ?: "", it.l("size"), it.s("sha256") ?: "",
                    it.s("hashSource") ?: "", it.s("packageName"), it.s("versionName"), it.l("versionCode"), it.s("signer"),
                    it.s("validation") ?: "", it.s("savedUri") ?: "", it.s("privatePath") ?: "", it.l("savedAt"), it.s("note") ?: "")
            }
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized fun add(e: HistoryEntry) = save(load() + e)
    @Synchronized fun remove(id: String) = save(load().filter { it.id != id })

    private fun save(list: List<HistoryEntry>) {
        val tmp = File(file.path + ".tmp")
        tmp.writeText(Json.write(list.map {
            mapOf("id" to it.id, "repo" to it.repo, "runId" to it.runId, "attempt" to it.attempt, "commit" to it.commit,
                "artifactId" to it.artifactId, "artifactName" to it.artifactName, "apkName" to it.apkName, "size" to it.size,
                "sha256" to it.sha256, "hashSource" to it.hashSource, "packageName" to it.packageName, "versionName" to it.versionName,
                "versionCode" to it.versionCode, "signer" to it.signer, "validation" to it.validation, "savedUri" to it.savedUri,
                "privatePath" to it.privatePath, "savedAt" to it.savedAt, "note" to it.note)
        }))
        if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
    }
}
