package com.lomipe.devhub.core

import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.Base64

private val REPO_RE = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

fun encodeSegment(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

/** Encodes each path segment but keeps slashes. Rejects unsafe repository paths. */
fun encodeRepoPath(path: String): String = validateRepoPath(path).split('/').joinToString("/") { encodeSegment(it) }

fun validateRepoPath(path: String): String {
    val p = path.trim()
    require(p.isNotEmpty()) { "Path is empty" }
    require(!p.startsWith("/") && !p.endsWith("/")) { "Path must not start or end with '/'" }
    require(!p.contains('\\')) { "Backslashes are not allowed" }
    require(p.none { it.code < 32 }) { "Control characters are not allowed" }
    for (seg in p.split('/')) {
        require(seg.isNotEmpty()) { "Empty path segment" }
        require(seg != "." && seg != "..") { "'.' and '..' segments are not allowed" }
        require(!seg.equals(".git", true)) { ".git is not allowed" }
    }
    return p
}

fun checkRepo(repo: String): String { require(REPO_RE.matches(repo)) { "Repository must look like owner/name" }; return repo }

class GitHubApi(val http: GitHubHttp) {
    private val api get() = http.policy.apiBase
    private fun r(repo: String) = "$api/repos/${checkRepo(repo)}"

    suspend fun getUser(): User = Parse.user(http.getJson("$api/user").json().asObj() ?: throw IOException("Bad /user response"))

    suspend fun listRepos(page: Int, perPage: Int = 50): Page<Repo> {
        val resp = http.getJson("$api/user/repos?per_page=$perPage&page=$page&sort=pushed&affiliation=owner,collaborator,organization_member")
        return Page(resp.json().asList().mapNotNull { it.asObj() }.map(Parse::repo), resp.hasNext(), page)
    }

    suspend fun getRepo(repo: String): Repo = Parse.repo(http.getJson(r(repo)).json().asObj()!!)

    suspend fun listBranches(repo: String, page: Int = 1): Page<Branch> {
        val resp = http.getJson("${r(repo)}/branches?per_page=100&page=$page")
        return Page(resp.json().asList().mapNotNull { it.asObj() }.map { Branch(it.s("name") ?: "", it.o("commit")?.s("sha") ?: "") }, resp.hasNext(), page)
    }

    suspend fun branchHeadSha(repo: String, branch: String): String {
        val o = http.getJson("${r(repo)}/branches/${encodeRepoPath(branch)}").json().asObj()
        return o?.o("commit")?.s("sha") ?: throw IOException("Branch has no commit")
    }

    suspend fun createBranch(repo: String, newBranch: String, fromSha: String) {
        validateRepoPath(newBranch)
        val body = Json.write(mapOf("ref" to "refs/heads/$newBranch", "sha" to fromSha)).toByteArray()
        http.send("POST", "${r(repo)}/git/refs", contentType = "application/json", length = body.size.toLong(), body = { o, _ -> o.write(body) })
    }

    // ---------- contents ----------
    suspend fun listContents(repo: String, path: String, ref: String): List<ContentEntry> {
        val p = if (path.isBlank()) "" else "/" + encodeRepoPath(path)
        val v = http.getJson("${r(repo)}/contents$p?ref=${encodeSegment(ref)}").json()
        return when (v) {
            is List<*> -> v.mapNotNull { it.asObj() }.map(Parse::entry).sortedWith(compareBy({ it.type != "dir" }, { it.name.lowercase() }))
            is Map<*, *> -> listOf(Parse.entry(v.asObj()!!))
            else -> emptyList()
        }
    }

    /** Returns null when the file does not exist (404). Other failures propagate. */
    suspend fun fileMeta(repo: String, path: String, ref: String): ContentEntry? {
        val resp = http.send("GET", "${r(repo)}/contents/${encodeRepoPath(path)}?ref=${encodeSegment(ref)}",
            accept = "application/vnd.github.object+json", okCodes = setOf(404))
        if (resp.code == 404) return null
        val o = resp.json().asObj() ?: return null
        if (o.s("type") != "file") throw IOException("$path is a ${o.s("type") ?: "non-file"}, not a file")
        return Parse.entry(o)
    }

    suspend fun readTextFile(repo: String, path: String, ref: String, maxBytes: Long = 1_000_000): FileContent {
        val resp = http.getJson("${r(repo)}/contents/${encodeRepoPath(path)}?ref=${encodeSegment(ref)}")
        val o = resp.json().asObj() ?: throw IOException("Unexpected response")
        if (o.s("type") != "file") throw IOException("Not a file")
        val size = o.l("size")
        if (size > maxBytes) return FileContent(path, o.s("sha") ?: "", size, null)
        val raw = Base64.getMimeDecoder().decode(o.s("content") ?: "")
        return FileContent(path, o.s("sha") ?: "", size, String(raw, Charsets.UTF_8))
    }

    suspend fun deleteFile(repo: String, path: String, branch: String, sha: String, message: String) {
        val body = Json.write(mapOf("message" to message, "sha" to sha, "branch" to branch)).toByteArray()
        http.send("DELETE", "${r(repo)}/contents/${encodeRepoPath(path)}", contentType = "application/json", length = body.size.toLong(), body = { o, _ -> o.write(body) })
    }

    // ---------- Actions ----------
    suspend fun listWorkflows(repo: String): List<Workflow> =
        http.getJson("${r(repo)}/actions/workflows?per_page=100").json().asObj()?.a("workflows")?.map(Parse::workflow) ?: emptyList()

    suspend fun listRuns(
        repo: String, workflowId: Long? = null, branch: String? = null, headSha: String? = null,
        event: String? = null, page: Int = 1, perPage: Int = 30, etag: Boolean = false,
    ): Page<Run> {
        val base = if (workflowId != null) "${r(repo)}/actions/workflows/$workflowId/runs" else "${r(repo)}/actions/runs"
        val q = buildList {
            add("per_page=$perPage"); add("page=$page")
            if (branch != null) add("branch=${encodeSegment(branch)}")
            if (headSha != null) add("head_sha=${encodeSegment(headSha)}")
            if (event != null) add("event=${encodeSegment(event)}")
        }.joinToString("&")
        val resp = http.getJson("$base?$q", etag)
        return Page(resp.json().asObj()?.a("workflow_runs")?.map(Parse::run) ?: emptyList(), resp.hasNext(), page)
    }

    suspend fun getRun(repo: String, runId: Long, attempt: Int? = null, etag: Boolean = false): Run {
        val suffix = if (attempt != null) "/attempts/$attempt" else ""
        return Parse.run(http.getJson("${r(repo)}/actions/runs/$runId$suffix", etag).json().asObj()!!)
    }

    suspend fun listJobs(repo: String, runId: Long, attempt: Int? = null): List<GhJob> {
        val base = if (attempt != null) "${r(repo)}/actions/runs/$runId/attempts/$attempt/jobs" else "${r(repo)}/actions/runs/$runId/jobs"
        val out = ArrayList<GhJob>()
        var page = 1
        while (page <= 10) {
            val resp = http.getJson("$base?per_page=100&page=$page")
            out += resp.json().asObj()?.a("jobs")?.map(Parse::job) ?: emptyList()
            if (!resp.hasNext()) break
            page++
        }
        return out
    }

    /** Job logs exist only after the job finishes. Keeps the tail when the log is huge and redacts secrets. */
    suspend fun jobLog(repo: String, jobId: Long, maxChars: Int = 600_000): LogText =
        http.download("${r(repo)}/actions/jobs/$jobId/logs") { input, _, check ->
            val sb = StringBuilder()
            val buf = CharArray(16 * 1024)
            var truncated = false
            input.reader(Charsets.UTF_8).use { rd ->
                while (true) {
                    check()
                    val n = rd.read(buf); if (n < 0) break
                    sb.append(buf, 0, n)
                    if (sb.length > maxChars * 2) { sb.delete(0, sb.length - maxChars); truncated = true }
                }
            }
            if (sb.length > maxChars) { sb.delete(0, sb.length - maxChars); truncated = true }
            LogText(Redactor.redact(sb.toString()), truncated)
        }

    suspend fun downloadRunLogsZip(repo: String, runId: Long, dest: File, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        Downloader.toFile(http, "${r(repo)}/actions/runs/$runId/logs", ACCEPT_JSON, dest, null, null, onProgress)
    }

    private suspend fun post(url: String, json: String? = null) {
        val b = json?.toByteArray()
        http.send("POST", url, contentType = if (b != null) "application/json" else null, length = b?.size?.toLong() ?: -1, body = b?.let { bytes -> { o, _ -> o.write(bytes) } })
    }

    suspend fun cancelRun(repo: String, runId: Long) = post("${r(repo)}/actions/runs/$runId/cancel")
    suspend fun rerun(repo: String, runId: Long) = post("${r(repo)}/actions/runs/$runId/rerun")
    suspend fun rerunFailed(repo: String, runId: Long) = post("${r(repo)}/actions/runs/$runId/rerun-failed-jobs")

    /** Success is an empty 204: no run id is returned. Callers must correlate the new run themselves. */
    suspend fun dispatch(repo: String, workflowId: Long, ref: String, inputs: Map<String, String> = emptyMap()) {
        val m = LinkedHashMap<String, Any?>(); m["ref"] = ref; if (inputs.isNotEmpty()) m["inputs"] = inputs
        post("${r(repo)}/actions/workflows/$workflowId/dispatches", Json.write(m))
    }

    suspend fun listArtifacts(repo: String, runId: Long): List<Artifact> =
        http.getJson("${r(repo)}/actions/runs/$runId/artifacts?per_page=100").json().asObj()?.a("artifacts")?.map(Parse::artifact) ?: emptyList()

    /** Downloads the artifact ZIP to [dest]. A fresh redirect is requested for every attempt. */
    suspend fun downloadArtifactZip(repo: String, artifact: Artifact, dest: File, attempts: Int = 3, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        if (artifact.expired) throw IOException("Artifact '${artifact.name}' has expired")
        var last: Exception? = null
        repeat(attempts) {
            try {
                Downloader.toFile(http, "${r(repo)}/actions/artifacts/${artifact.id}/zip", ACCEPT_JSON, dest,
                    artifact.sizeBytes.takeIf { it > 0 }, artifact.digest, onProgress)
                return
            } catch (e: ChecksumMismatch) { throw e }
            catch (e: ApiException) { if (e.kind != ErrorKind.SERVER) throw e; last = e }
            catch (e: IOException) { last = e }
        }
        throw last ?: IOException("Download failed")
    }

    // ---------- Releases ----------
    suspend fun listReleases(repo: String, page: Int = 1): Page<Release> {
        val resp = http.getJson("${r(repo)}/releases?per_page=30&page=$page")
        return Page(resp.json().asList().mapNotNull { it.asObj() }.map(Parse::release), resp.hasNext(), page)
    }

    suspend fun releaseByTag(repo: String, tag: String): Release? {
        val resp = http.send("GET", "${r(repo)}/releases/tags/${encodeSegment(tag)}", okCodes = setOf(404))
        return if (resp.code == 404) null else Parse.release(resp.json().asObj()!!)
    }

    suspend fun createRelease(repo: String, tag: String, name: String, body: String, draft: Boolean, target: String?): Release {
        val m = LinkedHashMap<String, Any?>(); m["tag_name"] = tag; m["name"] = name; m["body"] = body; m["draft"] = draft
        if (target != null) m["target_commitish"] = target
        val b = Json.write(m).toByteArray()
        val resp = http.send("POST", "${r(repo)}/releases", contentType = "application/json", length = b.size.toLong(), body = { o, _ -> o.write(b) })
        return Parse.release(resp.json().asObj()!!)
    }

    suspend fun listAssets(repo: String, releaseId: Long): List<Asset> {
        val out = ArrayList<Asset>(); var page = 1
        while (page <= 10) {
            val resp = http.getJson("${r(repo)}/releases/$releaseId/assets?per_page=100&page=$page")
            out += resp.json().asList().mapNotNull { it.asObj() }.map(Parse::asset)
            if (!resp.hasNext()) break; page++
        }
        return out
    }

    suspend fun deleteAsset(repo: String, assetId: Long) { http.send("DELETE", "${r(repo)}/releases/assets/$assetId") }

    suspend fun downloadAsset(repo: String, asset: Asset, dest: File, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        Downloader.toFile(http, "${r(repo)}/releases/assets/${asset.id}", ACCEPT_OCTET, dest, asset.size.takeIf { it > 0 }, asset.digest, onProgress)
    }

    suspend fun uploadReleaseAsset(repo: String, release: Release, source: UploadSource, assetName: String, onProgress: (Long) -> Unit): Asset =
        Uploader(this).uploadReleaseAsset(repo, release, source, assetName, onProgress)
}
