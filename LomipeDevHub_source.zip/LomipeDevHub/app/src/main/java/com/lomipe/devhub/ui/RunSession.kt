package com.lomipe.devhub.ui

import androidx.compose.runtime.*
import androidx.lifecycle.viewModelScope
import com.lomipe.devhub.core.*
import com.lomipe.devhub.data.*
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException

class RunSession(private val vm: AppViewModel, val repo: String, val runId: Long) {
    var run by mutableStateOf<Run?>(null)
    val jobs = mutableStateListOf<GhJob>()
    val artifacts = mutableStateListOf<Artifact>()
    var attempt by mutableStateOf<Int?>(null)
    var lastUpdated by mutableStateOf<String?>(null)
    var offline by mutableStateOf(false)
    var firstError by mutableStateOf<String?>(null)
    var fetched by mutableStateOf<Fetched?>(null)
    var progress by mutableStateOf<String?>(null)
    var info by mutableStateOf<String?>(null)
    private var poll: Job? = null
    private var dlJob: Job? = null
    private var signature = ""
    private var errorLoadedFor = -1L

    init { start() }

    fun start() {
        poll?.cancel()
        poll = vm.viewModelScope.launch {
            val base = vm.refreshSeconds * 1000L
            var wait = base
            var first = true
            while (isActive) {
                if (vm.foreground || first) {
                    try {
                        val changed = refreshOnce()
                        offline = false
                        wait = if (changed) base else (wait * 3 / 2).coerceAtMost(maxOf(15_000L, base))
                    } catch (e: CancellationException) { throw e }
                    catch (e: ApiException) {
                        if (e.kind == ErrorKind.RATE_LIMIT) {
                            val reset = e.resetEpochSeconds?.let { it * 1000 - System.currentTimeMillis() } ?: 60_000L
                            wait = reset.coerceIn(10_000L, 600_000L); info = "Rate limited; pausing refresh."
                        } else { info = errText(e); if (e.kind != ErrorKind.SERVER) break }
                    } catch (e: IOException) { offline = true; info = "Offline. Showing cached data from $lastUpdated." }
                }
                first = false
                if (run?.isActive == false) break
                delay(wait)
            }
        }
    }

    fun stop() { poll?.cancel(); dlJob?.cancel() }

    /** Returns true when something changed. */
    private suspend fun refreshOnce(): Boolean {
        val a = vm.api()
        val r = a.getRun(repo, runId, attempt, etag = true)
        val j = a.listJobs(repo, runId, attempt)
        val sig = r.status + r.conclusion + r.attempt + j.joinToString { it.id.toString() + it.status + it.conclusion + it.steps.joinToString("") { s -> s.status + s.conclusion } }
        val changed = sig != signature
        signature = sig
        run = r
        jobs.clear(); jobs.addAll(j)
        lastUpdated = nowText()
        if (r.status == "completed") {
            artifacts.clear(); artifacts.addAll(a.listArtifacts(repo, runId))
            val key = runId * 100 + r.attempt
            if (r.isFailure && errorLoadedFor != key) {
                errorLoadedFor = key
                val failed = LogAnalyzer.failedStep(j)
                if (failed != null) try {
                    val log = a.jobLog(repo, failed.first.id)
                    firstError = (failed.second?.let { "Failed step: ${it.name}\n" } ?: "") + (LogAnalyzer.firstError(log.text) ?: "No obvious error line; open the log.")
                } catch (e: ApiException) { firstError = "Failed step: ${failed.second?.name ?: failed.first.name}. Log not available: ${errText(e)}" }
            }
        }
        return changed
    }

    fun refreshNow() { start() }
    fun selectAttempt(n: Int) { attempt = n; signature = ""; firstError = null; start() }

    private fun act(label: String, block: suspend () -> Unit) = vm.op { block(); info = label; attempt = null; signature = ""; errorLoadedFor = -1; delay(1500); start() }
    fun cancelRun() = act("Cancel requested") { vm.api().cancelRun(repo, runId) }
    fun rerunAll() = act("Re-run requested") { vm.api().rerun(repo, runId) }
    fun rerunFailed() = act("Re-run of failed jobs requested") { vm.api().rerunFailed(repo, runId) }

    fun downloadArtifact(a: Artifact) {
        dlJob?.cancel()
        dlJob = vm.op {
            fetched?.let { vm.pipeline().discard(it) }; fetched = null
            try {
                fetched = vm.pipeline().fetch(repo, run, a) { done, total -> progress = "Downloading ${a.name}: ${done / 1024} KiB" + if (total > 0) " of ${total / 1024} KiB" else "" }
                vm.login?.let { l -> vm.prefs.setRepoPref(l, repo, "artifact", a.name) }
            } finally { progress = null }
        }
    }

    fun cancelDownload() { dlJob?.cancel(); progress = null }

    fun save(c: Candidate) = vm.op {
        val f = fetched ?: return@op
        val e = vm.pipeline().save(f, c)
        vm.loadHistory()
        info = "Saved ${e.apkName} to Downloads/LomipeDevHub. Open the Downloads tab to install."
    }

    fun downloadRunLogs() = vm.op {
        val tmp = File(vm.paths().cache(vm.login!!), "run-$runId-logs.zip")
        vm.api().downloadRunLogsZip(repo, runId, tmp) { d, _ -> progress = "Downloading logs: ${d / 1024} KiB" }
        progress = null
        MediaStoreSaver.saveToDownloads(vm.ctx, tmp, "run-$runId-logs.zip", "application/zip")
        tmp.delete()
        info = "Log archive saved to Downloads/LomipeDevHub."
    }
}

class LogSession(private val vm: AppViewModel, val repo: String, val jobId: Long, val title: String) {
    var text by mutableStateOf("")
    var truncated by mutableStateOf(false)
    var state by mutableStateOf("Loading log…")
    var query by mutableStateOf("")
    init {
        vm.op {
            try {
                val l = vm.api().jobLog(repo, jobId); text = l.text; truncated = l.truncated; state = ""
            } catch (e: ApiException) { state = if (e.kind == ErrorKind.NOT_FOUND) "No log yet. Logs appear after the job finishes. Go back and refresh." else errText(e) }
        }
    }
    fun matches(): List<Pair<Int, String>> = LogAnalyzer.search(text, query)
    fun export(): File { val f = File(Intents.exportDir(vm.ctx), "job-$jobId-log.txt"); f.writeText(text); return f }
}
