package com.lomipe.devhub.core

object WorkflowStudio {
    val kinds = listOf("Android / Gradle", "Flutter", "React Native", "HTML", "Python")
    fun yaml(kind: String): String {
        val steps = when(kind) {
            "Android / Gradle" -> """      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
      - run: bash ./gradlew testDebugUnitTest assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: android-apk
          path: '**/build/outputs/apk/**/*.apk'
          if-no-files-found: error"""
            "Flutter" -> """      - uses: subosito/flutter-action@v2
        with:
          channel: stable
      - run: flutter pub get
      - run: flutter build apk --debug
      - uses: actions/upload-artifact@v4
        with:
          name: flutter-apk
          path: build/app/outputs/flutter-apk/*.apk
          if-no-files-found: error"""
            "React Native" -> """      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - run: npm ci
      - run: cd android && bash ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: react-native-apk
          path: android/app/build/outputs/apk/**/*.apk
          if-no-files-found: error"""
            "HTML" -> """      - run: test -f index.html
      - uses: actions/upload-artifact@v4
        with:
          name: website
          path: |
            **/*.html
            **/*.css
            **/*.js
            **/*.png
            **/*.svg
            **/*.jpg"""
            "Python" -> """      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: python -m compileall -q .
      - uses: actions/upload-artifact@v4
        with:
          name: python-source
          path: '**/*.py'"""
            else -> error("This framework needs a project-specific workflow")
        }
        return "name: DevHub build\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  build:\n    runs-on: ubuntu-latest\n    timeout-minutes: 30\n    steps:\n      - uses: actions/checkout@v4\n$steps\n"
    }
}
