package com.lomipe.devhub.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.lomipe.devhub.core.Run

@Composable
fun H(text: String) { Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) }

@Composable
fun Note(text: String) { Text(text, style = MaterialTheme.typography.bodySmall) }

@Composable
fun Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, modifier = Modifier.padding(end = 8.dp, top = 4.dp)) { Text(text) }
}

@Composable
fun BtnO(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = Modifier.padding(end = 8.dp, top = 4.dp)) { Text(text) }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, singleLine: Boolean = true, modifier: Modifier = Modifier) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine, modifier = modifier.fillMaxWidth().padding(vertical = 4.dp))
}

@Composable
fun Mono(text: String) { SelectionContainer { Text(text, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) } }

@Composable
fun Confirm(title: String, body: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(body) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

fun statusLabel(status: String, conclusion: String?): String = if (status == "completed") (conclusion ?: "completed") else status.replace('_', ' ')

fun runLine(r: Run): String =
    "#${r.runNumber} ${statusLabel(r.status, r.conclusion)} · ${r.event} · ${r.branch ?: "?"} · ${r.headSha.take(7)}" + (if (r.attempt > 1) " · attempt ${r.attempt}" else "")

fun stepSymbol(status: String, conclusion: String?): String = when {
    status == "completed" && conclusion == "success" -> "✓"
    status == "completed" && (conclusion == "failure" || conclusion == "timed_out") -> "✗"
    status == "completed" && conclusion == "cancelled" -> "⊘"
    status == "completed" -> "–"
    status == "in_progress" -> "●"
    else -> "○"
}
