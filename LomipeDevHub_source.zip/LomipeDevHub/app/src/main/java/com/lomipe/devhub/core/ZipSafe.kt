package com.lomipe.devhub.core

import java.io.File
import java.io.IOException
import java.util.zip.CRC32
import java.util.zip.ZipFile

class UnsafeZipException(message: String) : IOException(message)
class LowDiskException(message: String) : IOException(message)

data class ExtractLimits(
    val maxEntries: Int = 5_000,
    val maxApkBytes: Long = 400L * 1024 * 1024,
    val maxTotalBytes: Long = 1024L * 1024 * 1024,
    val maxManifestBytes: Long = 1024L * 1024,
    val maxRatio: Long = 1_000,
    val minFreeBytesMargin: Long = 32L * 1024 * 1024,
)

data class ApkFile(
    val file: File, val sha256: String, val manifestSha256: String?, val manifestMatches: Boolean?, val looksSplit: Boolean,
)

class ExtractResult(val dir: File, val apks: List<ApkFile>, val manifestText: String?, val manifestName: String?, val ignoredEntries: Int)

object ZipSafe {
    private val checksumName = Regex("(?i).*(\\.sha256(sum)?(\\.txt)?|sha256sums?(\\.txt)?|checksums?(\\.txt)?)$")
    private val splitName = Regex("(?i)^(split_.*|config\\..*|.*\\.config\\..*|.*-config\\..*)\\.apk$")

    fun validateName(name: String): String {
        if (name.isEmpty()) throw UnsafeZipException("Empty entry name")
        if (name.startsWith("/") || name.contains('\\') || Regex("^[A-Za-z]:").containsMatchIn(name))
            throw UnsafeZipException("Absolute or non-portable path in ZIP: $name")
        if (name.any { it.code < 32 }) throw UnsafeZipException("Control character in ZIP entry name")
        if (name.trimEnd('/').split('/').any { it == ".." || it == "." })
            throw UnsafeZipException("Path traversal in ZIP: $name")
        return name
    }

    /**
     * Extracts only *.apk and checksum manifests into [outDir] (always created fresh, files named by the validated
     * base name – the ZIP's own paths are never used on disk). Throws before writing on unsafe archives.
     */
    fun extractApks(zip: File, outDir: File, limits: ExtractLimits = ExtractLimits(), check: () -> Unit = {}): ExtractResult {
        if (outDir.exists()) outDir.deleteRecursively()
        outDir.mkdirs()
        ZipFile(zip).use { zf ->
            val entries = zf.entries().toList()
            if (entries.size > limits.maxEntries) throw UnsafeZipException("Too many entries (${entries.size})")
            val seen = HashSet<String>()
            for (e in entries) {
                validateName(e.name)
                if (!seen.add(e.name.lowercase())) throw UnsafeZipException("Duplicate entry name: ${e.name}")
            }
            val wanted = entries.filter { !it.isDirectory }.filter {
                val base = it.name.substringAfterLast('/')
                base.endsWith(".apk", true) || checksumName.matches(base)
            }
            val baseNames = HashSet<String>()
            for (e in wanted) if (!baseNames.add(e.name.substringAfterLast('/').lowercase()))
                throw UnsafeZipException("Two entries share the file name ${e.name.substringAfterLast('/')}")
            val declared = wanted.sumOf { maxOf(0L, it.size) }
            if (declared > limits.maxTotalBytes) throw UnsafeZipException("Declared size $declared exceeds limit")
            if (outDir.usableSpace < declared + limits.minFreeBytesMargin) throw LowDiskException("Not enough free storage to extract (${declared / 1048576} MiB needed)")

            var total = 0L
            val apks = ArrayList<File>()
            var manifestText: String? = null; var manifestName: String? = null
            for (e in wanted) {
                val base = e.name.substringAfterLast('/')
                val isApk = base.endsWith(".apk", true)
                val cap = if (isApk) limits.maxApkBytes else limits.maxManifestBytes
                val target = File(outDir, base)
                var written = 0L
                val crc = CRC32()
                zf.getInputStream(e).use { input ->
                    target.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            check()
                            val n = input.read(buf); if (n < 0) break
                            written += n; total += n
                            if (written > cap) throw UnsafeZipException("Entry ${e.name} exceeds the ${cap / 1048576} MiB limit")
                            if (total > limits.maxTotalBytes) throw UnsafeZipException("Extracted data exceeds the total limit")
                            crc.update(buf, 0, n)
                            out.write(buf, 0, n)
                        }
                    }
                }
                // java.util.zip.ZipFile does NOT verify CRC-32 itself, so it is checked explicitly.
                if (e.crc != -1L && crc.value != e.crc) { target.delete(); throw IOException("CRC mismatch in ${e.name}: archive is corrupt") }
                val comp = e.compressedSize
                if (comp > 0 && written > 10L * 1024 * 1024 && written / comp > limits.maxRatio) throw UnsafeZipException("Suspicious compression ratio in ${e.name}")
                if (isApk) apks += target
                else if (manifestText == null) { manifestText = target.readText(); manifestName = base }
            }
            val files = apks.sortedBy { it.name }.map { f ->
                val sha = sha256Of(f)
                val expected = manifestText?.let { Checksums.lookup(it, f.name) }
                ApkFile(f, sha, expected, expected?.let { it.equals(sha, true) }, splitName.matches(f.name))
            }
            return ExtractResult(outDir, files, manifestText, manifestName, entries.size - wanted.size)
        }
    }
}

object Checksums {
    private val gnu = Regex("^([A-Fa-f0-9]{64})\\s+[* ]?(.+?)\\s*$")
    private val bsd = Regex("^SHA256 \\((.+)\\) = ([A-Fa-f0-9]{64})\\s*$", RegexOption.IGNORE_CASE)

    /** Exact file-name match only (path prefixes such as ./ are ignored, nothing else). */
    fun lookup(manifest: String, fileName: String): String? {
        for (line in manifest.lines()) {
            val l = line.trim()
            gnu.matchEntire(l)?.let { if (it.groupValues[2].removePrefix("./").substringAfterLast('/') == fileName) return it.groupValues[1].lowercase() }
            bsd.matchEntire(l)?.let { if (it.groupValues[1].removePrefix("./").substringAfterLast('/') == fileName) return it.groupValues[2].lowercase() }
        }
        return null
    }
}

class ArtifactFetch(val zipSha256: String, val result: ExtractResult)

/** download ZIP -> verify -> safe extract into a fresh staging dir. Caller promotes/deletes the staging dir. */
class ArtifactService(private val api: GitHubApi, private val limits: ExtractLimits = ExtractLimits()) {
    suspend fun fetch(repo: String, artifact: Artifact, workDir: File, onProgress: (Long, Long) -> Unit = { _, _ -> }): ArtifactFetch {
        val staging = File(workDir, "stage-${artifact.id}-${System.nanoTime()}")
        staging.mkdirs()
        try {
            val zip = File(staging, "artifact.zip")
            api.downloadArtifactZip(repo, artifact, zip, onProgress = onProgress)
            val zipSha = sha256Of(zip)
            val res = ZipSafe.extractApks(zip, File(staging, "apk"), limits)
            zip.delete()
            if (res.apks.isEmpty()) throw IOException("Artifact '${artifact.name}' contains no .apk file (logs-only artifact?)")
            return ArtifactFetch(zipSha, res)
        } catch (e: Throwable) {
            staging.deleteRecursively(); throw e
        }
    }
}
