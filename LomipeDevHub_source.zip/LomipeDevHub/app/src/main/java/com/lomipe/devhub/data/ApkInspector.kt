package com.lomipe.devhub.data

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import com.lomipe.devhub.core.hex
import java.io.File
import java.security.MessageDigest

data class ApkInfo(
    val packageName: String, val versionName: String?, val versionCode: Long, val minSdk: Int,
    val signerSha256: List<String>, val installedNote: String,
)

object ApkInspector {
    private fun fp(s: Signature): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).hex().chunked(2).joinToString(":").uppercase()

    @Suppress("DEPRECATION")
    fun inspect(context: Context, file: File): ApkInfo? {
        val pm = context.packageManager
        val pi = try { pm.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES) } catch (_: Exception) { null } ?: return null
        val signers = pi.signingInfo?.apkContentsSigners?.map(::fp) ?: emptyList()
        val installed = try { pm.getPackageInfo(pi.packageName, PackageManager.GET_SIGNING_CERTIFICATES) } catch (_: PackageManager.NameNotFoundException) { null } catch (_: Exception) { null }
        val note = when {
            installed == null -> "Not currently installed."
            else -> {
                val inst = installed.signingInfo?.apkContentsSigners?.map(::fp) ?: emptyList()
                val sameSigner = inst.isNotEmpty() && signers.isNotEmpty() && inst.toSet() == signers.toSet()
                val v = "installed versionCode ${installed.longVersionCode} -> ${pi.longVersionCode}"
                when {
                    inst.isEmpty() || signers.isEmpty() -> "Installed copy exists ($v); signer comparison unavailable."
                    !sameSigner -> "WARNING: signing certificate DIFFERS from the installed app. Android will refuse to update it ($v)."
                    pi.longVersionCode < installed.longVersionCode -> "Same signer, but this is a DOWNGRADE ($v)."
                    else -> "Same signer as the installed app ($v)."
                }
            }
        }
        return ApkInfo(pi.packageName, pi.versionName, pi.longVersionCode, pi.applicationInfo?.minSdkVersion ?: 0, signers, note)
    }
}
