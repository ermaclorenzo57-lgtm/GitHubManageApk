package com.lomipe.devhub.data

import com.lomipe.devhub.core.Redactor
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small non-secret event log (redacted on write) that the user can export from Settings. */
object AppLog {
    @Volatile private var file: File? = null
    fun init(dir: File) { file = File(dir, "app.log") }
    val logFile: File? get() = file

    @Synchronized fun log(message: String) {
        val f = file ?: return
        try {
            if (f.length() > 256 * 1024) f.writeText(f.readText().takeLast(64 * 1024))
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            f.appendText("$ts ${Redactor.redact(message)}\n")
        } catch (_: Exception) { }
    }
}
