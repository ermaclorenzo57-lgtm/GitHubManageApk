package com.lomipe.devhub.core

data class User(val login: String, val name: String?)

data class Repo(
    val fullName: String, val isPrivate: Boolean, val defaultBranch: String,
    val canPush: Boolean, val pushedAt: String?, val description: String?,
) { val owner get() = fullName.substringBefore('/'); val name get() = fullName.substringAfter('/') }

data class Branch(val name: String, val sha: String)

data class Workflow(val id: Long, val name: String, val path: String, val state: String)

data class Run(
    val id: Long, val runNumber: Long, val attempt: Int, val name: String, val workflowId: Long,
    val status: String, val conclusion: String?, val event: String, val branch: String?,
    val headSha: String, val commitMessage: String?, val createdAt: String?, val startedAt: String?,
    val updatedAt: String?, val htmlUrl: String,
) {
    val isActive get() = status != "completed"
    val isSuccess get() = status == "completed" && conclusion == "success"
    val isFailure get() = status == "completed" && conclusion in setOf("failure", "timed_out", "startup_failure")
}

data class Step(val number: Int, val name: String, val status: String, val conclusion: String?, val startedAt: String?, val completedAt: String?)

data class GhJob(
    val id: Long, val name: String, val status: String, val conclusion: String?,
    val startedAt: String?, val completedAt: String?, val steps: List<Step>,
) {
    /** Only meaningful when GitHub actually reported steps. */
    val completedSteps get() = steps.count { it.status == "completed" }
}

data class Artifact(
    val id: Long, val name: String, val sizeBytes: Long, val expired: Boolean, val expiresAt: String?,
    val createdAt: String?, val digest: String?, val runId: Long?, val headSha: String?,
)

data class Asset(val id: Long, val name: String, val size: Long, val state: String, val digest: String?, val updatedAt: String?)

data class Release(
    val id: Long, val tag: String, val name: String?, val draft: Boolean, val prerelease: Boolean,
    val publishedAt: String?, val htmlUrl: String, val assets: List<Asset>,
)

data class ContentEntry(val name: String, val path: String, val type: String, val size: Long, val sha: String)

data class FileContent(val path: String, val sha: String, val size: Long, val text: String?)

data class Page<T>(val items: List<T>, val hasNext: Boolean, val page: Int)

data class LogText(val text: String, val truncated: Boolean)

internal object Parse {
    fun user(o: JObj) = User(o.s("login") ?: "", o.s("name"))
    fun repo(o: JObj) = Repo(
        o.s("full_name") ?: "", o.b("private"), o.s("default_branch") ?: "main",
        o.o("permissions")?.b("push") ?: false, o.s("pushed_at"), o.s("description"),
    )
    fun workflow(o: JObj) = Workflow(o.l("id"), o.s("name") ?: "", o.s("path") ?: "", o.s("state") ?: "")
    fun run(o: JObj) = Run(
        o.l("id"), o.l("run_number"), o.l("run_attempt").toInt().coerceAtLeast(1), o.s("name") ?: o.s("display_title") ?: "",
        o.l("workflow_id"), o.s("status") ?: "unknown", o.s("conclusion"), o.s("event") ?: "", o.s("head_branch"),
        o.s("head_sha") ?: "", o.o("head_commit")?.s("message"), o.s("created_at"), o.s("run_started_at"),
        o.s("updated_at"), o.s("html_url") ?: "",
    )
    fun step(o: JObj) = Step(o.l("number").toInt(), o.s("name") ?: "", o.s("status") ?: "", o.s("conclusion"), o.s("started_at"), o.s("completed_at"))
    fun job(o: JObj) = GhJob(o.l("id"), o.s("name") ?: "", o.s("status") ?: "", o.s("conclusion"), o.s("started_at"), o.s("completed_at"), o.a("steps").map(::step))
    fun artifact(o: JObj) = Artifact(
        o.l("id"), o.s("name") ?: "", o.l("size_in_bytes"), o.b("expired"), o.s("expires_at"), o.s("created_at"),
        o.s("digest"), o.o("workflow_run")?.l("id"), o.o("workflow_run")?.s("head_sha"),
    )
    fun asset(o: JObj) = Asset(o.l("id"), o.s("name") ?: "", o.l("size"), o.s("state") ?: "", o.s("digest"), o.s("updated_at"))
    fun release(o: JObj) = Release(
        o.l("id"), o.s("tag_name") ?: "", o.s("name"), o.b("draft"), o.b("prerelease"), o.s("published_at"),
        o.s("html_url") ?: "", o.a("assets").map(::asset),
    )
    fun entry(o: JObj) = ContentEntry(o.s("name") ?: "", o.s("path") ?: "", o.s("type") ?: "", o.l("size"), o.s("sha") ?: "")
}
