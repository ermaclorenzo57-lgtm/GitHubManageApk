package com.lomipe.devhub.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.lomipe.devhub.core.*
import com.lomipe.devhub.data.*
import com.lomipe.devhub.ui.MainActivity
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Periodic (15 min minimum, system-scheduled, NOT real time) check of runs the user chose to watch.
 * Sends one notification per finished run and optionally auto-downloads a single unambiguous APK.
 */
class BuildWatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val prefs = Prefs(ctx)
        val login = prefs.activeLogin ?: return Result.success()
        val api = Services.api(ctx, login) ?: return Result.success()
        val watched = prefs.watched(login).toMutableSet()
        if (watched.isEmpty()) { WorkManager.getInstance(ctx).cancelUniqueWork(NAME); return Result.success() }
        var retry = false
        for (key in watched.toList()) {
            val repo = key.substringBefore('#')
            val id = key.substringAfter('#').toLongOrNull()
            if (id == null) { watched.remove(key); continue }
            try {
                val run = api.getRun(repo, id)
                if (run.status != "completed") continue
                val dedupe = "$key:${run.attempt}"
                var text = "${repo} run #${run.runNumber}: ${run.conclusion ?: "finished"}"
                if (run.isSuccess && prefs.autoDownload) text += " — " + autoDownload(ctx, login, api, repo, run)
                if (dedupe !in prefs.notified(login)) { notify(ctx, key.hashCode(), "Build finished", text); prefs.addNotified(login, dedupe) }
                watched.remove(key)
            } catch (e: ApiException) {
                if (e.kind == ErrorKind.RATE_LIMIT || e.kind == ErrorKind.SERVER) retry = true
                else if (e.kind == ErrorKind.AUTH || e.kind == ErrorKind.NOT_FOUND || e.kind == ErrorKind.FORBIDDEN) watched.remove(key)
                AppLog.log("watch $key: ${e.message}")
            } catch (e: IOException) { retry = true; AppLog.log("watch $key offline: ${e.message}") }
        }
        prefs.setWatched(login, watched)
        if (watched.isEmpty()) WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
        return if (retry) Result.retry() else Result.success()
    }

    private suspend fun autoDownload(ctx: Context, login: String, api: GitHubApi, repo: String, run: Run): String {
        return try {
            val prefs = Prefs(ctx)
            val arts = api.listArtifacts(repo, run.id).filter { !it.expired }
            val preferred = prefs.repoPref(login, repo, "artifact")
            val pick = arts.firstOrNull { it.name == preferred } ?: arts.singleOrNull()
                ?: return "several artifacts — open the app to choose"
            val p = ApkPipeline(ctx, login, api)
            val f = p.fetch(repo, run, pick) { _, _ -> }
            try {
                val ok = f.candidates.filter { it.installable }
                if (f.candidates.size == 1 && ok.size == 1) { val e = p.save(f, ok[0]); "saved ${e.apkName} to Downloads" }
                else "APK needs your decision (multiple, split or failed verification) — open the app"
            } finally { p.discard(f) }
        } catch (e: Exception) { "auto-download failed: ${Redactor.redact(e.message ?: "error")}" }
    }

    companion object {
        const val NAME = "lomipe_build_watch"
        private const val CHANNEL = "builds"

        fun schedule(ctx: Context, wifiOnly: Boolean) {
            val c = Constraints.Builder().setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build()
            val req = PeriodicWorkRequestBuilder<BuildWatchWorker>(15, TimeUnit.MINUTES).setConstraints(c).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun notify(ctx: Context, id: Int, title: String, text: String) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Build results", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(ctx, CHANNEL).setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(open).setAutoCancel(true).build()
            try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) { }
        }
    }
}
