package com.lomipe.devhub.core

/** Removes credentials and signed-URL secrets from any text before it is logged, shown or exported. */
object Redactor {
    private val tokenPatterns = listOf(
        Regex("github_pat_[A-Za-z0-9_]{20,}"),
        Regex("gh[pousr]_[A-Za-z0-9]{20,}"),
        Regex("(?i)(authorization:\\s*)(bearer|token|basic)\\s+\\S+"),
        Regex("(?i)\\b(bearer)\\s+[A-Za-z0-9._~+/=-]{16,}"),
    )
    private val signedQuery = Regex("(?i)(https?://[^\\s\"'<>?]+)\\?([^\\s\"'<>]*(sig=|x-amz-|token=|access_token=|se=|skoid=)[^\\s\"'<>]*)")

    fun redact(text: String): String {
        var out = text
        out = signedQuery.replace(out) { it.groupValues[1] + "?[redacted]" }
        for (p in tokenPatterns) {
            out = p.replace(out) { m -> if (m.groupValues.size > 2 && m.groupValues[1].startsWith("Auth", true)) m.groupValues[1] + "[redacted]" else "[redacted]" }
        }
        return out
    }

    fun redactUrl(url: String): String = redact(url)
}
