package com.lomipe.devhub.core

import java.io.File
import java.io.IOException
import java.security.MessageDigest

class ChecksumMismatch(message: String) : IOException(message)

fun ByteArray.hex(): String = joinToString("") { "%02x".format(it) }

fun sha256Of(file: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { s -> val b = ByteArray(64 * 1024); while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) } }
    return md.digest().hex()
}

object Downloader {
    /**
     * Streams to `<dest>.part`, checks the byte count (header and expected), checks "sha256:<hex>" digests when given,
     * then atomically renames. The .part file is removed on any failure.
     */
    suspend fun toFile(
        http: GitHubHttp, url: String, accept: String, dest: File,
        expectedSize: Long?, expectedDigest: String?, onProgress: (Long, Long) -> Unit,
    ) {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        part.delete()
        try {
            val md = MessageDigest.getInstance("SHA-256")
            val written = http.download(url, accept) { input, contentLength, check ->
                var total = 0L
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        check()
                        val n = input.read(buf); if (n < 0) break
                        out.write(buf, 0, n); md.update(buf, 0, n); total += n
                        onProgress(total, if (contentLength > 0) contentLength else expectedSize ?: -1)
                    }
                }
                if (contentLength >= 0 && total != contentLength) throw IOException("Incomplete download: got $total of $contentLength bytes")
                total
            }
            if (expectedSize != null && written != expectedSize) throw IOException("Size mismatch: got $written, expected $expectedSize")
            val digest = md.digest().hex()
            if (expectedDigest != null && expectedDigest.startsWith("sha256:", true)) {
                val want = expectedDigest.substringAfter(':').lowercase()
                if (want != digest) throw ChecksumMismatch("SHA-256 mismatch (expected $want, got $digest)")
            }
            dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not move download into place")
        } catch (e: Throwable) {
            part.delete()
            throw e
        }
    }
}
