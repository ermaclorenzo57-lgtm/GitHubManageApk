package com.lomipe.devhub.ui

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import com.lomipe.devhub.data.HistoryEntry
import java.io.File

object Intents {
    private fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

    /** Opens the system installer confirmation. Never installs silently. Returns a message when the user must act first. */
    fun install(ctx: Context, e: HistoryEntry): String? {
        val f = File(e.privatePath)
        if (!f.exists()) return "The local copy no longer exists."
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Android needs 'Install unknown apps' enabled for Lomipe DevHub. Turn it on, come back and press Install again."
        }
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri(ctx, f), "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return null
    }

    fun share(ctx: Context, f: File, mime: String) {
        val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri(ctx, f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openDownloads(ctx: Context) { ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    fun openGitHubUrl(ctx: Context, url: String) {
        if (!url.startsWith("https://github.com/")) return
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun copy(ctx: Context, label: String, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text))
    }

    fun exportDir(ctx: Context): File = File(ctx.filesDir, "exports").also { it.mkdirs() }
}
