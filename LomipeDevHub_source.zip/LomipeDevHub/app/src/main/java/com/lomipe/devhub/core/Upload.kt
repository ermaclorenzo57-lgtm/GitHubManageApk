package com.lomipe.devhub.core

import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.Base64

/** A readable file with a known size. [open] may be called more than once. */
interface UploadSource {
    val name: String
    val size: Long
    fun open(): InputStream
}

class FileSource(private val file: File, override val name: String = file.name) : UploadSource {
    override val size get() = file.length()
    override fun open(): InputStream = file.inputStream()
}

class BytesSource(override val name: String, private val bytes: ByteArray) : UploadSource {
    override val size get() = bytes.size.toLong()
    override fun open(): InputStream = ByteArrayInputStream(bytes)
}

/** The target file exists; the caller must get explicit user confirmation and retry with allowOverwrite = true. */
class OverwriteRequired(val path: String, val existingSha: String, val existingSize: Long) :
    IOException("$path already exists on the branch")

object UploadPolicy {
    /** Observed Aisya policy, not a server guarantee. Configurable in settings. */
    const val DEFAULT_COMMIT_THRESHOLD = 48L * 1024 * 1024
    /** Documented Contents API ceiling. */
    const val CONTENTS_API_MAX = 100L * 1024 * 1024
}

data class CommitResult(
    val path: String, val commitSha: String, val blobSha: String, val sha256: String,
    val blobVerified: Boolean, val replaced: Boolean,
)

data class ReleaseUploadResult(val asset: Asset, val finalName: String, val sha256: String, val sizeVerified: Boolean, val digestVerified: Boolean?)

fun gitBlobSha1(source: UploadSource): Pair<String, String> {
    val sha1 = MessageDigest.getInstance("SHA-1"); val sha256 = MessageDigest.getInstance("SHA-256")
    sha1.update("blob ${source.size}\u0000".toByteArray())
    var total = 0L
    source.open().use { s ->
        val b = ByteArray(64 * 1024)
        while (true) { val n = s.read(b); if (n < 0) break; sha1.update(b, 0, n); sha256.update(b, 0, n); total += n }
    }
    if (total != source.size) throw IOException("File size changed while reading ($total vs ${source.size})")
    return sha1.digest().hex() to sha256.digest().hex()
}

class Uploader(private val api: GitHubApi) {
    private val http get() = api.http
    private val base get() = http.policy.apiBase

    fun targetPath(dir: String, fileName: String): String {
        val d = dir.trim().trim('/')
        return validateRepoPath(if (d.isEmpty()) fileName else "$d/$fileName")
    }

    /** Commit a file to a branch with the Contents API, streaming base64 (never holds file + encoded copy in memory). */
    suspend fun commitFile(
        repo: String, branch: String, path: String, source: UploadSource, message: String,
        allowOverwrite: Boolean, expectedSha: String? = null, onProgress: (Long) -> Unit = {},
    ): CommitResult {
        validateRepoPath(path)
        require(message.isNotBlank()) { "Commit message is empty" }
        require(source.size <= UploadPolicy.CONTENTS_API_MAX) { "File exceeds the Contents API limit of 100 MiB; upload it as a release asset instead" }
        val existing = api.fileMeta(repo, path, branch)      // non-404 failures throw here
        // Edit flows pass the sha they loaded: if the file moved on GitHub meanwhile, stop instead of overwriting.
        if (expectedSha != null && existing?.sha != expectedSha)
            throw ApiException(409, ErrorKind.CONFLICT, "$path changed on GitHub since you opened it. Reload it and re-apply your edit.")
        if (existing != null && !allowOverwrite) throw OverwriteRequired(path, existing.sha, existing.size)

        val (blobSha, sha256) = gitBlobSha1(source)
        val prefixObj = LinkedHashMap<String, Any?>()
        prefixObj["message"] = message; prefixObj["branch"] = branch
        if (existing != null) prefixObj["sha"] = existing.sha
        // Build JSON up to the content value, then stream the base64 and close.
        val head = Json.write(prefixObj).dropLast(1) + ",\"content\":\""
        val headBytes = head.toByteArray(); val tailBytes = "\"}".toByteArray()
        val b64Len = 4L * ((source.size + 2) / 3)
        val length = headBytes.size + b64Len + tailBytes.size

        val writer: BodyWriter = { out, check ->
            out.write(headBytes)
            val enc = Base64.getEncoder()
            val chunk = ByteArray(3 * 16 * 1024)
            var sent = 0L
            source.open().use { s ->
                while (true) {
                    check()
                    val n = readFully(s, chunk); if (n <= 0) break
                    out.write(enc.encode(if (n == chunk.size) chunk else chunk.copyOf(n)))
                    sent += n; onProgress(sent)
                    if (n < chunk.size) break
                }
            }
            out.write(tailBytes)
        }
        val resp = http.send("PUT", "$base/repos/${checkRepo(repo)}/contents/${encodeRepoPath(path)}",
            contentType = "application/json", length = length, body = writer, readTimeoutMs = 180_000)
        val o = resp.json().asObj() ?: throw IOException("Unexpected response")
        val remoteBlob = o.o("content")?.s("sha") ?: ""
        val commit = o.o("commit")?.s("sha") ?: ""
        return CommitResult(path, commit, remoteBlob, sha256, remoteBlob.equals(blobSha, true), existing != null)
    }

    private fun readFully(s: InputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) { val n = s.read(buf, off, buf.size - off); if (n < 0) break; off += n }
        return off
    }

    /** Picks a name that does not collide with an existing asset (never deletes anything). */
    fun uniqueAssetName(name: String, existing: Collection<String>, stamp: String): String {
        if (name !in existing) return name
        val dot = name.lastIndexOf('.')
        val (stem, ext) = if (dot > 0) name.substring(0, dot) to name.substring(dot) else name to ""
        var candidate = "$stem-$stamp$ext"; var i = 2
        while (candidate in existing) candidate = "$stem-$stamp-${i++}$ext"
        return candidate
    }

    suspend fun uploadReleaseAsset(repo: String, release: Release, source: UploadSource, assetName: String, onProgress: (Long) -> Unit): Asset {
        val result = uploadReleaseAssetChecked(repo, release, source, assetName, onProgress)
        return result.asset
    }

    suspend fun uploadReleaseAssetChecked(
        repo: String, release: Release, source: UploadSource, requestedName: String, onProgress: (Long) -> Unit,
        stamp: String = java.time.format.DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(java.time.LocalDateTime.now()),
    ): ReleaseUploadResult {
        val existing = api.listAssets(repo, release.id).map { it.name }
        val finalName = uniqueAssetName(requestedName, existing, stamp)
        val (_, sha256) = gitBlobSha1(source)
        val writer: BodyWriter = { out: OutputStream, check ->
            var sent = 0L
            source.open().use { s ->
                val b = ByteArray(64 * 1024)
                while (true) { check(); val n = s.read(b); if (n < 0) break; out.write(b, 0, n); sent += n; onProgress(sent) }
            }
        }
        val url = "${http.policy.uploadsBase}/repos/${checkRepo(repo)}/releases/${release.id}/assets?name=${encodeSegment(finalName)}"
        val resp = http.send("POST", url, contentType = ACCEPT_OCTET, length = source.size, body = writer, readTimeoutMs = 300_000)
        val asset = Parse.asset(resp.json().asObj() ?: throw IOException("Unexpected response"))
        val sizeOk = asset.size == source.size
        val digestOk = asset.digest?.takeIf { it.startsWith("sha256:", true) }?.let { it.substringAfter(':').equals(sha256, true) }
        return ReleaseUploadResult(asset, finalName, sha256, sizeOk, digestOk)
    }
}

/** Associates a freshly pushed commit with workflow runs, without guessing. */
object RunCorrelator {
    sealed class Match {
        data class Single(val run: Run) : Match()
        data class Ambiguous(val candidates: List<Run>) : Match()
        object None : Match()
    }

    fun correlate(runs: List<Run>, headSha: String, event: String, branch: String?, workflowId: Long? = null): Match {
        val c = runs.filter {
            it.headSha.equals(headSha, true) && it.event == event &&
                (branch == null || it.branch == branch) && (workflowId == null || it.workflowId == workflowId)
        }.distinctBy { it.id }
        return when (c.size) { 0 -> Match.None; 1 -> Match.Single(c[0]); else -> Match.Ambiguous(c.sortedByDescending { it.runNumber }) }
    }

    /** For workflow_dispatch: runs created at/after the dispatch time on the ref. */
    fun correlateDispatch(runs: List<Run>, ref: String, workflowId: Long, notBeforeIso: String): Match {
        val c = runs.filter { it.event == "workflow_dispatch" && it.workflowId == workflowId && it.branch == ref && (it.createdAt ?: "") >= notBeforeIso }
        return when (c.size) { 0 -> Match.None; 1 -> Match.Single(c[0]); else -> Match.Ambiguous(c.sortedByDescending { it.runNumber }) }
    }
}
