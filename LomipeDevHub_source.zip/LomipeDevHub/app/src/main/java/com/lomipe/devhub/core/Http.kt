package com.lomipe.devhub.core

import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

enum class ErrorKind { AUTH, FORBIDDEN, NOT_FOUND, CONFLICT, VALIDATION, RATE_LIMIT, TOO_LARGE, SERVER, OTHER }

class ApiException(val code: Int, val kind: ErrorKind, message: String, val resetEpochSeconds: Long? = null) : IOException(message)

class HttpPolicy(
    val apiBase: String = "https://api.github.com",
    val uploadsBase: String = "https://uploads.github.com",
    /** Only tests turn this off (local mock server). */
    val requireHttps: Boolean = true,
)

class Resp(val code: Int, val headers: Map<String, String>, val body: ByteArray) {
    val text: String get() = String(body, Charsets.UTF_8)
    fun json(): Any? = Json.parse(text)
    fun hasNext(): Boolean = headers["link"]?.contains("rel=\"next\"") == true
}

typealias BodyWriter = (OutputStream, () -> Unit) -> Unit

const val ACCEPT_JSON = "application/vnd.github+json"
const val ACCEPT_RAW = "application/vnd.github.raw+json"
const val ACCEPT_OCTET = "application/octet-stream"

/**
 * Minimal HTTPS client. Rules enforced here:
 *  - only api.github.com / uploads.github.com (from [HttpPolicy]) receive the Authorization header;
 *  - redirects (GET only) are followed manually and the header is dropped for any other host;
 *  - nothing is logged; error messages are redacted.
 */
class GitHubHttp(
    private val token: () -> String,
    val policy: HttpPolicy = HttpPolicy(),
    private val userAgent: String = "LomipeDevHub",
) {
    private val trustedHosts = setOf(URL(policy.apiBase).host, URL(policy.uploadsBase).host)
    private val etags = object : LinkedHashMap<String, Pair<String, ByteArray>>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Pair<String, ByteArray>>) = size > 64
    }

    private class Holder { @Volatile var c: HttpURLConnection? = null }

    private fun parse(url: String): URL {
        val u = URL(url)
        require(!policy.requireHttps || u.protocol == "https") { "HTTPS is required" }
        return u
    }

    private fun trusted(u: URL) = u.host in trustedHosts

    private fun open(method: String, u: URL, accept: String, auth: Boolean, contentType: String?, readTimeout: Int): HttpURLConnection {
        val c = u.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = false
        c.connectTimeout = 20_000
        c.readTimeout = readTimeout
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("User-Agent", userAgent)
        if (auth) {
            c.setRequestProperty("Authorization", "Bearer " + token())
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        if (contentType != null) c.setRequestProperty("Content-Type", contentType)
        return c
    }

    private suspend fun <T> cancellable(h: Holder, block: (() -> Unit) -> T): T = coroutineScope {
        val job = coroutineContext[Job]!!
        val watcher = launch(Dispatchers.Default) { try { awaitCancellation() } finally { h.c?.disconnect() } }
        try {
            withContext(Dispatchers.IO) { block { job.ensureActive() } }
        } catch (e: IOException) {
            job.ensureActive()   // a disconnect caused by cancellation surfaces as CancellationException, not as an I/O error
            throw e
        } finally { watcher.cancel() }
    }

    private fun headersOf(c: HttpURLConnection): Map<String, String> {
        val m = HashMap<String, String>()
        for ((k, v) in c.headerFields) if (k != null && v.isNotEmpty()) m[k.lowercase()] = v[0]
        return m
    }

    private fun readAll(s: InputStream?, cap: Int, check: () -> Unit): ByteArray {
        if (s == null) return ByteArray(0)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(32 * 1024)
        s.use {
            while (true) {
                check()
                val n = it.read(buf); if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > cap) throw IOException("Response larger than ${cap / 1024 / 1024} MiB")
            }
        }
        return out.toByteArray()
    }

    fun toException(code: Int, headers: Map<String, String>, body: String): ApiException {
        val msg = try { Json.parse(body).asObj()?.s("message") } catch (_: Exception) { null } ?: body.take(200)
        val clean = Redactor.redact(msg)
        val reset = headers["x-ratelimit-reset"]?.toLongOrNull()
        return when {
            code == 401 -> ApiException(code, ErrorKind.AUTH, "GitHub rejected the token (expired, revoked or wrong). $clean")
            code == 403 && headers["x-github-sso"] != null -> ApiException(code, ErrorKind.FORBIDDEN, "SAML SSO authorization required for this token. $clean")
            code == 403 && (headers["x-ratelimit-remaining"] == "0" || clean.contains("rate limit", true)) ->
                ApiException(code, ErrorKind.RATE_LIMIT, "GitHub rate limit reached. $clean", reset)
            code == 429 -> ApiException(code, ErrorKind.RATE_LIMIT, "GitHub rate limit reached. $clean", reset)
            code == 403 -> ApiException(code, ErrorKind.FORBIDDEN, "Token lacks permission for this action. $clean")
            code == 404 -> ApiException(code, ErrorKind.NOT_FOUND, "Not found (or the token cannot see it). $clean")
            code == 409 -> ApiException(code, ErrorKind.CONFLICT, "Conflict: the remote changed. $clean")
            code == 413 -> ApiException(code, ErrorKind.TOO_LARGE, "File too large for this endpoint. $clean")
            code == 422 -> ApiException(code, ErrorKind.VALIDATION, "GitHub rejected the request: $clean")
            code >= 500 -> ApiException(code, ErrorKind.SERVER, "GitHub server error ($code). $clean")
            else -> ApiException(code, ErrorKind.OTHER, "HTTP $code: $clean")
        }
    }

    /**
     * Core request loop. [consume] runs once the final (non-redirect) response is available.
     */
    private suspend fun <T> exec(
        method: String, url: String, accept: String, contentType: String?, length: Long, body: BodyWriter?,
        readTimeout: Int, etag: Boolean, consume: (HttpURLConnection, Int, () -> Unit) -> T,
    ): T {
        val first = parse(url)
        require(trusted(first)) { "Refusing to send credentials to host ${first.host}" }
        val h = Holder()
        return cancellable(h) { check ->
            var u = first
            var hops = 0
            while (true) {
                val isTrusted = trusted(u)
                val c = open(method, u, accept, isTrusted, contentType, readTimeout)
                h.c = c
                if (etag && method == "GET" && isTrusted) etags[u.toString()]?.let { c.setRequestProperty("If-None-Match", it.first) }
                try {
                    if (body != null) {
                        c.doOutput = true
                        if (length >= 0) c.setFixedLengthStreamingMode(length) else c.setChunkedStreamingMode(64 * 1024)
                        c.outputStream.use { body(it, check) }
                    } else if (method == "POST" || method == "PUT") {
                        c.doOutput = true
                        c.setFixedLengthStreamingMode(0L)
                        c.outputStream.close()
                    }
                    val code = c.responseCode
                    if (method == "GET" && code in intArrayOf(301, 302, 303, 307, 308)) {
                        val loc = c.getHeaderField("Location") ?: throw IOException("Redirect without Location")
                        c.disconnect()
                        if (++hops > 5) throw IOException("Too many redirects")
                        u = parse(URL(u, loc).toString())   // Authorization is re-evaluated per host in open()
                        continue
                    }
                    return@cancellable consume(c, code, check)
                } catch (e: ApiException) {
                    throw e
                } catch (e: IOException) {
                    throw IOException(Redactor.redact(e.message ?: e.javaClass.simpleName), e)
                }
            }
            @Suppress("UNREACHABLE_CODE") throw IllegalStateException()
        }
    }

    suspend fun send(
        method: String, url: String, accept: String = ACCEPT_JSON, contentType: String? = null,
        length: Long = -1, body: BodyWriter? = null, readTimeoutMs: Int = 60_000, etag: Boolean = false,
        maxBytes: Int = 32 * 1024 * 1024, okCodes: Set<Int> = emptySet(),
    ): Resp = exec(method, url, accept, contentType, length, body, readTimeoutMs, etag) { c, code, check ->
        val headers = headersOf(c)
        val key = c.url.toString()
        if (code == 304) {
            val cached = etags[key] ?: throw IOException("304 without cache")
            c.disconnect()
            return@exec Resp(200, headers, cached.second)
        }
        val bytes = readAll(if (code >= 400) c.errorStream else c.inputStream, maxBytes, check)
        c.disconnect()
        if (code >= 400 && code !in okCodes) throw toException(code, headers, String(bytes, Charsets.UTF_8))
        if (etag && code == 200) headers["etag"]?.let { etags[key] = it to bytes }
        Resp(code, headers, bytes)
    }

    suspend fun getJson(url: String, etag: Boolean = false): Resp = send("GET", url, etag = etag)

    /** Streams a GET (following redirects without credentials) into [sink]. */
    suspend fun <T> download(url: String, accept: String = ACCEPT_JSON, sink: (InputStream, Long, () -> Unit) -> T): T =
        exec("GET", url, accept, null, -1, null, 120_000, false) { c, code, check ->
            val headers = headersOf(c)
            if (code >= 400) {
                val b = readAll(c.errorStream, 64 * 1024, check)
                c.disconnect()
                throw toException(code, headers, String(b, Charsets.UTF_8))
            }
            try { sink(c.inputStream, c.contentLengthLong, check) } finally { c.disconnect() }
        }
}
