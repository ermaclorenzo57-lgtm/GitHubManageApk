package com.lomipe.devhub.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Tokens are encrypted with an AES-256-GCM key that lives in the Android Keystore (never exported).
 * The account login is bound as AAD so a blob cannot be swapped between accounts.
 * Only the ciphertext is stored in app-private SharedPreferences, which are excluded from backup.
 */
class SecureTokenStore(context: Context) {
    private val sp = context.getSharedPreferences("secure_tokens", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun put(login: String, token: String) {
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key())
        c.updateAAD(login.lowercase().toByteArray())
        val ct = c.doFinal(token.toByteArray(Charsets.UTF_8))
        val enc = Base64.getEncoder()
        sp.edit().putString(PREFIX + login.lowercase(), enc.encodeToString(c.iv) + ":" + enc.encodeToString(ct)).apply()
    }

    fun get(login: String): String? {
        val raw = sp.getString(PREFIX + login.lowercase(), null) ?: return null
        return try {
            val (iv, ct) = raw.split(":").let { Base64.getDecoder().decode(it[0]) to Base64.getDecoder().decode(it[1]) }
            val c = Cipher.getInstance(TRANSFORM)
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            c.updateAAD(login.lowercase().toByteArray())
            String(c.doFinal(ct), Charsets.UTF_8)
        } catch (_: Exception) {
            null   // key invalidated / data corrupt: treated as "signed out"
        }
    }

    fun remove(login: String) { sp.edit().remove(PREFIX + login.lowercase()).apply() }

    fun logins(): List<String> = sp.all.keys.filter { it.startsWith(PREFIX) }.map { it.removePrefix(PREFIX) }.sorted()

    private companion object {
        const val ALIAS = "lomipe_devhub_token_key"
        const val TRANSFORM = "AES/GCM/NoPadding"
        const val PREFIX = "t_"
    }
}
