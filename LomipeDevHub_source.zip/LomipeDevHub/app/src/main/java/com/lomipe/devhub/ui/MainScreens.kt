package com.lomipe.devhub.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lomipe.devhub.core.Run
import com.lomipe.devhub.data.AppLog
import com.lomipe.devhub.data.HistoryEntry

@Composable
fun RunRow(repo: String, r: Run, vm: AppViewModel) {
    Column(Modifier.fillMaxWidth().clickable { vm.openRun(repo, r.id) }.padding(vertical = 8.dp)) {
        Text(repo + "  " + r.name, style = MaterialTheme.typography.bodyLarge)
        Text(runLine(r), style = MaterialTheme.typography.bodySmall)
        r.commitMessage?.let { Text(it.lines().first(), style = MaterialTheme.typography.bodySmall) }
    }
    HorizontalDivider()
}

@Composable
fun HomeScreen(vm: AppViewModel) = Page {
    Text("Signed in as ${vm.login}", style = MaterialTheme.typography.titleLarge)
    Row { BtnO("Refresh") { vm.refreshHome() }; BtnO("Repositories") { vm.tab = 1 } }
    vm.homeNote?.let { Note(it) }
    vm.homeUpdated?.let { Note("Updated $it") }
    H("Pinned repositories")
    if (vm.pinned.isEmpty()) Note("Pin repositories in the Repos tab to see their latest builds here.")
    for (r in vm.pinned.sorted()) {
        val latest = vm.homeRuns.firstOrNull { it.first == r }?.second
        Column(Modifier.fillMaxWidth().clickable { vm.openRepo(r) }.padding(vertical = 6.dp)) {
            Text(r, style = MaterialTheme.typography.bodyLarge)
            Text(latest?.let { runLine(it) } ?: "No runs found", style = MaterialTheme.typography.bodySmall)
        }
    }
    H("Recent failures")
    val failed = vm.homeRuns.filter { it.second.isFailure }.take(5)
    if (failed.isEmpty()) Note("None in the latest runs of pinned repositories.")
    failed.forEach { (repo, run) -> RunRow(repo, run, vm) }
    H("Active builds")
    val active = vm.homeRuns.filter { it.second.isActive }
    if (active.isEmpty()) Note("No active builds.")
    active.forEach { (repo, run) -> RunRow(repo, run, vm) }
    H("Latest downloads")
    if (vm.history.isEmpty()) Note("No APKs downloaded yet.")
    vm.history.take(3).forEach { Note("${it.apkName} (${it.repo}, run ${it.runId})") }
}

@Composable
fun ReposScreen(vm: AppViewModel) = Page {
    Field("Search repositories", vm.repoQuery, { vm.repoQuery = it })
    Row { BtnO("Reload") { vm.loadRepos(true) } }
    if (vm.reposLoaded && vm.repos.isEmpty()) Note("No repositories visible to this token. Check the token's repository access.")
    vm.filteredRepos().forEach { r ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.weight(1f).clickable { vm.openRepo(r.fullName) }) {
                Text(r.fullName + if (r.isPrivate) "  (private)" else "", style = MaterialTheme.typography.bodyLarge)
                Text("default: ${r.defaultBranch}" + if (!r.canPush) " · read-only" else "", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { vm.togglePin(r.fullName) }) { Text(if (r.fullName in vm.pinned) "Unpin" else "Pin") }
        }
        HorizontalDivider()
    }
    if (vm.reposHasNext) BtnO("Load more") { vm.loadRepos(false) }
    if (!vm.reposHasNext && vm.repoQuery.isNotBlank()) Note("Search covers loaded repositories only. Use Load more if needed.")
}

@Composable
fun BuildsScreen(vm: AppViewModel) = Page {
    Row { BtnO("Refresh") { vm.refreshHome() } }
    vm.homeNote?.let { Note(it) }
    if (vm.pinned.isEmpty()) Note("Pin repositories to follow their builds here.")
    vm.homeRuns.forEach { (repo, run) -> RunRow(repo, run, vm) }
}

@Composable
fun DownloadsScreen(vm: AppViewModel) = Page {
    val ctx = LocalContext.current
    var toDelete by remember { mutableStateOf<HistoryEntry?>(null) }
    Row { BtnO("Open Downloads") { Intents.openDownloads(ctx) }; BtnO("Reload") { vm.loadHistory() } }
    if (vm.history.isEmpty()) Note("Nothing downloaded yet. Open a successful run and download its APK artifact.")
    vm.history.forEach { e ->
        Column(Modifier.padding(vertical = 8.dp)) {
            Text(e.apkName, style = MaterialTheme.typography.bodyLarge)
            Note("${e.repo} · run ${e.runId} attempt ${e.attempt} · commit ${e.commit.take(7)} · ${e.size / 1024} KiB")
            Note("${e.packageName ?: "unknown package"} ${e.versionName ?: ""} (code ${e.versionCode})")
            Note("SHA-256 ${e.sha256} (" + (if (e.hashSource == "manifest-verified") "matches checksum file in artifact" else "calculated locally; no checksum file entry to compare") + ")")
            if (e.note.isNotBlank()) Note(e.note)
            Row {
                Btn("Install", enabled = e.validation == "ready") { Intents.install(ctx, e)?.let { vm.message = it } }
                BtnO("Share") { Intents.share(ctx, java.io.File(e.privatePath), "application/vnd.android.package-archive") }
                BtnO("Delete") { toDelete = e }
            }
        }
        HorizontalDivider()
    }
    toDelete?.let { e ->
        Confirm("Delete ${e.apkName}?", "Removes the app's copy and the file in Downloads/LomipeDevHub.", "Delete", { vm.deleteDownload(e); toDelete = null }, { toDelete = null })
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) = Page {
    val ctx = LocalContext.current
    var token by remember { mutableStateOf("") }
    H("GitHub account")
    Note("Use a fine-grained token limited to the repositories you manage. Needed permissions: Contents (read/write), Actions (read/write), Metadata (read). Add Workflows (write) only if you upload files under .github/workflows. Classic tokens need the 'repo' scope (and 'workflow' for workflow files). The token is stored encrypted with the Android Keystore and is never shown again.")
    OutlinedTextField(value = token, onValueChange = { token = it }, label = { Text("Personal access token") }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
    Row { Btn("Validate and save") { vm.signIn(token); token = "" } }
    vm.accounts.forEach { a ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
            Text(a + if (a.equals(vm.login, true)) "  (active)" else "", Modifier.weight(1f))
            if (!a.equals(vm.login, true)) TextButton(onClick = { vm.switchTo(a) }) { Text("Switch") }
            TextButton(onClick = { vm.signOut(a) }) { Text("Sign out") }
        }
    }
    Note("Sign out removes the token from this phone only. To revoke it on GitHub, delete it in GitHub → Settings → Developer settings.")
    H("Appearance")
    Row { listOf("system", "light", "dark").forEach { m -> if (vm.theme == m) Btn(m) { vm.setTheme(m) } else BtnO(m) { vm.setTheme(m) } } }
    H("Behaviour")
    Row(Modifier.fillMaxWidth()) { Text("Wi-Fi only for background work", Modifier.weight(1f)); Switch(checked = vm.wifiOnly, onCheckedChange = { vm.setWifi(it) }) }
    Row(Modifier.fillMaxWidth()) { Text("Auto-download APK of watched builds", Modifier.weight(1f)); Switch(checked = vm.autoDownload, onCheckedChange = { vm.setAuto(it) }) }
    Row { Text("Refresh every ${vm.refreshSeconds}s while a run screen is open", Modifier.weight(1f)); BtnO("-") { vm.setRefresh(vm.refreshSeconds - 1) }; BtnO("+") { vm.setRefresh(vm.refreshSeconds + 1) } }
    Row { Text("Warn above ${vm.commitThresholdMiB} MiB for commit uploads", Modifier.weight(1f)); BtnO("-") { vm.setThreshold(vm.commitThresholdMiB - 4) }; BtnO("+") { vm.setThreshold(vm.commitThresholdMiB + 4) } }
    Field("Default branch (optional, used if it exists)", vm.defaultBranch, { vm.setDefaultBranch(it) })
    H("Storage and diagnostics")
    Row {
        BtnO("Clear cache") { vm.clearCache() }
        BtnO("Export log") { AppLog.logFile?.takeIf { it.exists() }?.let { f ->
            val out = java.io.File(Intents.exportDir(ctx), "lomipe-devhub-log.txt"); f.copyTo(out, overwrite = true); Intents.share(ctx, out, "text/plain") } ?: run { vm.message = "No log yet." } }
    }
    Note("Lomipe DevHub 1.0.0. The log is redacted (tokens and signed URLs removed).")
}
