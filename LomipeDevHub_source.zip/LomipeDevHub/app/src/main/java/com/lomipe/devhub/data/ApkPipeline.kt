package com.lomipe.devhub.data

import android.content.Context
import com.lomipe.devhub.core.*
import java.io.File
import java.io.IOException
import java.util.UUID

class Candidate(val apk: ApkFile, val info: ApkInfo?) {
    /** Why saving/installing is discouraged or blocked. */
    val blocker: String? get() = when {
        apk.manifestMatches == false -> "SHA-256 does NOT match the checksum file in the artifact. Do not use this APK."
        else -> null
    }
    val warnings: List<String> get() = buildList {
        if (apk.looksSplit) add("Looks like a split APK; it cannot be installed on its own.")
        if (info == null) add("Android could not read this APK's manifest (corrupt, or a split package).")
        if (apk.manifestMatches == null) add("No checksum entry for this exact file name; the hash below is only locally calculated.")
        if (info != null && info.signerSha256.isEmpty()) add("Signing certificate could not be read.")
    }
    val installable: Boolean get() = blocker == null && info != null && !apk.looksSplit
}

class Fetched(val repo: String, val run: Run?, val artifact: Artifact, val zipSha256: String, val staging: File, val candidates: List<Candidate>, val manifestName: String?)

/** artifact -> staging -> inspection -> (user choice) -> Downloads + private copy + history. */
class ApkPipeline(private val context: Context, private val login: String, private val api: GitHubApi) {
    private val paths = Services.paths(context)
    private val history = HistoryStore(paths.history(login))

    fun history(): List<HistoryEntry> = history.load()

    suspend fun fetch(repo: String, run: Run?, artifact: Artifact, onProgress: (Long, Long) -> Unit): Fetched {
        val work = paths.cache(login)
        if (artifact.sizeBytes > 0 && work.usableSpace < artifact.sizeBytes * 3) throw LowDiskException("Not enough free storage for a ${artifact.sizeBytes / 1048576} MiB artifact")
        val f = ArtifactService(api).fetch(repo, artifact, work, onProgress)
        val cands = f.result.apks.map { Candidate(it, ApkInspector.inspect(context, it.file)) }
        return Fetched(repo, run, artifact, f.zipSha256, f.result.dir.parentFile!!, cands, f.result.manifestName)
    }

    fun discard(f: Fetched) { f.staging.deleteRecursively() }

    fun save(f: Fetched, c: Candidate): HistoryEntry {
        c.blocker?.let { throw IOException(it) }
        val dir = paths.downloads(login)
        var name = c.apk.file.name
        if (File(dir, name).exists()) name = name.removeSuffix(".apk") + "-" + System.currentTimeMillis() + ".apk"
        val priv = File(dir, name)
        c.apk.file.copyTo(priv)
        // re-verify the private copy so a bad disk write cannot be recorded as "verified"
        if (sha256Of(priv) != c.apk.sha256) { priv.delete(); throw IOException("Copy verification failed") }
        val uri = try { MediaStoreSaver.saveToDownloads(context, priv, name, "application/vnd.android.package-archive") }
        catch (e: Exception) { priv.delete(); throw e }
        val e = HistoryEntry(
            UUID.randomUUID().toString(), f.repo, f.run?.id ?: 0, f.run?.attempt ?: 0, f.run?.headSha ?: f.artifact.headSha ?: "",
            f.artifact.id, f.artifact.name, name, priv.length(), c.apk.sha256,
            if (c.apk.manifestMatches == true) "manifest-verified" else "locally-calculated",
            c.info?.packageName, c.info?.versionName, c.info?.versionCode ?: 0, c.info?.signerSha256?.firstOrNull(),
            if (c.installable) "ready" else "not-installable", uri.toString(), priv.absolutePath, System.currentTimeMillis(),
            (c.warnings + listOfNotNull(c.info?.installedNote)).joinToString(" "),
        )
        history.add(e)
        AppLog.log("Saved ${e.apkName} (${e.size} bytes) from ${e.repo} run ${e.runId}")
        return e
    }

    fun delete(e: HistoryEntry) {
        File(e.privatePath).delete()
        MediaStoreSaver.delete(context, e.savedUri)
        history.remove(e.id)
    }
}

/** Release-asset variant of [ApkPipeline.fetch]: authenticated API download of one .apk asset into staging. */
suspend fun ApkPipeline.fetchAsset(context: Context, login: String, api: GitHubApi, repo: String, asset: Asset, onProgress: (Long, Long) -> Unit): Fetched {
    val work = Services.paths(context).cache(login)
    if (asset.size > 0 && work.usableSpace < asset.size * 2) throw LowDiskException("Not enough free storage for ${asset.size / 1048576} MiB")
    val staging = File(work, "stage-asset-${asset.id}-${System.nanoTime()}").also { it.mkdirs() }
    try {
        require(asset.name.endsWith(".apk", true)) { "Only .apk assets can be verified here" }
        require(!asset.name.contains('/') && !asset.name.contains('\\') && asset.name != "..") { "Unsafe asset name" }
        val dir = File(staging, "apk").also { it.mkdirs() }
        val f = File(dir, asset.name)
        api.downloadAsset(repo, asset, f, onProgress)
        val sha = sha256Of(f)
        val apk = ApkFile(f, sha, null, null, false)
        val art = Artifact(asset.id, asset.name, asset.size, false, null, null, asset.digest, null, null)
        return Fetched(repo, null, art, sha, staging, listOf(Candidate(apk, ApkInspector.inspect(context, f))), null)
    } catch (e: Throwable) { staging.deleteRecursively(); throw e }
}
