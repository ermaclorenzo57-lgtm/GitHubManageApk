package com.lomipe.devhub.core

import java.io.File

/** Every account gets its own directory tree so caches/history never mix. */
class AccountPaths(private val root: File) {
    private fun safe(login: String) = login.lowercase().replace(Regex("[^a-z0-9_-]"), "_").ifEmpty { "unknown" }
    fun dir(login: String): File = File(root, "acct_${safe(login)}").also { it.mkdirs() }
    fun cache(login: String): File = File(dir(login), "cache").also { it.mkdirs() }
    fun downloads(login: String): File = File(dir(login), "downloads").also { it.mkdirs() }
    fun history(login: String): File = File(dir(login), "history.json")
    fun uploads(login: String): File = File(dir(login), "uploads.json")
}

data class UploadRecord(
    val id: String, val repo: String, val branch: String, val dir: String, val mode: String, val uri: String,
    val name: String, val size: Long, val message: String, val state: String, val detail: String,
)

/** Pending/finished uploads survive process recreation; anything left in "running" is shown as interrupted. */
class UploadQueueStore(private val file: File) {
    fun load(): List<UploadRecord> {
        if (!file.exists()) return emptyList()
        return try {
            Json.parse(file.readText()).asList().mapNotNull { it.asObj() }.map {
                val st = it.s("state") ?: "failed"
                UploadRecord(it.s("id") ?: "", it.s("repo") ?: "", it.s("branch") ?: "", it.s("dir") ?: "", it.s("mode") ?: "commit",
                    it.s("uri") ?: "", it.s("name") ?: "", it.l("size"), it.s("message") ?: "",
                    if (st == "running") "interrupted" else st, it.s("detail") ?: "")
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(list: List<UploadRecord>) {
        val tmp = File(file.path + ".tmp")
        tmp.writeText(Json.write(list.takeLast(100).map {
            mapOf("id" to it.id, "repo" to it.repo, "branch" to it.branch, "dir" to it.dir, "mode" to it.mode, "uri" to it.uri,
                "name" to it.name, "size" to it.size, "message" to it.message, "state" to it.state, "detail" to Redactor.redact(it.detail))
        }))
        if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
    }
}
