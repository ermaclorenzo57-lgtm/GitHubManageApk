package com.lomipe.devhub.data

import android.content.Context

/** Non-secret settings and per-account bookkeeping. Never holds tokens. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var activeLogin: String?
        get() = sp.getString("active_login", null)
        set(v) { sp.edit().putString("active_login", v).apply() }
    var theme: String                       // system | light | dark
        get() = sp.getString("theme", "system") ?: "system"
        set(v) { sp.edit().putString("theme", v).apply() }
    var wifiOnly: Boolean
        get() = sp.getBoolean("wifi_only", false)
        set(v) { sp.edit().putBoolean("wifi_only", v).apply() }
    var autoDownload: Boolean
        get() = sp.getBoolean("auto_download", false)
        set(v) { sp.edit().putBoolean("auto_download", v).apply() }
    var refreshSeconds: Int
        get() = sp.getInt("refresh_s", 8).coerceIn(5, 60)
        set(v) { sp.edit().putInt("refresh_s", v.coerceIn(5, 60)).apply() }
    var commitThresholdMiB: Int
        get() = sp.getInt("commit_threshold_mib", 48).coerceIn(1, 100)
        set(v) { sp.edit().putInt("commit_threshold_mib", v.coerceIn(1, 100)).apply() }
    var defaultBranch: String
        get() = sp.getString("default_branch", "") ?: ""
        set(v) { sp.edit().putString("default_branch", v.trim()).apply() }

    private fun k(login: String, name: String) = "${login.lowercase()}|$name"

    fun pinned(login: String): Set<String> = sp.getStringSet(k(login, "pins"), emptySet()) ?: emptySet()
    fun setPinned(login: String, repos: Set<String>) { sp.edit().putStringSet(k(login, "pins"), repos.toSet()).apply() }

    fun repoPref(login: String, repo: String, name: String): String? = sp.getString(k(login, "$repo|$name"), null)
    fun setRepoPref(login: String, repo: String, name: String, value: String?) { sp.edit().putString(k(login, "$repo|$name"), value).apply() }

    /** "owner/repo#runId" entries that the background worker should check. */
    fun watched(login: String): Set<String> = sp.getStringSet(k(login, "watched"), emptySet()) ?: emptySet()
    fun setWatched(login: String, v: Set<String>) { sp.edit().putStringSet(k(login, "watched"), v.toSet()).apply() }

    fun notified(login: String): Set<String> = sp.getStringSet(k(login, "notified"), emptySet()) ?: emptySet()
    fun addNotified(login: String, key: String) {
        val cur = notified(login).toMutableSet(); cur += key
        sp.edit().putStringSet(k(login, "notified"), cur.toList().takeLast(200).toSet()).apply()
    }
}
