package com.lomipe.devhub.data

import android.content.Context
import com.lomipe.devhub.core.AccountPaths
import com.lomipe.devhub.core.GitHubApi
import com.lomipe.devhub.core.GitHubHttp

/** Builds per-account API clients. The token is read from the Keystore on each request and never cached in a field of the UI. */
object Services {
    private val apis = HashMap<String, GitHubApi>()

    fun paths(context: Context) = AccountPaths(context.filesDir)

    @Synchronized fun api(context: Context, login: String): GitHubApi? {
        val key = login.lowercase()
        apis[key]?.let { return it }
        val store = SecureTokenStore(context.applicationContext)
        if (store.get(login) == null) return null
        val api = GitHubApi(GitHubHttp({ store.get(login) ?: "" }))
        apis[key] = api
        return api
    }

    @Synchronized fun forget(login: String) { apis.remove(login.lowercase()) }
}
