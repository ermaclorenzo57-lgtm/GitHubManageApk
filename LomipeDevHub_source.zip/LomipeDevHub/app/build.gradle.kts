plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Optional stable signing, supplied only through environment variables (never committed).
// With these set, debug AND release builds are signed with the same key so updates install over each other.
val ksFile = System.getenv("LOMIPE_KEYSTORE_FILE")

android {
    namespace = "com.lomipe.devhub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lomipe.devhub"
        minSdk = 29          // MediaStore.Downloads / scoped storage without legacy permissions
        targetSdk = 35
        versionCode = (System.getenv("LOMIPE_VERSION_CODE") ?: "2").toInt()
        versionName = System.getenv("LOMIPE_VERSION_NAME") ?: "2.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        if (ksFile != null && file(ksFile).exists()) {
            create("ci") {
                storeFile = file(ksFile)
                storePassword = System.getenv("LOMIPE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("LOMIPE_KEY_ALIAS")
                keyPassword = System.getenv("LOMIPE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug { signingConfigs.findByName("ci")?.let { signingConfig = it } }
        release {
            isMinifyEnabled = false
            signingConfigs.findByName("ci")?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    testOptions { unitTests.isReturnDefaultValues = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

tasks.withType<Test>().configureEach { maxHeapSize = "1g" }

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    testImplementation("junit:junit:4.13.2")

    androidTestImplementation(platform("androidx.compose:compose-bom:2024.10.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
