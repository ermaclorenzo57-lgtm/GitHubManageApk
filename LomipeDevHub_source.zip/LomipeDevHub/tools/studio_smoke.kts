import com.lomipe.devhub.core.*
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.nio.file.Files
val dir=Files.createTempDirectory("devhub-smoke").toFile()
var count=0
fun test(name:String,block:()->Unit){block();count++;println("PASS $name")}
fun zip(name:String,vararg pairs:Pair<String,String>):File=File(dir,name).also{f->ZipOutputStream(f.outputStream()).use{z->pairs.forEach{(p,t)->z.putNextEntry(ZipEntry(p));z.write(t.toByteArray());z.closeEntry()}}}
try {
 test("URL import"){check(repoFromInput("https://github.com/user/project.git")=="user/project");check(repoFromInput("user/project")=="user/project")}
 test("reject non-GitHub host and path"){check(runCatching{repoFromInput("https://github.com.evil.example/user/project")}.isFailure);check(runCatching{repoFromInput("https://github.com/user/project/tree/main")}.isFailure)}
 test("safe extraction, root normalization, secret exclusions"){val a=zip("project.zip","project/gradlew" to "test","project/build.gradle.kts" to "test","project/.env" to "secret","project/src/Main.kt" to "fun main() {}","project/build/cache" to "cache");val out=File(dir,"project");val result=ProjectStudio.extract(a,out);check(result.files.map{it.path}.toSet()==setOf("gradlew","build.gradle.kts","src/Main.kt"));check("Android / Gradle" in result.frameworks);check(result.warnings.any{it.contains("JAR")})}
 test("traversal rejected and workspace cleaned"){val a=zip("bad.zip","../bad" to "bad");val out=File(dir,"bad");check(runCatching{ProjectStudio.extract(a,out)}.isFailure);check(!out.exists())}
 test("duplicate case-folded paths rejected"){val a=zip("dup.zip","a.txt" to "a","A.txt" to "b");check(runCatching{ProjectStudio.extract(a,File(dir,"dup"))}.isFailure)}
 test("framework detection"){val a=zip("frameworks.zip","pubspec.yaml" to "name: test","project.godot" to "config_version=5","package.json" to "{\"dependencies\":{\"react-native\":\"1\"}}","index.html" to "hi","main.py" to "print(1)","ProjectVersion.txt" to "1");val s=ProjectStudio.extract(a,File(dir,"frameworks"));check(s.frameworks.containsAll(listOf("Flutter","Godot","React Native","HTML","Python","Unity")))}
 test("workflow templates"){check(WorkflowStudio.kinds.size==5);WorkflowStudio.kinds.forEach{check(WorkflowStudio.yaml(it).contains("workflow_dispatch:"));check(WorkflowStudio.yaml(it).contains("contents: read"))}}
 test("error advice"){check(ProjectStudio.advice("Unresolved reference: abc").contains("imports"))}
 println("$count passed")
} finally {dir.deleteRecursively()}
