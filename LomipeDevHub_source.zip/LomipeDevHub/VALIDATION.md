# Validation report

## Done in the build sandbox
| Check | Result |
|---|---|
| Core (`app/src/main/java/.../core`, pure Kotlin) compiled with Kotlin 2.4.21 | OK, 0 errors |
| Android data layer (`data/`: Keystore store, APK inspector, MediaStore saver, pipeline) type-checked against the **android-34 `android.jar`** stubs | OK, 0 errors |
| Core unit tests: 43 tests against a local mock GitHub server (JDK `HttpServer`) | 43 passed, 0 failed (`tools/last_local_test_report.txt`) |
| Build-workflow YAML parsed; project locator script run on 5 fixture repos (single, nested, ambiguous, newest-ZIP, zip-slip) | OK |

Covered by the 43 tests: 401/403/404/409/413/422/5xx/rate-limit/SSO mapping, pagination, ETag, token only to trusted host,
redirect without Authorization, 39,306,752-byte commit upload (exact Content-Length, streamed Base64, blob SHA verified),
overwrite confirmation, stale-SHA edit rejection, release upload with unique names + digest, run/job/step parsing,
re-run/cancel/dispatch endpoints, run correlation (single/ambiguous/none), log redaction + tail truncation, partial
download, checksum mismatch, retry with fresh redirect, expired artifacts, zip-slip/absolute/backslash/duplicate names,
zip-bomb and entry limits, **CRC corruption (found and fixed a real bug: java.util.zip.ZipFile does not verify CRC)**,
checksum-manifest exact-name matching, per-account isolation, upload-queue persistence, line diff, cancellation semantics.

Caveat: the tests were executed with a tiny JUnit-4 stand-in runner (real JUnit is not downloadable here: Maven is blocked).
They are standard JUnit 4 and should run unchanged under `./gradlew testDebugUnitTest`, which has NOT been run.

## NOT tested (could not be, in this sandbox)
* **The Gradle/AGP build itself** (`./gradlew assembleDebug`): Maven Central, Google Maven and services.gradle.org are
  unreachable here. Versions chosen (AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, Compose BOM 2024.10.01, WorkManager 2.9.1) are a
  known-compatible set from my knowledge; I did not verify they are the newest. Expect to possibly fix small things on the first CI run.
* **All Jetpack Compose / androidx code** (`ui/`, `work/`) was written but never compiled (androidx libraries unavailable).
  Treat compile errors there as likely-but-small on first build.
* Anything on a real device/emulator: Keystore encryption round trip, SAF file picker, MediaStore save, FileProvider install
  flow, notifications, WorkManager scheduling, themes, the androidTest smoke test.
* Real GitHub: no request was ever sent to api.github.com (no token/network). Behaviour is verified against a mock built
  from the documented API only. Cancelling a network call promptly relies on Android's HttpURLConnection.disconnect();
  on the desktop JDK it waits for the body, so promptness is unverified.
* Real-world 39 MB upload over a phone network, rate-limit headers from the live service, the installer's behaviour
  with a signer mismatch.
* `gradle-wrapper.jar` was copied from the official gradle/gradle v8.9.0 tag; its checksum was not independently verified.
