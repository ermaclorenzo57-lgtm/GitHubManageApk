import com.lomipe.devhub.core.*
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry
val root=Files.createTempDirectory("devhub3-test").toFile()
var passed=0
fun test(name:String,block:()->Unit){block();passed++;println("PASS $name")}
try {
 test("atomic write replaces file"){val f=File(root,"draft");DevTools.atomicWrite(f,"old");DevTools.atomicWrite(f,"new");check(f.readText()=="new")}
 test("HTML generation escapes untrusted text"){val s=DevTools.design("<script>x</script>","#123456",listOf(DevTools.Widget("Input","\"<>")));check(!s.contains("<script>"));check(s.contains("&quot;&lt;&gt;"));check(runCatching{DevTools.design("title","bad",emptyList())}.isFailure)}
 test("Compose source escapes interpolation"){val s=DevTools.composeSource("Hello \$name",listOf(DevTools.Widget("Button","Test")));check(s.contains("Hello \\\$name"));check(s.contains("onAction(0)"))}
 test("diagnostics flag invalid JSON and conflicts without printing secrets"){val d=File(root,"project").also{it.mkdirs()};File(d,"broken.json").writeText("{");File(d,"main.kt").writeText("<<<<<<< HEAD\nval a=1");val result=DevTools.diagnostics(d);check(result.any{it.contains("Invalid JSON")});check(result.any{it.contains("merge conflict")})}
 test("asset index sorts by size"){val d=File(root,"assets").also{it.mkdirs()};File(d,"a.png").writeText("1234");File(d,"b.wav").writeText("1");File(d,"x.txt").writeText("other");check(DevTools.assets(d).map{it.path}==listOf("a.png","b.wav"))}
 test("persistent tasks"){val store=TaskStore(File(root,"tasks.json"));val t=DevTask("1","Fix UI","To do");store.save(listOf(t));check(store.load()==listOf(t));store.save(listOf(t.copy(status="Done")));check(store.load().first().status=="Done")}
 test("encrypted backup roundtrip, wrong password and tamper rejection"){val p="test password 123".toCharArray();val content="example project".toByteArray();val e=BackupCrypto.encrypt(content,p);check(BackupCrypto.decrypt(e,p).contentEquals(content));check(runCatching{BackupCrypto.decrypt(e,"wrong password 123".toCharArray())}.isFailure);e[e.lastIndex]=(e.last().toInt() xor 1).toByte();check(runCatching{BackupCrypto.decrypt(e,p)}.isFailure)}
 test("archive inspection"){val f=File(root,"test.zip");ZipOutputStream(f.outputStream()).use{it.putNextEntry(ZipEntry("data.txt"));it.write("abc".toByteArray());it.closeEntry()};check(DevTools.archiveReport(f).any{it.contains("3 B · data.txt")})}
 test("simple regex restrictions and JSON utility"){check(DevTools.regexMatches("[ab]","abc").size==2);check(runCatching{DevTools.regexMatches("(a+)+","a")}.isFailure);check(DevTools.formatJson("{ \"x\": 1 }")=="{\"x\":1}")}
 test("API tester rejects insecure URL"){check(runCatching{ApiProbe.request("http://example.org","GET","")}.isFailure)}
 test("workflow templates"){check(WorkflowStudio.kinds.size==9);check(WorkflowStudio.yaml("Android test lab").contains("connectedDebugAndroidTest"));check(WorkflowStudio.yaml("Android AAB").contains("bundleRelease"));check(WorkflowStudio.yaml("Godot (configured runner)").contains("self-hosted"));check(WorkflowStudio.yaml("Electron").contains("npm run dist"));val d=File("tools/generated-workflows").also{it.mkdirs()};WorkflowStudio.kinds.forEachIndexed{i,k->File(d,"template-$i.yml").writeText(WorkflowStudio.yaml(k))}}
 println("$passed passed")
}finally{root.deleteRecursively()}
