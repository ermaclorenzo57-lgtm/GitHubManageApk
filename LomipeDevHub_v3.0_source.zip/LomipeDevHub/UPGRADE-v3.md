# LomipeDevHub 3.0 — Studio development preview

Built from the exact supplied v2.0 ZIP. Original GitHub, account, upload, build monitoring, download, installation and release features remain. New code has not been built against the Android SDK here. No live repository or account was changed.

## Added
- New Studio entry on bottom navigation (works without login), and Tools tab within each repository, with account/project-scoped storage.
- Code workbench: import/export UTF-8 text, debounced draft save, explicit save, baseline comparison (500 lines), basic highlighting, find/replace, undo/redo, line lookup and manual indentation. Existing project editor retained. Draft changes can be lost if exiting during the 600ms debounce; use Save draft before leaving.
- UI designer: ordered heading/text/button/input elements, accent color for HTML, static safe WebView preview, export HTML and Compose source. No arbitrary generated code is executed. Compose callbacks are placeholders, not full application navigation. Not a drag-and-drop designer.
- Test lab: scan project ZIP for framework prerequisites, invalid JSON, merge conflict markers, common secret patterns and manifest permission references; copy report. Not a compiler, vulnerability database or complete secret scanner.
- Manual GitHub Actions emulator workflow and new instrumentation smoke test. Android test lab template is available in existing repository workflow builder. Requires suitable runner and user-written instrumentation tests. It does not discover arbitrary nonresponsive buttons, record video or measure performance automatically.
- HTTPS API tester: GET, HEAD, confirmed POST with JSON body, status, elapsed milliseconds, up to 64 KiB response. No automatic GitHub credential attachment or redirect following; no custom auth or collections.
- Persistent local project/general task boards (to do, in progress, done), with task creation, moving and confirmed removal. No real-time collaboration.
- Asset inventory by type/size, and APK/AAB/ZIP archive size report plus existing Android APK metadata inspector. No modification or re-signing.
- Encrypted file backups: select ZIP, encrypt/decrypt via AES-256-GCM with random 16-byte salt and 12-byte IV, PBKDF2-HMAC-SHA256 600,000 iterations; 20 MiB cap; 12+ character password. No password recovery; no automatic backup or restore. Temporary input/output stored in private cache; normally deleted on leaving/export, but interruption can leave cache files. Exported decrypted ZIP is plaintext. Not a security audit.
- Offline AI handoff: build redacted review prompt from user-selected logs/code and copy for review in an external assistant. No model API or autonomous patching.
- Utilities: compact/validate JSON and deliberately restricted regex matcher.
- Release draft with custom title and changelog; publish on GitHub.
- Nine workflow templates: existing Android Gradle, Flutter, React Native, HTML and Python, plus Android emulator test lab, Android AAB (signing project-specific), Electron (requires npm dist script), Godot Android (trusted preconfigured self-hosted runner with godot label, Godot binary, SDK, export templates and Android preset). Godot template is not a universal cloud build. Only manual dispatch; verify workflows and third-party actions before running. CI charges may apply. Do not run untrusted repositories on a self-hosted machine.

## How to use
Build from GitHub Actions as before; the optional Test Lab workflow is manual. Studio opens without login. For repo tools select Repos > repository > Tools. Existing Studio tab remains the project ZIP/editor/workflow manager. Use the same signing key and higher versionCode for in-place installation; defaults are version 3.0.0/code 3, configurable by existing environment variables. No signing secrets are bundled.

## Deferred / partial
Full language-server autocomplete, automatic syntax checks across languages, true split-screen/line gutters/global replacement; drag-and-drop/native preview; cloud AI providers, local LLM, autonomous bug fixes; shell/terminal with Git/Node/Python; GitLab/Bitbucket, collaborative live editing, extensions; full Unity/KMP and universal builds; performance/video/screenshot cloud diagnostics; full keystore manager, automated Play publishing, full dependency vulnerability scan, asset optimizer; Git conflict resolution and project upload resume beyond existing retry; full encrypted workspace backup and biometric lock; live billing totals. Existing device credential lock and GitHub API quota monitor retained. These are not represented as completed features. Existing v2 limitations still apply unless specifically addressed above.

## Validation
See tools/v3_smoke_report.txt and tools/v3_regression_report.txt for local JVM smoke tests. The earlier VALIDATION.md and earlier reports describe older builds. Android compilation, instrumented tests, live GitHub/API requests, cloud builds and on-device behavior not verified in this environment. Source archive only, no APK.

References: Godot command line export docs https://docs.godotengine.org/en/stable/tutorials/editor/command_line_tutorial.html ; emulator runner https://github.com/ReactiveCircus/android-emulator-runner .
