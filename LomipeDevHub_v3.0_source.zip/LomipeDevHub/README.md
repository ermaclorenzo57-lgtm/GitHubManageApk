> Version 3.0 development preview: see [UPGRADE-v3.md](UPGRADE-v3.md) for additions, instructions, validation and limitations.

# Lomipe DevHub

Native Kotlin + Jetpack Compose Android app to manage GitHub repositories from a phone:
upload files (as a branch commit or as a release asset), detect the GitHub Actions run that
your upload started, watch jobs and steps, read logs, re-run / cancel / dispatch, and download,
verify and install the built APK. It is a port of the Aisya Godot GitHub uploader's behaviour
(contents upload, release-asset upload, workflow dispatch, artifact download) into Kotlin.

## Build
* Locally / on GitHub: `./gradlew testDebugUnitTest assembleDebug` (JDK 17, Android SDK 35).
* GitHub Actions: push this repo to GitHub; `.github/workflows/build-android.yml` builds it and uploads
  an artifact named `apk` (APK + `SHA256SUMS`). Download it with the app itself.
* The workflow auto-detects the project (a `gradlew` folder, or the **newest project ZIP** in the repo root or
  `uploads/`), so new versions never require editing the workflow. Ambiguity (two Gradle projects) stops with a clear
  error; fix by setting the repository variable `LOMIPE_PROJECT_DIR`.
* Other repos can reuse it: `uses: <owner>/LomipeDevHub/.github/workflows/build-android.yml@main` with
  `with: { tools_repo: <owner>/LomipeDevHub }`.
* Stable signing (so updates install over each other): add secrets `LOMIPE_KEYSTORE_BASE64`,
  `LOMIPE_KEYSTORE_PASSWORD`, `LOMIPE_KEY_ALIAS`, `LOMIPE_KEY_PASSWORD`. Without them each CI build gets a fresh debug
  key and Android will refuse to update over an older install (uninstall first). No key is stored in this repo.

## Token
Fine-grained token for the repositories you manage: Contents RW, Actions RW, Metadata R (+ Workflows RW only to upload
files under `.github/workflows`). Stored AES-256-GCM encrypted with an Android Keystore key; excluded from backup;
never logged (log text is redacted); Authorization is only ever sent to api.github.com / uploads.github.com, and is
dropped on redirects to other hosts (signed artifact/log URLs).

## Design decisions / deviations from the master prompt (all deliberate, to keep it simple and verifiable)
* No third-party libraries for networking/JSON: `HttpURLConnection` + a small JSON parser + `java.util.zip`
  (instead of OkHttp, kotlinx.serialization). Fewer dependencies, and the whole core is unit-testable on a plain JVM.
* No Room / DataStore: SharedPreferences for settings, small JSON files (per-account folders) for download history and
  the upload queue. minSdk is 29 (MediaStore.Downloads without legacy storage permission), not 26.
* Polling, not push: the run screen refreshes while open (ETag conditional requests, backoff, rate-limit pause).
  Background watching uses WorkManager and can only run about every 15 minutes (Android decides). It is not real time.
* Release uploads never delete existing assets; a name clash gets a timestamp suffix.
* Not implemented: repo creation/deletion, file rename/move, split-APK installation, cache by-repo search of
  repos not yet loaded, in-app GitHub App OAuth. Wi-Fi-only applies to background work/auto-download only.

## Validation actually performed (see below for what was NOT)
See `VALIDATION.md`.

## Version 2.0 preview
See [UPGRADE-v2.md](UPGRADE-v2.md) for new features, operation and current limitations.
