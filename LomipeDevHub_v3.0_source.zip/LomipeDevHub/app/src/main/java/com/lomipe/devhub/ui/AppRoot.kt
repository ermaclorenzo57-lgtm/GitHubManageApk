package com.lomipe.devhub.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AppRoot(vm: AppViewModel, onRequestNotifications: () -> Unit) {
    val top = vm.stack.lastOrNull()
    BackHandler(enabled = top != null) { vm.pop() }
    Scaffold(
        bottomBar = {
            if (top == null) NavigationBar {
                listOf("Home", "Repos", "Builds", "Downloads", "Settings", "Studio").forEachIndexed { i, t ->
                    NavigationBarItem(selected = vm.tab == i, onClick = { vm.tab = i }, icon = { Text(t.take(1)) }, label = { Text(t) })
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            if (vm.busy > 0) LinearProgressIndicator(Modifier.fillMaxWidth())
            vm.message?.let { m ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Text(m, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { vm.message = null }) { Text("OK") }
                }
            }
            if (vm.login == null && top == null && vm.tab != 4 && vm.tab != 5) {
                Column(Modifier.padding(16.dp)) {
                    Text("Welcome to Lomipe DevHub", style = MaterialTheme.typography.headlineSmall)
                    Note("Open Settings and add a GitHub token to begin.")
                    Btn("Go to Settings") { vm.tab = 4 }
                }
            } else when (top) {
                is Screen.RepoDetail -> vm.repoSession?.let { RepoScreen(vm, it) }
                is Screen.RunDetail -> vm.runSession?.let { RunScreen(vm, it, onRequestNotifications) }
                is Screen.LogView -> vm.logSession?.let { LogScreen(vm, it) }
                null -> when (vm.tab) {
                    0 -> HomeScreen(vm)
                    1 -> ReposScreen(vm)
                    2 -> BuildsScreen(vm)
                    3 -> DownloadsScreen(vm)
                    5 -> AdvancedStudio(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), content = content)
}
