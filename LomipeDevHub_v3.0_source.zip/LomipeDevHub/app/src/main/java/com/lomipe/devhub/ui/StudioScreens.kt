package com.lomipe.devhub.ui

import android.app.KeyguardManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.lomipe.devhub.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@Composable fun RepositoryAddPanel(vm: AppViewModel) {
    var mode by remember { mutableStateOf(0) }; var name by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var privateRepo by remember { mutableStateOf(true) }; var readme by remember { mutableStateOf(true) }; var workflow by remember { mutableStateOf(false) }
    Row { Btn("+ New repo") { mode = 1 }; BtnO("Add existing") { mode = 2 } }
    if(mode != 0) AlertDialog(onDismissRequest={ mode=0 }, title={ Text(if(mode==1) "Create repository" else "Add repository") }, text={ Column {
        Field(if(mode==1) "Repository name" else "GitHub URL or owner/name",name,{name=it})
        if(mode==1) { Field("Description",desc,{desc=it}); Row { Checkbox(privateRepo,{privateRepo=it}); Text("Private") }; Row { Checkbox(readme,{readme=it; if(!it)workflow=false}); Text("Initialize README") }; Row { Checkbox(workflow,{workflow=it},enabled=readme); Text("Android workflow") }; Note("Requires GitHub repository creation permission. Public repositories are visible to everyone.") }
    } }, confirmButton={ TextButton(enabled=name.isNotBlank() && vm.busy==0,onClick={ if(mode==1)vm.createRepo(name,desc,privateRepo,readme,workflow) else vm.importRepo(name); mode=0; name=""; desc="" }){ Text(if(mode==1) "Create" else "Add") } }, dismissButton={TextButton(onClick={mode=0}){Text("Cancel")}})
}

private class CodeColors(private val color: Color): VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val result=AnnotatedString.Builder(text.text)
        Regex("\\b(fun|val|var|class|object|if|else|return|import|package|def|const|let|public|private|true|false|null)\\b").findAll(text.text).take(10000).forEach { result.addStyle(SpanStyle(color=color),it.range.first,it.range.last+1) }
        return TransformedText(result.toAnnotatedString(),OffsetMapping.Identity)
    }
}
@Composable fun CodeField(value: String, set: (String)->Unit) {
    var find by remember { mutableStateOf("") }; var replace by remember { mutableStateOf("") }
    val undo = remember { mutableStateListOf<String>() }; val redo = remember { mutableStateListOf<String>() }
    fun edit(next: String) { if(next==value)return; undo.add(value); if(undo.size>20)undo.removeAt(0); redo.clear(); set(next) }
    Field("Find",find,{find=it}); Field("Replace with",replace,{replace=it})
    Row { BtnO("Replace all",find.isNotEmpty() && value.contains(find)) { edit(value.replace(find,replace)) }; BtnO("Undo",undo.isNotEmpty()) { redo.add(value); set(undo.removeAt(undo.lastIndex)) }; BtnO("Redo",redo.isNotEmpty()) { undo.add(value); set(redo.removeAt(redo.lastIndex)) } }
    Note("${value.lines().size} lines · ${value.length} characters" + if(find.isNotEmpty()) " · ${value.lines().count{it.contains(find)}} matching lines" else "")
    OutlinedTextField(value=value,onValueChange={edit(it)},label={Text("Source code")}, modifier=Modifier.fillMaxWidth().heightIn(min=220.dp,max=480.dp), textStyle=LocalTextStyle.current.copy(fontFamily=FontFamily.Monospace),visualTransformation=CodeColors(MaterialTheme.colorScheme.primary),keyboardOptions=KeyboardOptions.Default)
}
@Composable fun MoveFilePanel(s: RepoSession,f: FileContent) {
    var show by remember(f.path){mutableStateOf(false)}; var to by remember(f.path){mutableStateOf(f.path)}
    BtnO("Rename / move") { show=true }
    if(show) AlertDialog(onDismissRequest={show=false},title={Text("Move file on ${s.branch}")},text={Column{Field("New path",to,{to=it});Note("Creates one commit; existing destination files are not overwritten.")}},confirmButton={TextButton(enabled=to.isNotBlank()&&to!=f.path,onClick={show=false;s.moveOpened(to)}){Text("Move")}},dismissButton={TextButton(onClick={show=false}){Text("Cancel")}})
}
@Composable fun UsagePanel(vm: AppViewModel) {
    var rate by remember { mutableStateOf<JObj?>(null) }; H("GitHub usage")
    BtnO("Check API quota",vm.login!=null && vm.busy==0){vm.op {rate=StudioApi(vm.api()).rate()}}
    rate?.let {Note("Core requests remaining: ${it.l("remaining")} / ${it.l("limit")}"); Note("Resets: ${java.util.Date(it.l("reset")*1000)}")}
    vm.login?.let {BtnO("Actions billing on GitHub"){Intents.openGitHubUrl(vm.ctx,"https://github.com/settings/billing")}}
}
@Composable fun DeviceLockSettings(vm: AppViewModel) {
    var locked by remember {mutableStateOf(vm.prefs.deviceLock)}
    val manager=vm.ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ if(it.resultCode==android.app.Activity.RESULT_OK){vm.prefs.deviceLock=!locked;locked=!locked} }
    H("App protection"); Row {Text("Device credential lock on app launch",Modifier.weight(1f));Switch(locked,{ if(manager.isDeviceSecure){ @Suppress("DEPRECATION") val intent=manager.createConfirmDeviceCredentialIntent("DevHub protection","Confirm your device credential"); if(intent!=null)launcher.launch(intent) } else vm.message="Set a device screen lock first" })}
    Note("Uses Android's device credential prompt. Does not encrypt workspace files or replace GitHub authentication.")
}
@Composable fun ManagePanel(vm:AppViewModel,s:RepoSession)=Page {
    var info by remember {mutableStateOf<JObj?>(null)}; var name by remember {mutableStateOf("")}; var desc by remember {mutableStateOf("")}; var privateRepo by remember {mutableStateOf(true)}; var archive by remember {mutableStateOf(false)}; var group by remember {mutableStateOf(vm.prefs.repoPref(vm.login!!,s.repo,"group")?:"")}; var ask by remember {mutableStateOf("")}; var secrets by remember {mutableStateOf<List<String>?>(null)}
    fun load(){vm.op { val d=StudioApi(vm.api()).details(s.repo);info=d;name=d.s("name")?:"";desc=d.s("description")?:"";privateRepo=d.b("private");archive=d.b("archived") }}
    LaunchedEffect(s.repo){load()}
    H("Repository settings"); BtnO("Refresh",vm.busy==0){load()}; info?.let {d->
        Note("GitHub size: ${d.l("size")} KiB · ${d.l("open_issues_count")} open issues / PRs")
        Field("Name",name,{name=it});Field("Description",desc,{desc=it});Row {Checkbox(privateRepo,{privateRepo=it});Text("Private")};Row{Checkbox(archive,{archive=it});Text("Archived")}
        Btn("Save settings",vm.busy==0 && name.isNotBlank()){ask="settings"}
    }
    Field("Local project group",group,{group=it});BtnO("Save group"){vm.prefs.setRepoPref(vm.login!!,s.repo,"group",group.trim());vm.message="Saved group"}
    BtnO("Fork repository",vm.busy==0){ask="fork"}
    H("Actions secrets");BtnO("List secret names",vm.busy==0){vm.op{secrets=StudioApi(vm.api()).secretNames(s.repo)}};secrets?.let{Note(if(it.isEmpty())"No secrets returned" else it.joinToString("\n"))};BtnO("Manage encrypted secrets on GitHub"){Intents.openGitHubUrl(vm.ctx,"https://github.com/${s.repo}/settings/secrets/actions")}
    if(ask.isNotEmpty()) Confirm(if(ask=="fork")"Create fork?" else "Change repository settings?",if(ask=="fork")"Create a fork in your GitHub account." else "Rename, archive, or change visibility. Public repositories can be seen by everyone.","Confirm",{val action=ask;ask="";vm.op{val api=StudioApi(vm.api());val r=if(action=="fork")api.fork(s.repo) else api.update(s.repo,name,desc,privateRepo,archive);vm.rememberRepo(r);vm.message="Updated ${r.fullName}";vm.pop();vm.openRepo(r.fullName)}},{ask=""})
}
@Composable fun HistoryPanel(vm:AppViewModel,s:RepoSession)=Page {
    var commits by remember {mutableStateOf<List<JObj>>(emptyList())};var detail by remember{mutableStateOf<JObj?>(null)};var restore by remember{mutableStateOf<String?>(null)}
    H("Commit history · ${s.branch}");BtnO("Load latest 50",vm.busy==0&&s.branch.isNotBlank()){vm.op{commits=StudioApi(vm.api()).commits(s.repo,s.branch)}}
    detail?.let {d-> H("Changes ${d.s("sha")?.take(8)}");d.a("files").take(30).forEach{f->Note("${f.s("filename")} · ${f.s("status")} +${f.l("additions")} -${f.l("deletions")}");Mono(f.s("patch")?.take(5000)?:"No text patch available")};BtnO("Close diff"){detail=null}}
    commits.forEach{c->val sha=c.s("sha")?:return@forEach;H(sha.take(8));Note(c.o("commit")?.s("message")?:"");Row{BtnO("Diff",vm.busy==0){vm.op{detail=StudioApi(vm.api()).commitDetails(s.repo,sha)}};BtnO("Restore",vm.busy==0){restore=sha}};HorizontalDivider()}
    restore?.let {sha->Confirm("Restore ${sha.take(8)}?","Creates a new commit replacing the entire selected branch tree with this historical snapshot. No force push.","Restore",{restore=null;vm.op{val result=StudioApi(vm.api()).restore(s.repo,s.branch,sha);vm.message="Restored in ${result.take(8)}";commits=StudioApi(vm.api()).commits(s.repo,s.branch)}},{restore=null})}
}
@Composable fun TeamPanel(vm:AppViewModel,s:RepoSession)=Page {
    var issues by remember {mutableStateOf<List<JObj>>(emptyList())};var pulls by remember{mutableStateOf<List<JObj>>(emptyList())};var title by remember{mutableStateOf("")};var body by remember{mutableStateOf("")};var head by remember{mutableStateOf("")};var base by remember{mutableStateOf("")};var action by remember{mutableStateOf<Pair<String,JObj>?>(null)}
    val api={StudioApi(vm.api())};H("Issues");BtnO("Load issues",vm.busy==0){vm.op{issues=api().issues(s.repo)}};Field("Title",title,{title=it});Field("Description",body,{body=it},false);Btn("Create issue",title.isNotBlank()&&vm.busy==0){vm.op{api().createIssue(s.repo,title,body);title="";body="";issues=api().issues(s.repo)}}
    issues.forEach{d->Note("#${d.l("number")} ${d.s("title")}");Row{BtnO("Open"){Intents.openGitHubUrl(vm.ctx,"https://github.com/${s.repo}/issues/${d.l("number")}")};BtnO("Close",vm.busy==0){action="close" to d}}}
    H("Pull requests");BtnO("Load pull requests",vm.busy==0){vm.op{pulls=api().pulls(s.repo)}};Field("Source branch",head,{head=it});Field("Target branch",base,{base=it});Btn("Create PR",title.isNotBlank()&&head.isNotBlank()&&base.isNotBlank()&&vm.busy==0){vm.op{api().createPull(s.repo,title,head,base,body);pulls=api().pulls(s.repo)}}
    pulls.forEach{d->Note("#${d.l("number")} ${d.s("title")}");Row{BtnO("Review"){Intents.openGitHubUrl(vm.ctx,"https://github.com/${s.repo}/pull/${d.l("number")}")};BtnO("Merge",vm.busy==0){action="merge" to d}}}
    action?.let{(kind,d)->Confirm("${if(kind=="close")"Close issue" else "Merge pull request"}?","#${d.l("number")} ${d.s("title")}","Confirm",{action=null;vm.op{if(kind=="close"){api().closeIssue(s.repo,d.l("number"));issues=api().issues(s.repo)}else{val sha=d.o("head")?.s("sha")?:error("Missing head SHA");val result=api().merge(s.repo,d.l("number"),sha);require(result.b("merged")){result.s("message")?:"Merge not completed"};pulls=api().pulls(s.repo)}}},{action=null})}
}

@Composable fun StudioPanel(vm:AppViewModel,s:RepoSession)=Page {
    val login=vm.login ?: return@Page
    val workspaceRoot=remember(login,s.repo){File(vm.ctx.filesDir,"workspaces/${login.lowercase()}/${s.repo}").also{it.mkdirs()}}
    var folders by remember{mutableStateOf(workspaceRoot.listFiles()?.filter{it.isDirectory}?.sortedByDescending{it.lastModified()}?:emptyList())}
    var root by remember{mutableStateOf<File?>(folders.firstOrNull())};var scan by remember{mutableStateOf<ProjectScan?>(null)}
    var status by remember{mutableStateOf("")};var query by remember{mutableStateOf("")};var searchContent by remember{mutableStateOf(false)};var matches by remember{mutableStateOf<List<String>>(emptyList())}
    val tabs=remember{mutableStateListOf<String>()};val drafts=remember{mutableStateMapOf<String,String>()};var current by remember{mutableStateOf<String?>(null)}
    var kind by remember{mutableStateOf("Android / Gradle")};var yaml by remember{mutableStateOf(WorkflowStudio.yaml(kind))};var ask by remember{mutableStateOf("")};var preview by remember{mutableStateOf(false)};var commitMessage by remember{mutableStateOf("Upload project from DevHub")};var newPath by remember{mutableStateOf("")}
    fun select(f:File){root=f;scan=null;tabs.clear();drafts.clear();current=null;matches=emptyList();preview=false}
    fun refresh(){folders=workspaceRoot.listFiles()?.filter{it.isDirectory}?.sortedByDescending{it.lastModified()}?:emptyList()}
    suspend fun inspect(f:File){scan=withContext(Dispatchers.IO){ProjectStudio.scan(f)}}
    LaunchedEffect(root){root?.let{f->try{inspect(f);val detected=scan?.frameworks?.firstOrNull{it in WorkflowStudio.kinds};if(detected!=null){kind=detected;yaml=WorkflowStudio.yaml(kind)}}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){status=errText(e)}}}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)vm.op{
        val dest=File(workspaceRoot,UUID.randomUUID().toString());val zip=File(vm.ctx.cacheDir,"${UUID.randomUUID()}.zip")
        try{withContext(Dispatchers.IO){vm.ctx.contentResolver.openInputStream(uri)!!.use{input->zip.outputStream().use{out->val buf=ByteArray(65536);var total=0L;while(true){val n=input.read(buf);if(n<0)break;total+=n;require(total<=100L*1024*1024){"ZIP exceeds 100 MiB"};out.write(buf,0,n)}}};ProjectStudio.extract(zip,dest)};refresh();select(dest);status="Imported ZIP to offline workspace"}finally{zip.delete()}
    }}
    H("Project studio · ${s.branch}");Note("ZIP import skips common credentials and generated folders. Review all source files before committing. Limits: 500 files, 10 MiB per file, 100 MiB total.")
    Row{Btn("Import ZIP",vm.busy==0){picker.launch(arrayOf("application/zip","application/octet-stream","application/x-zip-compressed"))};BtnO("Clone ZIP",vm.busy==0&&s.branch.isNotBlank()){vm.op{val zip=File(vm.ctx.cacheDir,"${UUID.randomUUID()}.zip");val dest=File(workspaceRoot,UUID.randomUUID().toString());try{StudioApi(vm.api()).downloadZip(s.repo,s.branch,zip);withContext(Dispatchers.IO){ProjectStudio.extract(zip,dest)};refresh();select(dest);status="Cloned branch snapshot"}finally{zip.delete()}}}}
    BtnO("Share repo ZIP",vm.busy==0&&s.branch.isNotBlank()){vm.op{val file=File(Intents.exportDir(vm.ctx),"${s.repo.substringAfter('/')}-${UUID.randomUUID()}.zip");StudioApi(vm.api()).downloadZip(s.repo,s.branch,file);Intents.share(vm.ctx,file,"application/zip")}}
    H("Offline workspaces");folders.take(30).forEachIndexed{i,f->TextButton(onClick={select(f)},enabled=vm.busy==0){Text("${if(root==f)"●" else "○"} Workspace ${i+1} · ${java.util.Date(f.lastModified())}")}}
    Row{BtnO("New HTML project",vm.busy==0){vm.op{val f=File(workspaceRoot,UUID.randomUUID().toString());withContext(Dispatchers.IO){f.mkdirs();File(f,"index.html").writeText("<!doctype html>\n<html><head><meta charset=\"utf-8\"><title>My project</title></head><body><h1>Hello DevHub</h1></body></html>")};refresh();select(f)}};BtnO("Python project",vm.busy==0){vm.op{val f=File(workspaceRoot,UUID.randomUUID().toString());withContext(Dispatchers.IO){f.mkdirs();File(f,"main.py").writeText("def main():\n    print('Hello DevHub')\n\nif __name__ == '__main__':\n    main()\n")};refresh();select(f)}}}
    if(status.isNotBlank())Note(status)
    val f=root
    if(f!=null){
        val data=scan
        H("Preflight");Note("Detected: ${data?.frameworks?.joinToString()?:"Scanning"} · ${data?.files?.size?:0} files");data?.warnings?.forEach{Note("⚠ $it")};Note("Godot and Unity require custom export templates, versions, licensing or runner configuration.")
        Field("Filter / search",query,{query=it});Row{Checkbox(searchContent,{searchContent=it});Text("Search inside text files")};BtnO("Find in project",query.isNotBlank()&&vm.busy==0){vm.op{matches=withContext(Dispatchers.IO){(scan?.files?:emptyList()).filter{it.path.contains(query,true)||(searchContent&&it.file.length()<=200000&&runCatching{it.file.readText().contains(query,true)}.getOrDefault(false))}.map{it.path}.take(100)}}};matches.forEach{Note(it)}
        val choices=data?.files?.filter{query.isBlank()||it.path.contains(query,true)||it.path in matches}?.take(100)?:emptyList()
        choices.forEach{p->TextButton(onClick={vm.op{require(p.file.length()<=1000000){"Text editor limit: 1 MB"};val t=withContext(Dispatchers.IO){val b=p.file.readBytes();require(b.none{it==0.toByte()}){"Binary file"};Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(b)).toString()};if(p.path !in tabs)tabs.add(p.path);if(p.path !in drafts)drafts[p.path]=t;current=p.path;preview=false}},enabled=vm.busy==0){Text(p.path)}}
        Field("New source file path",newPath,{newPath=it});BtnO("Create local file",newPath.isNotBlank()&&vm.busy==0){vm.op{val path=validateRepoPath(newPath);val local=File(f,path);require(local.canonicalPath.startsWith(f.canonicalPath+File.separator)&&!local.exists());withContext(Dispatchers.IO){local.parentFile.mkdirs();local.writeText("")};newPath="";inspect(f)}}
        tabs.forEach{p->TextButton(onClick={current=p;preview=false}){Text("${if(p==current)"●" else "○"} $p")}}
        current?.let{p->H(p);key(p){CodeField(drafts[p]?:"",{drafts[p]=it})};Row{Btn("Save locally",vm.busy==0){vm.op{withContext(Dispatchers.IO){File(f,p).writeText(drafts[p]?:"")};inspect(f);status="Saved $p"}};BtnO("Close tab"){tabs.remove(p);drafts.remove(p);current=tabs.lastOrNull();preview=false}};if(p.endsWith(".html",true)){BtnO(if(preview)"Hide preview" else "Preview HTML"){preview=!preview};if(preview)AndroidView(factory={context->android.webkit.WebView(context).apply{settings.javaScriptEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.blockNetworkLoads=true}},update={it.loadDataWithBaseURL(null,drafts[p]?:"","text/html","UTF-8",null)},modifier=Modifier.fillMaxWidth().height(240.dp))}}
        Field("Commit message",commitMessage,{commitMessage=it});Btn("Commit saved workspace",vm.busy==0&&s.branch.isNotBlank()&&data?.files?.isNotEmpty()==true&&commitMessage.isNotBlank()){ask="upload"}
        BtnO("Delete local workspace",vm.busy==0){ask="delete"}
    }
    H("Workflow builder");Note("Templates assume the project is at repository root. Review before installing. Workflows dispatch manually; start from Runs after reopening the repository.")
    WorkflowStudio.kinds.forEach{k->TextButton(onClick={kind=k;yaml=WorkflowStudio.yaml(k)}){Text("${if(kind==k)"●" else "○"} $k")}}
    Field("Workflow YAML",yaml,{yaml=it},false);Row{BtnO("Copy YAML"){Intents.copy(vm.ctx,"Workflow",yaml)};Btn("Install workflow",vm.busy==0&&s.branch.isNotBlank()){ask="workflow"}}
    if(ask.isNotBlank())Confirm(when(ask){"upload"->"Commit project?";"delete"->"Delete local workspace?";else->"Install workflow?"},when(ask){"upload"->"Commit saved files to ${s.repo}/${s.branch}. Existing matching files are replaced; unrelated remote files are preserved. Unsaved editor drafts are not uploaded.";"delete"->"Remove this local workspace, including uncommitted files.";else->"Create .github/workflows/devhub-build.yml on ${s.branch}. Existing file will not be overwritten."},"Confirm",{val action=ask;ask="";vm.op{when(action){"upload"->{val selected=root?:error("No workspace");val files=withContext(Dispatchers.IO){ProjectStudio.scan(selected).files};val sha=StudioApi(vm.api()).uploadProject(s.repo,s.branch,files,commitMessage){status=it};status="Committed ${sha.take(8)}";s.loadRunsOp(true)};"delete"->{root?.let{withContext(Dispatchers.IO){it.deleteRecursively()}};refresh();root=null;scan=null;tabs.clear();drafts.clear();current=null};else->{Uploader(vm.api()).commitFile(s.repo,s.branch,".github/workflows/devhub-build.yml",BytesSource("devhub-build.yml",yaml.toByteArray()),"Add DevHub workflow",false);status="Workflow committed. Reopen repository to reload workflows."}}}},{ask=""})
}
