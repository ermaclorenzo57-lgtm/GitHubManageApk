package com.lomipe.devhub.ui

import android.app.Application
import android.os.Build
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lomipe.devhub.core.*
import com.lomipe.devhub.data.*
import com.lomipe.devhub.work.BuildWatchWorker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface Screen {
    data class RepoDetail(val full: String) : Screen
    data class RunDetail(val repo: String, val runId: Long) : Screen
    data class LogView(val repo: String, val jobId: Long, val title: String) : Screen
}

fun errText(e: Throwable): String = Redactor.redact(e.message ?: e.javaClass.simpleName)
fun nowText(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val ctx = app.applicationContext
    val prefs = Prefs(ctx)
    val tokens = SecureTokenStore(ctx)
    @Volatile var foreground = true

    var login by mutableStateOf(prefs.activeLogin?.takeIf { tokens.get(it) != null })
    var accounts by mutableStateOf(tokens.logins())
    var theme by mutableStateOf(prefs.theme)
    var wifiOnly by mutableStateOf(prefs.wifiOnly)
    var autoDownload by mutableStateOf(prefs.autoDownload)
    var refreshSeconds by mutableStateOf(prefs.refreshSeconds)
    var commitThresholdMiB by mutableStateOf(prefs.commitThresholdMiB)
    var defaultBranch by mutableStateOf(prefs.defaultBranch)

    var tab by mutableStateOf(0)
    val stack = mutableStateListOf<Screen>()
    var busy by mutableStateOf(0)
    var message by mutableStateOf<String?>(null)

    val repos = mutableStateListOf<Repo>()
    var reposHasNext by mutableStateOf(false)
    private var reposPage = 0
    val imported = mutableStateListOf<Repo>()
    var repoQuery by mutableStateOf("")
    var reposLoaded by mutableStateOf(false)
    var pinned by mutableStateOf<Set<String>>(emptySet())

    val homeRuns = mutableStateListOf<Pair<String, Run>>()
    var homeUpdated by mutableStateOf<String?>(null)
    var homeNote by mutableStateOf<String?>(null)

    val history = mutableStateListOf<HistoryEntry>()

    var repoSession by mutableStateOf<RepoSession?>(null)
    var runSession by mutableStateOf<RunSession?>(null)
    var logSession by mutableStateOf<LogSession?>(null)

    init {
        AppLog.init(ctx.filesDir)
        if (login != null) onAccountReady()
    }

    fun op(block: suspend () -> Unit): Job = viewModelScope.launch {
        busy++
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { message = errText(e); AppLog.log("error: ${errText(e)}") }
        finally { busy-- }
    }

    fun api(): GitHubApi {
        val l = login ?: throw IllegalStateException("Sign in first (Settings)")
        return Services.api(ctx, l) ?: throw IllegalStateException("No token stored for $l")
    }

    fun paths() = Services.paths(ctx)
    fun pipeline() = ApkPipeline(ctx, login!!, api())

    // ----- accounts -----
    fun signIn(token: String) = op {
        val t = token.trim()
        require(t.isNotEmpty()) { "Paste a token first" }
        val u = GitHubApi(GitHubHttp({ t })).getUser()      // validates token against GET /user, no hard-coded account
        tokens.put(u.login, t)
        Services.forget(u.login)
        prefs.activeLogin = u.login
        accounts = tokens.logins(); login = u.login
        resetAccountState(); onAccountReady()
        message = "Signed in as ${u.login}"
    }

    fun switchTo(l: String) { prefs.activeLogin = l; login = l; resetAccountState(); onAccountReady() }

    fun signOut(l: String) {
        tokens.remove(l); Services.forget(l)
        accounts = tokens.logins()
        if (login.equals(l, true)) { login = accounts.firstOrNull(); prefs.activeLogin = login; resetAccountState(); if (login != null) onAccountReady() }
    }

    private fun resetAccountState() {
        repos.clear(); imported.clear(); reposPage = 0; reposHasNext = false; reposLoaded = false
        homeRuns.clear(); history.clear(); stack.clear(); repoSession = null; runSession?.stop(); runSession = null; logSession = null
        pinned = emptySet()
    }

    private fun onAccountReady() {
        val l = login ?: return
        pinned = prefs.pinned(l)
        op { for (full in prefs.imported(l)) { try { imported.add(api().getRepo(full)) } catch(e: CancellationException) { throw e } catch(e: Exception) { AppLog.log(errText(e)) } } }
        loadHistory()
        loadRepos(true)
        refreshHome()
    }

    // ----- settings -----
    fun changeTheme(v: String) { theme = v; prefs.theme = v }
    fun setWifi(v: Boolean) { wifiOnly = v; prefs.wifiOnly = v; if (login != null && prefs.watched(login!!).isNotEmpty()) BuildWatchWorker.schedule(ctx, v) }
    fun setAuto(v: Boolean) { autoDownload = v; prefs.autoDownload = v }
    fun setRefresh(v: Int) { refreshSeconds = v.coerceIn(5, 60); prefs.refreshSeconds = refreshSeconds }
    fun setThreshold(v: Int) { commitThresholdMiB = v.coerceIn(1, 100); prefs.commitThresholdMiB = commitThresholdMiB }
    fun changeDefaultBranch(v: String) { defaultBranch = v; prefs.defaultBranch = v }

    fun clearCache() {
        val l = login ?: return
        paths().cache(l).deleteRecursively(); paths().cache(l)
        Intents.exportDir(ctx).deleteRecursively()
        message = "Cache cleared"
    }

    // ----- repos -----
    fun loadRepos(reset: Boolean) = op {
        if (reset) { reposPage = 0 }
        val p = api().listRepos(reposPage + 1)
        if (reset) repos.clear()
        repos.addAll(p.items); reposPage = p.page; reposHasNext = p.hasNext; reposLoaded = true
    }

    fun filteredRepos(): List<Repo> {
        val q = repoQuery.trim()
        val all = (repos + imported).distinctBy { it.fullName.lowercase() }
        val l = if (q.isEmpty()) all else all.filter { it.fullName.contains(q, true) || (it.description ?: "").contains(q, true) }
        return l.sortedByDescending { it.fullName in pinned }
    }

    fun rememberRepo(r: Repo) {
        val l = login ?: return
        imported.removeAll { it.fullName.equals(r.fullName,true) }; imported.add(r)
        prefs.setImported(l, prefs.imported(l) + r.fullName)
        pinned = pinned + r.fullName; prefs.setPinned(l,pinned)
    }
    fun createRepo(name: String, desc: String, privateRepo: Boolean, readme: Boolean, workflow: Boolean) = op {
        require(!workflow || readme) { "Initialize README to add a workflow" }
        val a = api(); val r = StudioApi(a).create(name.trim(),desc,privateRepo,readme)
        rememberRepo(r); message = "Created ${r.fullName}"
        if (workflow) {
            Uploader(a).commitFile(r.fullName,r.defaultBranch,".github/workflows/devhub-build.yml",BytesSource("devhub-build.yml",WorkflowStudio.yaml("Android / Gradle").toByteArray()),"Add DevHub workflow",false)
            message = "Created ${r.fullName} with Android workflow"
        }
        openRepo(r.fullName)
    }
    fun importRepo(input: String) = op { val r = api().getRepo(repoFromInput(input)); rememberRepo(r); message = "Added ${r.fullName}"; openRepo(r.fullName) }
    fun togglePin(full: String) {
        val l = login ?: return
        pinned = if (full in pinned) pinned - full else pinned + full
        prefs.setPinned(l, pinned)
        refreshHome()
    }

    // ----- home / builds -----
    fun refreshHome() = op {
        val a = api(); val out = ArrayList<Pair<String, Run>>(); var failed = 0
        for (r in pinned) {
            try { a.listRuns(r, perPage = 5).items.forEach { out += r to it } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { failed++; AppLog.log("home $r: ${errText(e)}") }
        }
        if (failed < pinned.size || pinned.isEmpty()) {
            homeRuns.clear(); homeRuns.addAll(out.sortedByDescending { it.second.createdAt ?: "" }); homeUpdated = nowText()
        }
        homeNote = if (failed > 0) "$failed repo(s) could not be refreshed; showing last known data (updated $homeUpdated)." else null
    }

    // ----- downloads -----
    fun loadHistory() {
        val l = login ?: return
        history.clear(); history.addAll(HistoryStore(paths().history(l)).load().sortedByDescending { it.savedAt })
    }

    fun deleteDownload(e: HistoryEntry) = op { pipeline().delete(e); loadHistory(); message = "Deleted local copy" }

    // ----- navigation -----
    fun openRepo(full: String) { repoSession = RepoSession(this, full); stack.add(Screen.RepoDetail(full)) }
    fun openRun(repo: String, id: Long) { runSession?.stop(); runSession = RunSession(this, repo, id); stack.add(Screen.RunDetail(repo, id)) }
    fun openLog(repo: String, jobId: Long, title: String) { logSession = LogSession(this, repo, jobId, title); stack.add(Screen.LogView(repo, jobId, title)) }
    fun pop() {
        if (stack.isEmpty()) return
        val s = stack.removeAt(stack.lastIndex)
        if (s is Screen.RunDetail) runSession?.stop()
    }

    fun watch(repo: String, runId: Long) {
        val l = login ?: return
        prefs.setWatched(l, prefs.watched(l) + "$repo#$runId")
        BuildWatchWorker.schedule(ctx, wifiOnly)
        message = "Watching in background. Checks run about every 15 minutes (Android decides the exact time)."
    }

    override fun onCleared() { runSession?.stop() }
}
