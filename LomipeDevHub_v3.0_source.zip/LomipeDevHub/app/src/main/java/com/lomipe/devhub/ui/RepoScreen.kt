package com.lomipe.devhub.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lomipe.devhub.core.UploadPolicy

@Composable
fun RepoScreen(vm: AppViewModel, s: RepoSession) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            TextButton(onClick = { vm.pop() }) { Text("‹ Back") }
            Text(s.repo, Modifier.weight(1f).padding(top = 12.dp), style = MaterialTheme.typography.titleMedium)
        }
        ScrollableTabRow(selectedTabIndex = s.subTab) {
            listOf("Upload", "Files", "Runs", "Releases", "Studio", "Manage", "History", "Team", "Tools").forEachIndexed { i, t -> Tab(selected = s.subTab == i, onClick = { s.subTab = i; if (i == 3) s.loadReleases() else if (i == 1 && s.entries.isEmpty()) s.loadDir("") }, text = { Text(t) }) }
        }
        when (s.subTab) {
            0 -> UploadTab(vm, s)
            1 -> FilesTab(s)
            2 -> RunsTab(vm, s)
            3 -> ReleasesTab(s, vm)
            4 -> StudioPanel(vm,s)
            5 -> ManagePanel(vm,s)
            6 -> HistoryPanel(vm,s)
            7 -> TeamPanel(vm,s)
            else -> AdvancedStudio(vm,s.repo)
        }
    }
}

@Composable
fun BranchPicker(s: RepoSession) {
    H("Branch: ${s.branch}")
    s.branches.take(30).forEach { b -> TextButton(onClick = { s.branch = b }) { Text((if (b == s.branch) "● " else "○ ") + b) } }
    Field("New branch name (created from selected branch)", s.newBranch, { s.newBranch = it })
    BtnO("Create branch", enabled = s.newBranch.isNotBlank()) { s.createBranch() }
}

@Composable
fun UploadTab(vm: AppViewModel, s: RepoSession) = Page {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> s.addFiles(uris) }
    Row {
        if (s.mode == "commit") Btn("Commit to branch") { s.mode = "commit" } else BtnO("Commit to branch") { s.mode = "commit" }
        if (s.mode == "release") Btn("Release asset") { s.mode = "release" } else BtnO("Release asset") { s.mode = "release" }
    }
    if (s.mode == "commit") {
        Note("Commits the file to the selected branch (Contents API, up to 100 MiB). A push can start your workflows.")
        BranchPicker(s)
        Field("Folder in repository (optional)", s.dir, { s.dir = it })
        Field("Commit message", s.message, { s.message = it })
    } else {
        Note("Uploads the file as a release asset. This does not change any branch and does not normally start push workflows. Existing assets are never deleted; a name clash gets a timestamp suffix.")
        Field("Release tag (created if missing)", s.releaseTag, { s.releaseTag = it })
        Row(Modifier.fillMaxWidth()) { Text("Create as draft if the release is new", Modifier.weight(1f)); Switch(checked = s.releaseDraft, onCheckedChange = { s.releaseDraft = it }) }
        Note("Creating a non-draft release also creates the tag on the selected branch (${s.branch}), which can trigger tag/release workflows.")
    }
    Row { Btn("Choose files") { picker.launch(arrayOf("*/*")) } }
    s.uploads.forEach { u ->
        Column(Modifier.padding(vertical = 6.dp)) {
            Text("${u.name}  (${if (u.size >= 0) "${u.size / 1024} KiB" else "size unknown"})")
            if (s.mode == "commit" && u.size > vm.commitThresholdMiB * 1024L * 1024L && u.size <= UploadPolicy.CONTENTS_API_MAX)
                Note("Larger than your ${vm.commitThresholdMiB} MiB warning threshold; GitHub may reject it. Release asset mode is the safer choice.")
            if (s.mode == "commit" && u.size > UploadPolicy.CONTENTS_API_MAX) Note("Over the 100 MiB Contents API limit. Use Release asset mode.")
            Note("State: ${u.state}" + if (u.state == "running" && u.size > 0) " · ${u.sent * 100 / u.size}%" else "")
            if (u.state == "running" && u.size > 0) LinearProgressIndicator(progress = { (u.sent.toFloat() / u.size).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            if (u.detail.isNotBlank()) Note(u.detail)
        }
    }
    Row {
        Btn("Upload", enabled = s.uploads.any { it.state in setOf("queued", "failed", "cancelled", "interrupted") } && vm.busy == 0) { s.startUploads() }
        BtnO("Cancel", enabled = vm.busy > 0) { s.cancelUploads() }
        BtnO("Clear list") { s.uploads.removeAll { it.state != "running" } }
    }
    if (s.detectStatus.isNotBlank()) {
        H("Build detection")
        Note(s.detectStatus)
        s.detectedRun?.let { r -> Row { Btn("Open run #${r.runNumber}") { vm.openRun(s.repo, r.id) } } }
        s.candidates.forEach { r -> BtnO("Run #${r.runNumber} ${r.name}") { vm.openRun(s.repo, r.id) } }
    }
    if (s.previous.isNotEmpty()) {
        H("Earlier uploads")
        s.previous.toList().forEach { r ->
            Row(Modifier.fillMaxWidth()) {
                Text("${r.name} · ${r.state}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                if (r.state != "done") TextButton(onClick = { s.retryPrevious(r) }) { Text("Retry") }
            }
        }
    }
    s.overwriteAsk?.let { Confirm("Replace existing file?", s.overwriteInfo, "Replace", { s.confirmOverwrite() }, { s.declineOverwrite() }) }
}

@Composable
fun FilesTab(s: RepoSession) = Page {
    val f = s.opened
    if (f != null) {
        if (f.path.isEmpty()) Field("New file path", s.newFilePath, { s.newFilePath = it }) else Text(f.path, style = MaterialTheme.typography.titleSmall)
        CodeField(s.editText, { s.editText = it; s.diff = null })
        if (f.path.isNotEmpty()) MoveFilePanel(s,f)
        Field("Commit message", s.editMessage, { s.editMessage = it })
        Row {
            if (f.path.isEmpty()) Btn("Create file", enabled = s.newFilePath.isNotBlank()) { s.createFile() }
            else { Btn("Commit change") { s.saveFile() }; BtnO("Preview diff") { s.previewDiff() }; BtnO("Delete") { s.confirmDelete = true } }
            BtnO("Close") { s.opened = null }
        }
        s.diff?.let { d ->
            Note("${com.lomipe.devhub.core.LineDiff.changed(d)} changed line(s)")
            d.filter { it.kind != ' ' }.take(200).forEach { Mono("${it.kind} ${it.text}") }
        }
        if (s.confirmDelete) Confirm("Delete ${f.path}?", "Commits a deletion to ${s.branch}.", "Delete", { s.deleteOpened() }, { s.confirmDelete = false })
        return@Page
    }
    Text("Branch ${s.branch} · /${s.filePath}", style = MaterialTheme.typography.titleSmall)
    Row { BtnO("Up", enabled = s.filePath.isNotEmpty()) { s.up() }; BtnO("Reload") { s.loadDir(s.filePath) }; BtnO("New file") { s.newFileEditor() } }
    Note("Open a file to edit or move it. Use Studio for offline project search and editing.")
    s.entries.forEach { e ->
        Text((if (e.type == "dir") "📁 " else "📄 ") + e.name + if (e.type == "file") "  ${e.size} B" else "",
            Modifier.fillMaxWidth().clickable { if (e.type == "dir") s.loadDir(e.path) else s.openFile(e.path) }.padding(vertical = 10.dp))
        HorizontalDivider()
    }
}

@Composable
fun RunsTab(vm: AppViewModel, s: RepoSession) = Page {
    H("Workflow filter")
    TextButton(onClick = { s.selectWorkflow(null) }) { Text((if (s.selectedWorkflowId == null) "● " else "○ ") + "All workflows") }
    s.workflows.forEach { w -> TextButton(onClick = { s.selectWorkflow(w.id) }) { Text((if (s.selectedWorkflowId == w.id) "● " else "○ ") + w.name + " (${w.path.substringAfterLast('/')})") } }
    var ask by remember { mutableStateOf(false) }
    H("Dispatch selected workflow on ${s.branch}")
    Note("Only works if the workflow has a workflow_dispatch trigger. GitHub returns no run id, so the app looks for the new run afterwards.")
    Field("Inputs (one key=value per line)", s.dispatchInputs, { s.dispatchInputs = it }, singleLine = false)
    Btn("Dispatch", enabled = s.selectedWorkflowId != null) { if (s.detectedRun != null) s.dispatchConfirm = true else ask = true }
    if (ask) Confirm("Start a build?", "Dispatch workflow on branch ${s.branch}.", "Dispatch", { ask = false; s.dispatch() }, { ask = false })
    if (s.dispatchConfirm) Confirm("A build was already detected", "Run #${s.detectedRun?.runNumber} was started by your last upload. Dispatching again starts a second build.", "Dispatch anyway", { s.dispatchConfirm = false; s.dispatch() }, { s.dispatchConfirm = false })
    H("Runs")
    s.runs.forEach { r ->
        Column(Modifier.fillMaxWidth().clickable { vm.openRun(s.repo, r.id) }.padding(vertical = 8.dp)) {
            Text(r.name); Text(runLine(r), style = MaterialTheme.typography.bodySmall)
        }
        HorizontalDivider()
    }
    Row { BtnO("Refresh") { s.loadRunsOp(true) }; if (s.runsHasNext) BtnO("More") { s.loadRunsOp(false) } }
}

@Composable
fun ReleasesTab(s: RepoSession, vm: AppViewModel) = Page {
    var notes by remember { mutableStateOf("") }; var releaseName by remember { mutableStateOf("") }; var tag by remember { mutableStateOf("") }; var ask by remember { mutableStateOf(false) }
    H("Release notes studio")
    Field("Release tag",tag,{tag=it}); Field("Release title",releaseName,{releaseName=it}); Field("Markdown changelog",notes,{notes=it},false)
    BtnO("Create release draft with notes",tag.isNotBlank()&&releaseName.isNotBlank()&&vm.busy==0&&s.branch.isNotBlank()){ask=true}
    if(ask)Confirm("Create draft release?","Creates a draft on GitHub. Review and publish it on GitHub when ready.","Create",{ask=false;vm.op{vm.api().createRelease(s.repo,tag,releaseName,notes,true,s.branch);vm.message="Release draft created";s.loadReleases()}},{ask=false})
    BtnO("Open GitHub releases"){Intents.openGitHubUrl(vm.ctx,"https://github.com/${s.repo}/releases")}
    HorizontalDivider()

    Field("New draft release tag", s.newReleaseTag, { s.newReleaseTag = it })
    Row { Btn("Create draft", enabled = s.newReleaseTag.isNotBlank()) { s.createDraftRelease() }; BtnO("Reload") { s.loadReleases() } }
    s.relInfo?.let { Note(it) }
    s.fetched?.let { f ->
        H("Downloaded ${f.artifact.name}")
        f.candidates.forEach { c ->
            Note("SHA-256 ${c.apk.sha256}"); c.info?.let { Note("${it.packageName} ${it.versionName} (code ${it.versionCode}). ${it.installedNote}") }
            c.warnings.forEach { Note("⚠ $it") }
            Btn("Save to Downloads", enabled = c.blocker == null) { s.saveAsset(c) }
        }
    }
    s.releases.forEach { r ->
        H("${r.tag}${if (r.draft) " (draft)" else ""}")
        r.assets.forEach { a ->
            Column(Modifier.padding(vertical = 4.dp)) {
                Text(a.name); Note("${a.size / 1024} KiB · ${a.state}")
                Row {
                    if (a.name.endsWith(".apk", true)) BtnO("Download APK") { s.fetchApkAsset(a) }
                    BtnO("Delete asset") { s.confirmAssetDelete = r to a }
                }
            }
        }
    }
    s.confirmAssetDelete?.let { (_, a) -> Confirm("Delete asset ${a.name}?", "This permanently removes the file from the release.", "Delete", { s.deleteAsset() }, { s.confirmAssetDelete = null }) }
}
