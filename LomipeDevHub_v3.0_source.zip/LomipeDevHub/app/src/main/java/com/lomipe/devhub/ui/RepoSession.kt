package com.lomipe.devhub.ui

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.lifecycle.viewModelScope
import com.lomipe.devhub.core.*
import com.lomipe.devhub.data.*
import kotlinx.coroutines.*
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID

class UploadItem(val id: String, val uri: Uri, val name: String, val size: Long) {
    var state by mutableStateOf("queued")       // queued | running | done | failed | cancelled | needs_confirm | interrupted
    var sent by mutableStateOf(0L)
    var detail by mutableStateOf("")
}

private class SafSource(private val vm: AppViewModel, private val uri: Uri, override val name: String, override val size: Long) : UploadSource {
    override fun open(): InputStream = vm.ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open $name")
}

class RepoSession(private val vm: AppViewModel, val repo: String) {
    private val scope get() = vm.viewModelScope
    var subTab by mutableStateOf(0)
    var info by mutableStateOf<Repo?>(null)

    // branches
    val branches = mutableStateListOf<String>()
    var branch by mutableStateOf("")
    var newBranch by mutableStateOf("")

    // upload
    var dir by mutableStateOf("")
    var message by mutableStateOf("Upload from Lomipe DevHub")
    var mode by mutableStateOf("commit")            // commit | release
    var releaseTag by mutableStateOf("lomipe-uploads")
    var releaseDraft by mutableStateOf(false)
    val uploads = mutableStateListOf<UploadItem>()
    var overwriteAsk by mutableStateOf<UploadItem?>(null)
    var overwriteInfo by mutableStateOf("")
    var detectStatus by mutableStateOf("")
    var detectedRun by mutableStateOf<Run?>(null)
    val candidates = mutableStateListOf<Run>()
    private var queue: Job? = null
    private val store = UploadQueueStore(vm.paths().uploads(vm.login!!))
    val previous = mutableStateListOf<UploadRecord>()

    // files
    var filePath by mutableStateOf("")
    val entries = mutableStateListOf<ContentEntry>()
    var opened by mutableStateOf<FileContent?>(null)
    var editText by mutableStateOf("")
    var editMessage by mutableStateOf("")
    var diff by mutableStateOf<List<LineDiff.Line>?>(null)
    var confirmDelete by mutableStateOf(false)
    var newFilePath by mutableStateOf("")

    // runs
    val workflows = mutableStateListOf<Workflow>()
    var selectedWorkflowId by mutableStateOf<Long?>(null)
    val runs = mutableStateListOf<Run>()
    var runsHasNext by mutableStateOf(false)
    private var runsPage = 0
    var dispatchInputs by mutableStateOf("")
    var dispatchConfirm by mutableStateOf(false)

    // releases
    val releases = mutableStateListOf<Release>()
    var fetched by mutableStateOf<Fetched?>(null)
    var relInfo by mutableStateOf<String?>(null)
    var newReleaseTag by mutableStateOf("")
    var confirmAssetDelete by mutableStateOf<Pair<Release, Asset>?>(null)

    init {
        previous.addAll(store.load().filter { it.repo == repo }.takeLast(10))
        vm.op {
            val a = vm.api()
            info = a.getRepo(repo)
            var p = 1
            while (p <= 5) { val pg = a.listBranches(repo, p); branches.addAll(pg.items.map { it.name }); if (!pg.hasNext) break; p++ }
            branch = listOf(vm.defaultBranch, info!!.defaultBranch).firstOrNull { it.isNotBlank() && it in branches } ?: branches.firstOrNull() ?: info!!.defaultBranch
            workflows.addAll(a.listWorkflows(repo))
            val saved = vm.prefs.repoPref(vm.login!!, repo, "workflow")?.toLongOrNull()
            selectedWorkflowId = saved?.takeIf { id -> workflows.any { it.id == id } }
            loadRuns(true)
        }
    }

    fun selectWorkflow(id: Long?) {
        selectedWorkflowId = id
        vm.prefs.setRepoPref(vm.login!!, repo, "workflow", id?.toString())
        loadRunsOp(true)
    }

    fun createBranch() = vm.op {
        val a = vm.api(); val name = newBranch.trim()
        a.createBranch(repo, name, a.branchHeadSha(repo, branch))
        branches.add(name); branch = name; newBranch = ""
        vm.message = "Branch '$name' created from the previous branch head."
    }

    // ---------- upload ----------
    fun addFiles(uris: List<Uri>) {
        val cr = vm.ctx.contentResolver
        for (u in uris) {
            try { cr.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            var name = "file"; var size = -1L
            cr.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
            uploads.add(UploadItem(UUID.randomUUID().toString(), u, name.replace('/', '_'), size))
        }
    }

    fun retryPrevious(r: UploadRecord) { addFiles(listOf(Uri.parse(r.uri))); previous.remove(r) }

    private fun persist() {
        val keep = store.load().filter { it.repo != repo }
        store.save(keep + uploads.map { UploadRecord(it.id, repo, branch, dir, mode, it.uri.toString(), it.name, it.size, message, it.state, it.detail) })
    }

    fun startUploads() {
        if (queue?.isActive == true) return
        val todo = uploads.filter { it.state in setOf("queued", "failed", "cancelled", "interrupted") }
        if (todo.isEmpty()) return
        queue = scope.launch {
            vm.busy++
            try { for (item in todo) { if (!isActive) break; runOne(item, false) } }
            catch (e: CancellationException) { uploads.filter { it.state == "running" }.forEach { it.state = "cancelled"; it.detail = "Cancelled" }; persist(); throw e }
            finally { vm.busy-- }
        }
    }

    fun cancelUploads() { queue?.cancel() }

    fun confirmOverwrite() { val i = overwriteAsk ?: return; overwriteAsk = null; scope.launch { vm.busy++; try { runOne(i, true) } finally { vm.busy-- } } }
    fun declineOverwrite() { overwriteAsk?.let { it.state = "cancelled"; it.detail = "Not overwritten" }; overwriteAsk = null; persist() }

    private suspend fun source(item: UploadItem): UploadSource {
        if (item.size >= 0) return SafSource(vm, item.uri, item.name, item.size)
        // size unknown: copy to app-private storage first so the length is exact
        val tmp = File(vm.paths().cache(vm.login!!), "upload-${item.id}")
        withContext(Dispatchers.IO) { vm.ctx.contentResolver.openInputStream(item.uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } } }
        return FileSource(tmp, item.name)
    }

    private suspend fun runOne(item: UploadItem, allow: Boolean) {
        item.state = "running"; item.sent = 0; item.detail = ""; persist()
        try {
            val a = vm.api(); val up = Uploader(a); val src = source(item)
            if (mode == "commit") {
                val path = up.targetPath(dir, item.name)
                val res = up.commitFile(repo, branch, path, src, message, allow) { item.sent = it }
                item.state = "done"
                item.detail = "Committed ${res.commitSha.take(7)} to $branch as $path. Blob SHA " + (if (res.blobVerified) "verified." else "could NOT be verified.") + " SHA-256 ${res.sha256.take(16)}…"
                persist()
                detect(res.commitSha)
            } else {
                var rel = a.releaseByTag(repo, releaseTag.trim())
                if (rel == null) rel = a.createRelease(repo, releaseTag.trim(), releaseTag.trim(), "Files uploaded from Lomipe DevHub", releaseDraft, branch)
                val r = up.uploadReleaseAssetChecked(repo, rel, src, item.name, onProgress = { item.sent = it })
                item.state = "done"
                item.detail = "Uploaded to release '${releaseTag.trim()}' as ${r.finalName}. Size " + (if (r.sizeVerified) "verified" else "MISMATCH") +
                    when (r.digestVerified) { true -> ", SHA-256 verified."; false -> ", SHA-256 MISMATCH."; null -> ", no remote digest supplied." } +
                    " A release upload is not a branch commit and may not trigger a push build."
                persist()
            }
        } catch (e: OverwriteRequired) {
            item.state = "needs_confirm"; item.detail = "Exists on $branch"
            overwriteInfo = "Repository: $repo\nBranch: $branch\nPath: ${e.path}\nCurrent size on GitHub: ${e.existingSize} bytes\nNew size: ${item.size} bytes\n\nThis replaces the file with a new commit (history keeps the old version)."
            overwriteAsk = item
            persist()
        } catch (e: CancellationException) { throw e }
        catch (e: ApiException) {
            item.state = "failed"
            item.detail = errText(e) + when (e.kind) {
                ErrorKind.TOO_LARGE, ErrorKind.VALIDATION -> " Mode was NOT changed automatically. Consider uploading as a release asset instead."
                ErrorKind.CONFLICT -> " The branch changed meanwhile; retry."
                else -> ""
            }
            persist()
        } catch (e: Exception) { item.state = "failed"; item.detail = errText(e); persist() }
    }

    private suspend fun detect(sha: String) {
        detectedRun = null; candidates.clear()
        detectStatus = "Waiting for GitHub to start a push-triggered run for commit ${sha.take(7)}…"
        var wait = 3000L
        repeat(14) {
            val found = vm.api().listRuns(repo, headSha = sha, event = "push", perPage = 30).items
            when (val m = RunCorrelator.correlate(found, sha, "push", branch, selectedWorkflowId)) {
                is RunCorrelator.Match.Single -> { detectedRun = m.run; detectStatus = "Build detected: run #${m.run.runNumber} (${m.run.status})."; return }
                is RunCorrelator.Match.Ambiguous -> { candidates.addAll(m.candidates); detectStatus = "Several runs match this commit. Choose the right one."; return }
                RunCorrelator.Match.None -> {}
            }
            delay(wait); wait = (wait * 14 / 10).coerceAtMost(10_000)
        }
        detectStatus = "No workflow run appeared for this commit. The repository may not build on push; use the Runs tab to dispatch one."
    }

    // ---------- files ----------
    fun loadDir(path: String) = vm.op { val l = vm.api().listContents(repo, path, branch); entries.clear(); entries.addAll(l); filePath = path }
    fun up() { if (filePath.isNotEmpty()) loadDir(filePath.substringBeforeLast('/', "")) }

    fun openFile(path: String) = vm.op {
        val f = vm.api().readTextFile(repo, path, branch)
        if (f.text == null) { vm.message = "File is binary, invalid UTF-8, or larger than 1 MB; not opened in the editor."; return@op }
        opened = f; editText = f.text; editMessage = "Update ${path.substringAfterLast('/')}"; diff = null; confirmDelete = false
    }

    fun moveOpened(to: String) = vm.op {
        val f = opened ?: return@op
        StudioApi(vm.api()).move(repo,branch,f.path,to,f.sha)
        opened = null; loadDir(filePath); vm.message = "Moved ${f.path} to $to"
    }
    fun previewDiff() { diff = LineDiff.diff(opened?.text ?: "", editText) }

    fun saveFile() = vm.op {
        val f = opened ?: return@op
        Uploader(vm.api()).commitFile(repo, branch, f.path, BytesSource(f.path.substringAfterLast('/'), editText.toByteArray()), editMessage, true, expectedSha = f.sha)
        vm.message = "Committed ${f.path} to $branch"
        opened = null; loadDir(filePath)
    }

    fun createFile() = vm.op {
        val p = newFilePath.trim()
        Uploader(vm.api()).commitFile(repo, branch, p, BytesSource(p.substringAfterLast('/'), editText.toByteArray()), editMessage.ifBlank { "Add $p" }, false)
        vm.message = "Created $p on $branch"; newFilePath = ""; opened = null; loadDir(filePath)
    }

    fun newFileEditor() { opened = FileContent("", "", 0, ""); editText = ""; editMessage = ""; newFilePath = if (filePath.isEmpty()) "" else "$filePath/" }

    fun deleteOpened() = vm.op {
        val f = opened ?: return@op
        vm.api().deleteFile(repo, f.path, branch, f.sha, editMessage.ifBlank { "Delete ${f.path}" })
        vm.message = "Deleted ${f.path}"; opened = null; confirmDelete = false; loadDir(filePath)
    }

    // ---------- runs ----------
    fun loadRunsOp(reset: Boolean) = loadRuns(reset)
    private fun loadRuns(reset: Boolean) = vm.op {
        if (reset) runsPage = 0
        val p = vm.api().listRuns(repo, workflowId = selectedWorkflowId, page = runsPage + 1)
        if (reset) runs.clear()
        runs.addAll(p.items); runsPage = p.page; runsHasNext = p.hasNext
    }

    fun dispatch() = vm.op {
        val wf = selectedWorkflowId ?: throw IllegalStateException("Select a workflow first")
        val inputs = dispatchInputs.lines().map { it.trim() }.filter { it.contains('=') }.associate { it.substringBefore('=').trim() to it.substringAfter('=').trim() }
        val t0 = Instant.now().minusSeconds(5).truncatedTo(ChronoUnit.SECONDS).toString()
        vm.api().dispatch(repo, wf, branch, inputs)
        vm.message = "Dispatch accepted (GitHub returns no run id). Looking for the new run…"
        var wait = 3000L
        repeat(10) {
            val found = vm.api().listRuns(repo, workflowId = wf, event = "workflow_dispatch", perPage = 10).items
            when (val m = RunCorrelator.correlateDispatch(found, branch, wf, t0)) {
                is RunCorrelator.Match.Single -> { detectedRun = m.run; vm.openRun(repo, m.run.id); return@op }
                is RunCorrelator.Match.Ambiguous -> { candidates.clear(); candidates.addAll(m.candidates); detectStatus = "Several dispatched runs match; choose one in the Upload tab."; return@op }
                RunCorrelator.Match.None -> {}
            }
            delay(wait); wait = (wait * 14 / 10).coerceAtMost(10_000)
        }
        vm.message = "No new run found yet. Check the Runs list in a moment."
    }

    // ---------- releases ----------
    fun loadReleases() = vm.op { releases.clear(); releases.addAll(vm.api().listReleases(repo).items) }

    fun createDraftRelease() = vm.op {
        val t = newReleaseTag.trim(); require(t.isNotEmpty()) { "Enter a tag" }
        vm.api().createRelease(repo, t, t, "", true, branch); newReleaseTag = ""; vm.message = "Draft release '$t' created"; loadReleases()
    }

    fun fetchApkAsset(asset: Asset) = vm.op {
        fetched?.let { vm.pipeline().discard(it) }
        val l = vm.login!!
        fetched = vm.pipeline().fetchAsset(vm.ctx, l, vm.api(), repo, asset) { d, _ -> relInfo = "Downloading ${asset.name}: ${d / 1024} KiB" }
        relInfo = null
    }

    fun saveAsset(c: Candidate) = vm.op {
        val f = fetched ?: return@op
        val e = vm.pipeline().save(f, c); vm.loadHistory(); relInfo = "Saved ${e.apkName}. Open the Downloads tab to install."
    }

    fun deleteAsset() = vm.op {
        val (_, a) = confirmAssetDelete ?: return@op
        vm.api().deleteAsset(repo, a.id); confirmAssetDelete = null; loadReleases()
    }
}
