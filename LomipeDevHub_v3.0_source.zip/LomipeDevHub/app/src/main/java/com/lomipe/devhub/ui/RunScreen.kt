package com.lomipe.devhub.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun RunScreen(vm: AppViewModel, s: RunSession, onRequestNotifications: () -> Unit) {
    val ctx = LocalContext.current
    var ask by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            TextButton(onClick = { vm.pop() }) { Text("‹ Back") }
            Text(s.repo, Modifier.weight(1f).padding(top = 12.dp), style = MaterialTheme.typography.titleMedium)
        }
        Page {
            val r = s.run
            if (r == null) Note("Loading run…") else {
                Text(r.name, style = MaterialTheme.typography.titleLarge)
                Text("Run #${r.runNumber} · attempt ${r.attempt} · ${r.event} · ${r.branch ?: "?"} · ${r.headSha.take(7)}")
                Text("Status: ${statusLabel(r.status, r.conclusion)}", style = MaterialTheme.typography.titleMedium)
                r.commitMessage?.let { Note(it.lines().first()) }
                if (r.attempt > 1) Row { (1..r.attempt).forEach { n -> if (n == (s.attempt ?: r.attempt)) Btn("#$n") { s.selectAttempt(n) } else BtnO("#$n") { s.selectAttempt(n) } } }
            }
            s.lastUpdated?.let { Note("Last updated $it" + if (s.offline) " (offline)" else "") }
            s.info?.let { Note(it) }
            Row {
                BtnO("Refresh") { s.refreshNow() }
                BtnO("Open on GitHub", enabled = r != null) { r?.let { Intents.openGitHubUrl(ctx, it.htmlUrl) } }
            }
            Row {
                BtnO("Cancel run", enabled = r?.isActive == true) { ask = "cancel" }
                BtnO("Re-run all", enabled = r != null && !r.isActive) { ask = "rerun" }
                BtnO("Re-run failed", enabled = r?.isFailure == true) { ask = "failed" }
            }
            Row { BtnO("Watch in background", enabled = r?.isActive == true) { onRequestNotifications(); vm.watch(s.repo, s.runId) } }
            s.firstError?.let { H("First error"); Mono(it); H("Suggested checks"); Note(com.lomipe.devhub.core.ProjectStudio.advice(it)); BtnO("Copy error") { Intents.copy(vm.ctx,"Build error",it) } }
            H("Jobs")
            if (s.jobs.isEmpty()) Note("No jobs reported yet (queued or waiting for a runner).")
            s.jobs.forEach { j ->
                Text("${stepSymbol(j.status, j.conclusion)} ${j.name} · ${statusLabel(j.status, j.conclusion)}", style = MaterialTheme.typography.titleSmall)
                if (j.steps.isNotEmpty()) Note("${j.completedSteps} of ${j.steps.size} steps completed")
                j.steps.forEach { st -> Text("   ${stepSymbol(st.status, st.conclusion)} ${st.number}. ${st.name}", style = MaterialTheme.typography.bodySmall) }
                if (j.status == "completed") BtnO("View log") { vm.openLog(s.repo, j.id, j.name) } else Note("Log available after this job finishes.")
            }
            if (r != null && !r.isActive) {
                H("Artifacts")
                if (s.artifacts.isEmpty()) Note("This run produced no artifacts.")
                s.artifacts.forEach { a ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Text(a.name); Note("${a.sizeBytes / 1024} KiB" + if (a.expired) " · EXPIRED" else (a.expiresAt?.let { " · expires $it" } ?: ""))
                        Row { Btn("Download APK", enabled = !a.expired && vm.busy == 0) { s.downloadArtifact(a) } }
                    }
                }
                s.progress?.let { Note(it); BtnO("Cancel download") { s.cancelDownload() } }
                s.fetched?.let { f ->
                    H("Found ${f.candidates.size} APK file(s)")
                    f.manifestName?.let { Note("Checksum file: $it") }
                    f.candidates.forEach { c ->
                        Text(c.apk.file.name, style = MaterialTheme.typography.titleSmall)
                        Note("${c.apk.file.length() / 1024} KiB · SHA-256 ${c.apk.sha256}")
                        Note(when (c.apk.manifestMatches) { true -> "✓ Matches the checksum file."; false -> "✗ DOES NOT match the checksum file."; null -> "No checksum entry; locally calculated only." })
                        c.info?.let { Note("${it.packageName} ${it.versionName ?: ""} (code ${it.versionCode}, minSdk ${it.minSdk})"); Note("Signer SHA-256: ${it.signerSha256.firstOrNull() ?: "unavailable"}"); Note(it.installedNote) }
                        c.warnings.forEach { w -> Note("⚠ $w") }
                        c.blocker?.let { Note("⛔ $it") }
                        Btn("Save to Downloads", enabled = c.blocker == null) { s.save(c) }
                    }
                }
                BtnO("Download run logs (ZIP)") { s.downloadRunLogs() }
            }
        }
    }
    when (ask) {
        "cancel" -> Confirm("Cancel this run?", "The running jobs will be stopped.", "Cancel run", { ask = null; s.cancelRun() }, { ask = null })
        "rerun" -> Confirm("Re-run all jobs?", "Starts a new attempt of this run.", "Re-run", { ask = null; s.rerunAll() }, { ask = null })
        "failed" -> Confirm("Re-run failed jobs?", "Only failed jobs (and dependents) run again.", "Re-run", { ask = null; s.rerunFailed() }, { ask = null })
    }
}

@Composable
fun LogScreen(vm: AppViewModel, s: LogSession) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row { TextButton(onClick = { vm.pop() }) { Text("‹ Back") }; Text(s.title, Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleMedium) }
        if (s.state.isNotBlank()) Note(s.state)
        if (s.truncated) Note("Log is very large; showing the last part only.")
        Field("Search in log", s.query, { s.query = it })
        Row {
            BtnO("Copy", enabled = s.text.isNotEmpty()) { Intents.copy(ctx, "log", s.text) }
            BtnO("Export", enabled = s.text.isNotEmpty()) { Intents.share(ctx, s.export(), "text/plain") }
        }
        val lines = if (s.query.isBlank()) s.text.lines().mapIndexed { i, l -> (i + 1) to l } else s.matches()
        LazyColumn(Modifier.fillMaxSize()) { items(lines) { (n, l) -> Mono("$n  $l") } }
    }
}
