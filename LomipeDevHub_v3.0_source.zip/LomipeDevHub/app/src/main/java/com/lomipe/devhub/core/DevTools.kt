package com.lomipe.devhub.core

import java.io.File
import java.net.URI
import java.net.HttpURLConnection
import java.util.UUID
import java.util.zip.ZipFile
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.security.SecureRandom

object DevTools {
    fun atomicWrite(file: File, text: String) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, ".${file.name}.${UUID.randomUUID()}.tmp")
        try { tmp.writeText(text); require(tmp.renameTo(file)) { "Could not save file" } } finally { tmp.delete() }
    }
    fun escapeHtml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
    data class Widget(val type: String, val label: String)
    fun design(title: String, color: String, widgets: List<Widget>): String {
        require(color.matches(Regex("#[0-9a-fA-F]{6}"))) { "Use #RRGGBB" }
        val content = widgets.joinToString("\n") { w -> val t = escapeHtml(w.label); when(w.type) {
            "Heading" -> "<h2>$t</h2>"; "Text" -> "<p>$t</p>"; "Button" -> "<button type=\"button\">$t</button>"; "Input" -> "<label>$t<input placeholder=\"$t\"></label>"; else -> error("Unknown widget")
        } }
        return """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(title)}</title><style>body{font:16px system-ui;margin:0;background:#f3f5f8;color:#202735}main{max-width:640px;margin:auto;padding:24px}h1{color:$color}button,input{font:inherit;padding:12px;border-radius:8px;box-sizing:border-box}button{background:$color;color:white;border:0;width:100%;margin:8px 0}input{display:block;width:100%;border:1px solid #aaa;margin:8px 0}label{display:block}</style></head><body><main><h1>${escapeHtml(title)}</h1>$content</main></body></html>"""
    }
    fun composeSource(title: String, widgets: List<Widget>): String {
        fun literal(s: String) = Json.quote(s).replace("$", "\\$")
        val body = widgets.mapIndexed { i,w -> val t=literal(w.label); when(w.type){"Heading"->"Text($t, style = MaterialTheme.typography.headlineSmall)"; "Text"->"Text($t)"; "Button"->"Button(onClick = { onAction($i) }) { Text($t) }"; "Input"->"var input$i by remember { mutableStateOf(\"\") }; OutlinedTextField(value = input$i, onValueChange = { input$i = it }, label = { Text($t) })";else->error("Unknown widget")}}.joinToString("\n        ")
        return """import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun GeneratedScreen(onAction: (Int) -> Unit = {}) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(${literal(title)}, style = MaterialTheme.typography.headlineMedium)
        $body
    }
}
"""
    }
    fun diagnostics(root: File): List<String> {
        val scan = ProjectStudio.scan(root)
        val findings = scan.warnings.map { "WARN: $it" }.toMutableList()
        for (p in scan.files.take(500)) {
            if (p.file.length() > 512_000 || p.path.substringAfterLast('.').lowercase() !in setOf("kt","java","js","ts","py","gd","json","xml","yaml","yml","gradle","kts","properties","html","css")) continue
            val text = runCatching { p.file.readText() }.getOrNull() ?: continue
            if (Redactor.redact(text) != text || Regex("-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----").containsMatchIn(text)) findings += "WARN: Possible credential in ${p.path}; inspect locally."
            if (p.path.endsWith(".json") && runCatching { Json.parse(text) }.isFailure) findings += "ERROR: Invalid JSON: ${p.path}"
            if (text.lineSequence().any { it.startsWith("<<<<<<< ") }) findings += "WARN: Possible merge conflict: ${p.path}"
            if (p.path.endsWith("AndroidManifest.xml")) {
                Regex("android:name\\s*=\\s*\"(android\\.permission\\.[^\"]+)\"").findAll(text).map { it.groupValues[1] }.distinct().forEach { findings += "INFO: Manifest reference $it (${p.path})" }
                if (text.contains("android:debuggable=\"true\"")) findings += "WARN: Explicit debuggable=true in ${p.path}"
            }
        }
        return listOf("Frameworks: ${scan.frameworks.joinToString().ifBlank { "Unknown" }}", "Files: ${scan.files.size}; bytes: ${scan.files.sumOf { it.file.length() }}", "Static checks only; no compilation or security certification.") + findings.ifEmpty { listOf("No matching warnings found.") }
    }
    fun assets(root: File) = ProjectStudio.scan(root).files.filter { it.path.substringAfterLast('.').lowercase() in setOf("png","jpg","jpeg","webp","svg","gif","ogg","wav","mp3","mp4","ttf","otf","glb","gltf") }.sortedByDescending { it.file.length() }
    fun archiveReport(file: File): List<String> = ZipFile(file).use { z ->
        val entries = z.entries().asSequence().filter { !it.isDirectory }.take(20_001).toList()
        require(entries.size <= 20_000) { "Archive too many entries" }
        listOf("Archive entries: ${entries.size}", "Compressed file bytes: ${file.length()}", "Declared uncompressed bytes: ${entries.sumOf { it.size.coerceAtLeast(0) }}", "Largest entries (declared size):") + entries.sortedByDescending { it.size }.take(30).map { "${it.size} B · ${it.name}" }
    }
    fun regexMatches(pattern: String, text: String): List<String> {
        require(pattern.length <= 100 && text.length <= 2000) { "Regex input limit: 100 pattern / 2000 text characters" }
        // Only literal characters and simple character classes, no nested quantifiers or backtracking groups.
        require(pattern.none { it in "(){}+*?|\\" }) { "Use simple patterns or character classes (advanced regex not supported)" }
        return Regex(pattern).findAll(text).take(100).map { "${it.range.first}: ${it.value}" }.toList()
    }
    fun formatJson(text: String): String = Json.write(Json.parse(text))
}

data class DevTask(val id: String, val title: String, val status: String)
class TaskStore(private val file: File) {
    fun load(): List<DevTask> = if (!file.exists()) emptyList() else Json.parse(file.readText()).asList().mapNotNull { it.asObj() }.map { DevTask(it.s("id") ?: error("Missing task ID"),it.s("title") ?: "",it.s("status") ?: "To do") }
    fun save(tasks: List<DevTask>) { require(tasks.size <= 300); DevTools.atomicWrite(file,Json.write(tasks.map { mapOf("id" to it.id,"title" to it.title,"status" to it.status) })) }
}

object BackupCrypto {
    private val magic = "LDH3".toByteArray()
    private fun key(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password,salt,600_000,256)
        return try { SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,"AES") } finally { spec.clearPassword() }
    }
    fun encrypt(bytes: ByteArray, password: CharArray): ByteArray {
        require(password.size >= 12 && bytes.size <= 20*1024*1024) { "Use 12+ characters; maximum backup 20 MiB" }
        val random=SecureRandom(); val salt=ByteArray(16).also(random::nextBytes);val iv=ByteArray(12).also(random::nextBytes)
        val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key(password,salt),GCMParameterSpec(128,iv));c.updateAAD(magic)
        return magic+salt+iv+c.doFinal(bytes)
    }
    fun decrypt(bytes: ByteArray,password: CharArray): ByteArray {
        require(bytes.size in 48..(20*1024*1024+48) && bytes.copyOfRange(0,4).contentEquals(magic)) { "Not a DevHub encrypted backup" }
        val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(password,bytes.copyOfRange(4,20)),GCMParameterSpec(128,bytes.copyOfRange(20,32)));c.updateAAD(magic)
        return c.doFinal(bytes.copyOfRange(32,bytes.size))
    }
}

object ApiProbe {
    data class Result(val status: Int,val elapsedMs: Long,val body: String)
    fun request(url: String,method: String,body: String): Result {
        val uri=URI(url);require(uri.scheme=="https" && uri.host!=null && uri.userInfo==null && uri.fragment==null) { "Use an HTTPS URL without embedded credentials" }
        require(method in setOf("GET","HEAD","POST") && body.length<=100_000)
        val c=uri.toURL().openConnection() as HttpURLConnection
        val start=System.nanoTime()
        try { c.instanceFollowRedirects=false;c.connectTimeout=15000;c.readTimeout=15000;c.requestMethod=method;c.setRequestProperty("Accept","application/json, text/plain, */*")
            if(method=="POST"){ c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.outputStream.use { it.write(body.toByteArray()) } }
            val status=c.responseCode; val stream=if(status>=400)c.errorStream else c.inputStream
            val bytes=stream?.use { val buf=ByteArray(65536);var n=0;while(n<buf.size){val k=it.read(buf,n,buf.size-n);if(k<=0)break;n+=k};buf.copyOf(n) } ?: byteArrayOf()
            return Result(status,(System.nanoTime()-start)/1_000_000,Redactor.redact(bytes.toString(Charsets.UTF_8)))
        } finally { c.disconnect() }
    }
}
