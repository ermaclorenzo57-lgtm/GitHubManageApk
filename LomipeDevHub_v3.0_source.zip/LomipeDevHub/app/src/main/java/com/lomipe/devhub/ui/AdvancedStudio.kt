package com.lomipe.devhub.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.lomipe.devhub.core.*
import com.lomipe.devhub.data.ApkInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@Composable fun AdvancedStudio(vm: AppViewModel, repo: String? = null) {
    val account = vm.login ?: "local"
    key(account, repo) { AdvancedStudioContent(vm, account, repo) }
}

@Composable private fun AdvancedStudioContent(vm: AppViewModel, account: String, repo: String?) = Page {
    val home = remember(account,repo) { File(vm.paths().dir(account),"studio/${repo?.let { "repos/$it" } ?: "general"}").also { it.mkdirs() } }
    var tool by remember { mutableStateOf("") }
    H("DevHub Studio · 3.0")
    Note(repo ?: "Local tools work without a GitHub account. Repository tools are available inside each repo.")
    if(tool.isEmpty()) {
        val tools=listOf("Code workbench","UI designer","Test lab","API tester","Task board","Asset library","APK analyzer","Encrypted backup","AI handoff","Utilities","Build templates")
        tools.chunked(2).forEach { pair -> Row(Modifier.fillMaxWidth()) { pair.forEach { name -> OutlinedButton(onClick={tool=name},modifier=Modifier.weight(1f).padding(4.dp).heightIn(min=64.dp)){Text(name)} };if(pair.size==1)Spacer(Modifier.weight(1f)) } }
        Note("No AI requests, cloud builds, or uploads run automatically.")
    } else {
        TextButton(onClick={tool=""}) { Text("‹ Studio tools") }; H(tool)
        when(tool) {
            "Code workbench" -> Workbench(vm,home)
            "UI designer" -> Designer(vm,home)
            "Test lab" -> InspectProject(vm,home,false)
            "API tester" -> ApiTester(vm)
            "Task board" -> TasksPanel(vm,home)
            "Asset library" -> InspectProject(vm,home,true)
            "APK analyzer" -> ArchivePanel(vm)
            "Encrypted backup" -> BackupPanel(vm)
            "AI handoff" -> AiHandoff(vm)
            "Utilities" -> Utilities(vm)
            "Build templates" -> TemplatesPanel(vm)
        }
    }
}

@Composable private fun Workbench(vm:AppViewModel, home:File) {
    val draft=remember{File(home,"draft.txt")};val baseline=remember{File(home,"baseline.txt")}
    var code by remember{mutableStateOf(runCatching{draft.readText()}.getOrDefault(""))}
    var old by remember{mutableStateOf(runCatching{baseline.readText()}.getOrDefault(""))}
    var result by remember{mutableStateOf("")};var compare by remember{mutableStateOf(false)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri->if(uri!=null)vm.op{
        val t=withContext(Dispatchers.IO){vm.ctx.contentResolver.openInputStream(uri)!!.use{input->val buffer=java.io.ByteArrayOutputStream(); val chunk=ByteArray(8192); while(true){val n=input.read(chunk);if(n<0)break;require(buffer.size()+n<=1_000_000){"Text files up to 1 MB"};buffer.write(chunk,0,n)};val bytes=buffer.toByteArray();require(bytes.size<=1_000_000 && bytes.none{it==0.toByte()}){"Text files up to 1 MB"};Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString()}}
        old=t;code=t;withContext(Dispatchers.IO){DevTools.atomicWrite(baseline,t);DevTools.atomicWrite(draft,t)};result="Imported as local draft"
    }}
    val exporter=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){uri->if(uri!=null)vm.op{val content=code;withContext(Dispatchers.IO){vm.ctx.contentResolver.openOutputStream(uri,"wt")!!.use{it.write(content.toByteArray())}};result="Exported"}}
    LaunchedEffect(code){val snapshot=code;kotlinx.coroutines.delay(600);try{withContext(Dispatchers.IO){DevTools.atomicWrite(draft,snapshot)}}catch(e:kotlinx.coroutines.CancellationException){throw e}catch(e:Exception){vm.message=errText(e)}}
    Note("Local draft recovery, code highlighting, undo/redo, line references, comparison and export. Import replaces the current draft.")
    BtnO("Import text",vm.busy==0){picker.launch(arrayOf("*/*"))}
    CodeField(code){if(it.length<=1_000_000)code=it}
    var line by remember{mutableStateOf("1")};Field("Inspect line number",line,{line=it});Note(code.lineSequence().drop(((line.toIntOrNull()?:1)-1).coerceIn(0,1000000)).firstOrNull()?.take(500)?:"Line not found")
    Row{BtnO("Indent last line"){val i=code.lastIndexOf('\n')+1;code=code.substring(0,i)+"    "+code.substring(i)};BtnO("Save draft",vm.busy==0){vm.op{val t=code;withContext(Dispatchers.IO){DevTools.atomicWrite(draft,t)};result="Saved"}}}
    Row{BtnO("Compare baseline"){compare=!compare};BtnO("Export",vm.busy==0){exporter.launch("source.txt")}}
    if(compare){ val diff=remember(old,code){if(old.lineSequence().count()>500||code.lineSequence().count()>500)"Comparison limited to 500 lines per file" else LineDiff.diff(old,code,500).filter{it.kind!=' '}.take(100).joinToString("\n"){"${it.kind} ${it.text}"}};Mono(diff.ifEmpty{"No changes (or comparison limit exceeded)"}) }
    if(result.isNotEmpty())Note(result)
}

@Composable private fun Designer(vm:AppViewModel, home:File) {
    var title by remember{mutableStateOf("My application")};var color by remember{mutableStateOf("#3569A8")};var label by remember{mutableStateOf("")}
    val widgets=remember{mutableStateListOf<DevTools.Widget>()};var html by remember{mutableStateOf("")};var compose by remember{mutableStateOf("")};var output by remember{mutableStateOf("HTML")}
    val exporter=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")){uri->if(uri!=null)vm.op{val content=if(output=="HTML")html else compose;withContext(Dispatchers.IO){vm.ctx.contentResolver.openOutputStream(uri,"wt")!!.use{it.write(content.toByteArray())}};vm.message="Exported generated source"}}
    Field("Screen title",title,{title=it});Field("HTML accent (#RRGGBB)",color,{color=it});Field("Widget text",label,{label=it})
    listOf("Heading","Text","Button","Input").chunked(2).forEach{pair->Row{pair.forEach{kind->BtnO("+ $kind",label.isNotBlank()&&widgets.size<50){widgets.add(DevTools.Widget(kind,label));label=""}}}}
    widgets.toList().forEachIndexed{i,w->Row(Modifier.fillMaxWidth()){Text("${w.type}: ${w.label}",Modifier.weight(1f));TextButton(onClick={if(i>0){val a=widgets[i-1];widgets[i-1]=widgets[i];widgets[i]=a}},enabled=i>0){Text("↑")};TextButton(onClick={widgets.removeAt(i)}){Text("Remove")}}}
    Btn("Generate preview and source"){vm.op{html=DevTools.design(title,color,widgets.toList());compose=DevTools.composeSource(title,widgets.toList());val h=html;val c=compose;withContext(Dispatchers.IO){DevTools.atomicWrite(File(home,"design.html"),h);DevTools.atomicWrite(File(home,"GeneratedScreen.kt"),c)}}}
    if(html.isNotEmpty()){
        AndroidView(factory={ctx->android.webkit.WebView(ctx).apply{settings.javaScriptEnabled=false;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.blockNetworkLoads=true;webViewClient=object:android.webkit.WebViewClient(){override fun shouldOverrideUrlLoading(view:android.webkit.WebView?,request:android.webkit.WebResourceRequest?)=true}}},update={it.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)},modifier=Modifier.fillMaxWidth().height(320.dp))
        Row{BtnO("HTML"){output="HTML"};BtnO("Compose"){output="Compose"}};Mono((if(output=="HTML")html else compose).take(12000));Row{BtnO("Copy"){Intents.copy(vm.ctx,"Generated source",if(output=="HTML")html else compose)};BtnO("Export"){exporter.launch(if(output=="HTML")"index.html" else "GeneratedScreen.kt")}}
    }
    Note("Ordered visual components with live static HTML preview. Compose output is a starter screen; button actions and navigation are wired by the developer.")
}

private suspend fun copySelected(vm:AppViewModel,uri:android.net.Uri,dest:File,limit:Long){withContext(Dispatchers.IO){vm.ctx.contentResolver.openInputStream(uri)!!.use{input->dest.outputStream().use{out->val b=ByteArray(65536);var total=0L;while(true){val n=input.read(b);if(n<0)break;total+=n;require(total<=limit){"Selected file exceeds size limit"};out.write(b,0,n)}}}}}

@Composable private fun InspectProject(vm:AppViewModel,home:File,assetMode:Boolean){
    var report by remember{mutableStateOf("")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)vm.op{val zip=File(vm.ctx.cacheDir,"${UUID.randomUUID()}.zip");val root=File(home,"scan-${UUID.randomUUID()}");try{copySelected(vm,uri,zip,100L*1024*1024);report=withContext(Dispatchers.IO){ProjectStudio.extract(zip,root);if(assetMode){val assets=DevTools.assets(root);"${assets.size} assets · ${assets.sumOf{it.file.length()}} bytes\n"+assets.take(200).joinToString("\n"){"${it.file.length()} B · ${it.path}"}}else DevTools.diagnostics(root).joinToString("\n")}}finally{withContext(Dispatchers.IO){zip.delete();root.deleteRecursively()}}}}
    Note(if(assetMode)"Import a project ZIP to list image, audio, video, font and model assets, largest first." else "Static source checks: missing files, malformed JSON, possible secrets, merge conflicts and manifest references. Does not prove the application builds or is secure.")
    Btn("Scan project ZIP",vm.busy==0){picker.launch(arrayOf("application/zip","application/octet-stream","application/x-zip-compressed"))};if(report.isNotEmpty()){Mono(report);BtnO("Copy report"){Intents.copy(vm.ctx,"Studio report",report)}}
    if(!assetMode){H("Remote emulator test template");Note("Install from repository Studio > Workflow builder, then dispatch manually. Runner minutes may be billed. Requires Android Gradle project and instrumentation tests.");BtnO("Copy test workflow"){Intents.copy(vm.ctx,"Test workflow",WorkflowStudio.yaml("Android test lab"))}}
}

@Composable private fun ApiTester(vm:AppViewModel){
    var url by remember{mutableStateOf("")};var method by remember{mutableStateOf("GET")};var body by remember{mutableStateOf("")};var result by remember{mutableStateOf("")};var confirm by remember{mutableStateOf(false)}
    Note("HTTPS requests only. No GitHub token, credentials, or cookies are attached by DevHub. Redirects are not followed. Test only endpoints you are authorized to use.")
    Field("HTTPS endpoint",url,{url=it});Row{listOf("GET","HEAD","POST").forEach{m->TextButton(onClick={method=m}){Text(if(method==m)"● $m" else m)}}};if(method=="POST")Field("JSON request body",body,{body=it},false)
    fun send(){val u=url;val m=method;val b=body;vm.op{val r=withContext(Dispatchers.IO){ApiProbe.request(u,m,b)};result="HTTP ${r.status} · ${r.elapsedMs} ms\n${r.body}"}}
    Btn("Send $method",url.isNotBlank()&&vm.busy==0){if(method=="POST")confirm=true else send()};if(confirm)Confirm("Send POST?","This may change data on the server.","Send",{confirm=false;send()},{confirm=false});if(result.isNotEmpty()){Mono(result);BtnO("Copy response"){Intents.copy(vm.ctx,"Response",result)}}
}

@Composable private fun TasksPanel(vm:AppViewModel,home:File){
    val store=remember{TaskStore(File(home,"tasks.json"))};val tasks=remember{mutableStateListOf<DevTask>()};var title by remember{mutableStateOf("")};var loaded by remember{mutableStateOf(false)};var remove by remember{mutableStateOf<DevTask?>(null)}
    LaunchedEffect(Unit){try{tasks.addAll(withContext(Dispatchers.IO){store.load()});loaded=true}catch(e:Exception){vm.message=errText(e)}}
    fun update(next:List<DevTask>){vm.op{withContext(Dispatchers.IO){store.save(next)};tasks.clear();tasks.addAll(next)}}
    Field("New task",title,{title=it});Btn("Add task",loaded&&title.isNotBlank()&&tasks.size<300&&vm.busy==0){update(tasks.toList()+DevTask(UUID.randomUUID().toString(),title.trim(),"To do"));title=""}
    listOf("To do","In progress","Done").forEach{status->H(status);tasks.filter{it.status==status}.forEach{t->Text(t.title);Row{BtnO("Next",vm.busy==0&&status!="Done"){update(tasks.map{if(it.id==t.id)it.copy(status=if(status=="To do")"In progress" else "Done")else it})};BtnO("Back",vm.busy==0&&status!="To do"){update(tasks.map{if(it.id==t.id)it.copy(status=if(status=="Done")"In progress" else "To do")else it})};BtnO("Remove",vm.busy==0){remove=t}}}}
    remove?.let{t->Confirm("Remove task?",t.title,"Remove",{remove=null;update(tasks.filter{it.id!=t.id})},{remove=null})};Note("Saved locally; no team synchronization.")
}

@Composable private fun ArchivePanel(vm:AppViewModel){
    var report by remember{mutableStateOf("")};val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)vm.op{val f=File(vm.ctx.cacheDir,"${UUID.randomUUID()}.apk");try{copySelected(vm,uri,f,250L*1024*1024);report=withContext(Dispatchers.IO){val a=ApkInspector.inspect(vm.ctx,f);(a?.let{"Package: ${it.packageName}\nVersion: ${it.versionName} (${it.versionCode})\nMin SDK: ${it.minSdk}\nSigners: ${it.signerSha256.joinToString()}\n${it.installedNote}\n"}?:"APK package metadata not available.\n")+DevTools.archiveReport(f).joinToString("\n")}}finally{withContext(Dispatchers.IO){f.delete()}}}}
    Btn("Inspect APK / AAB / ZIP",vm.busy==0){picker.launch(arrayOf("*/*"))};Note("Read-only archive report. Does not install, optimize, re-sign or certify safety.");if(report.isNotEmpty()){Mono(report);BtnO("Copy report"){Intents.copy(vm.ctx,"Archive report",report)}}
}

@Composable private fun BackupPanel(vm:AppViewModel){
    var password by remember{mutableStateOf("")};var input by remember{mutableStateOf<File?>(null)};var decrypt by remember{mutableStateOf(false)};var output by remember{mutableStateOf<File?>(null)}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)vm.op{val f=File(vm.ctx.cacheDir,"${UUID.randomUUID()}.backup");try{copySelected(vm,uri,f,20L*1024*1024+48);input?.delete();output?.delete();input=f;output=null}catch(e:Exception){f.delete();throw e}}}
    val exporter=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){uri->if(uri!=null)vm.op{val f=output?:error("Process file first");withContext(Dispatchers.IO){vm.ctx.contentResolver.openOutputStream(uri,"wt")!!.use{out->f.inputStream().use{it.copyTo(out)}}};vm.message="Exported backup";output=null;f.delete()}}
    DisposableEffect(Unit){onDispose{input?.delete();output?.delete()}}
    Note("Encrypt or decrypt a selected project ZIP (up to 20 MiB) using AES-256-GCM and PBKDF2. No password recovery. Decrypted content is not automatically extracted or uploaded.")
    Row{BtnO("Encrypt"){decrypt=false;output?.delete();output=null};BtnO("Decrypt"){decrypt=true;output?.delete();output=null}};Note(if(decrypt)"Decrypt mode" else "Encrypt mode")
    BtnO("Choose file",vm.busy==0){picker.launch(arrayOf("*/*"))};Note(if(input!=null)"Input selected" else "No input selected")
    OutlinedTextField(value=password,onValueChange={password=it},label={Text("Backup password (12+ characters)")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
    Btn("Process",input!=null&&password.length>=12&&vm.busy==0){val f=input!!;val p=password.toCharArray();val d=decrypt;password="";vm.op{try{val out=withContext(Dispatchers.IO){val bytes=if(d)BackupCrypto.decrypt(f.readBytes(),p)else BackupCrypto.encrypt(f.readBytes(),p);File(vm.ctx.cacheDir,"${UUID.randomUUID()}.out").also{it.writeBytes(bytes)}};output?.delete();output=out;vm.message="File processed; choose Export"}finally{p.fill('\u0000')}}}
    if(output!=null)Btn("Export",vm.busy==0){exporter.launch(if(decrypt)"restored.zip" else "project.ldh3")}
}

@Composable private fun AiHandoff(vm:AppViewModel){
    var problem by remember{mutableStateOf("")};var log by remember{mutableStateOf("")};var prompt by remember{mutableStateOf("")}
    Note("Offline prompt builder for your chosen AI assistant. No API provider connected; nothing is sent automatically. Remove private source, keys, and personal information before sharing.")
    Field("Goal / problem",problem,{problem=it},false);Field("Relevant log or code",log,{log=it},false);Btn("Prepare review prompt",problem.isNotBlank()){prompt=Redactor.redact("Help review this development task. Explain the root cause, propose a minimal patch, list verification tests, and do not change unrelated behavior.\nGoal: $problem\nContext:\n${log.take(30000)}")};if(prompt.isNotEmpty()){Mono(prompt);BtnO("Copy for review"){Intents.copy(vm.ctx,"AI prompt",prompt)}}
}

@Composable private fun Utilities(vm:AppViewModel){
    var input by remember{mutableStateOf("")};var pattern by remember{mutableStateOf("")};var result by remember{mutableStateOf("")}
    Field("Text / JSON",input,{if(it.length<=100000)input=it},false);Field("Simple regex pattern",pattern,{pattern=it});Row{BtnO("Compact JSON",vm.busy==0){vm.op{result=DevTools.formatJson(input)}};BtnO("Find matches",pattern.isNotEmpty()&&vm.busy==0){vm.op{result=DevTools.regexMatches(pattern,input).joinToString("\n").ifEmpty{"No matches"}}}};if(result.isNotEmpty()){Mono(result);BtnO("Copy"){Intents.copy(vm.ctx,"Utility result",result)}}
}

@Composable private fun TemplatesPanel(vm:AppViewModel){
    var kind by remember{mutableStateOf("Android / Gradle")};WorkflowStudio.kinds.forEach{k->TextButton(onClick={kind=k}){Text(if(kind==k)"● $k" else k)}}
    Note("Review before committing. Godot requires a trusted self-hosted runner labeled godot with the correct SDK and export templates; Electron requires npm dist script; AAB signing is project-specific. No automatic billing or dispatch.")
    Mono(WorkflowStudio.yaml(kind));BtnO("Copy YAML"){Intents.copy(vm.ctx,"Workflow",WorkflowStudio.yaml(kind))}
}
