package com.lomipe.devhub.core

object WorkflowStudio {
    val kinds = listOf("Android / Gradle", "Flutter", "React Native", "HTML", "Python", "Android test lab", "Android AAB", "Godot (configured runner)", "Electron")
    fun yaml(kind: String): String {
        val steps = when(kind) {
            "Android / Gradle" -> """      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
      - run: bash ./gradlew testDebugUnitTest assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: android-apk
          path: '**/build/outputs/apk/**/*.apk'
          if-no-files-found: error"""
            "Flutter" -> """      - uses: subosito/flutter-action@v2
        with:
          channel: stable
      - run: flutter pub get
      - run: flutter build apk --debug
      - uses: actions/upload-artifact@v4
        with:
          name: flutter-apk
          path: build/app/outputs/flutter-apk/*.apk
          if-no-files-found: error"""
            "React Native" -> """      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - run: npm ci
      - run: cd android && bash ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: react-native-apk
          path: android/app/build/outputs/apk/**/*.apk
          if-no-files-found: error"""
            "HTML" -> """      - run: test -f index.html
      - uses: actions/upload-artifact@v4
        with:
          name: website
          path: |
            **/*.html
            **/*.css
            **/*.js
            **/*.png
            **/*.svg
            **/*.jpg"""
            "Python" -> """      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: python -m compileall -q .
      - uses: actions/upload-artifact@v4
        with:
          name: python-source
          path: '**/*.py'"""
            "Android test lab" -> """      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
      - run: bash ./gradlew testDebugUnitTest lintDebug
      - name: Enable KVM permissions
        run: |
          echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
          sudo udevadm control --reload-rules
          sudo udevadm trigger --name-match=kvm
      - uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 34
          arch: x86_64
          script: bash ./gradlew connectedDebugAndroidTest
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: test-reports
          path: |
            **/build/reports/**
            **/build/outputs/androidTest-results/**"""
            "Android AAB" -> """      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
      - run: bash ./gradlew bundleRelease
      - uses: actions/upload-artifact@v4
        with:
          name: android-bundle
          path: '**/build/outputs/bundle/**/*.aab'
          if-no-files-found: error"""
            "Godot (configured runner)" -> """      - run: |
          test -f project.godot
          test -f export_presets.cfg
          command -v godot
          mkdir -p dist
          godot --headless --path . --export-debug Android dist/game.apk
      - uses: actions/upload-artifact@v4
        with:
          name: godot-apk
          path: dist/game.apk
          if-no-files-found: error"""
            "Electron" -> """      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - run: npm ci
      - run: npm run dist
      - uses: actions/upload-artifact@v4
        with:
          name: desktop-dist
          path: dist/
          if-no-files-found: error"""
            else -> error("This framework needs a project-specific workflow")
        }
        val runner = if (kind == "Godot (configured runner)") "[self-hosted, godot]" else "ubuntu-latest"
        return "name: DevHub build\non:\n  workflow_dispatch:\npermissions:\n  contents: read\njobs:\n  build:\n    runs-on: $runner\n    timeout-minutes: 45\n    steps:\n      - uses: actions/checkout@v4\n$steps\n"
    }
}
