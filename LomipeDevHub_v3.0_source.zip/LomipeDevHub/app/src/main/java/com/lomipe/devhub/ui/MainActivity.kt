package com.lomipe.devhub.ui

import android.Manifest
import android.app.KeyguardManager
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var unlocked by mutableStateOf(false)
    private val unlock = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result -> unlocked = result.resultCode == RESULT_OK }
    private fun requestUnlock() {
        val manager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        @Suppress("DEPRECATION") val intent = manager.createConfirmDeviceCredentialIntent("Unlock DevHub", "Confirm your device credential")
        if (intent != null) unlock.launch(intent)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        unlocked = !vm.prefs.deviceLock
        setContent {
            LomipeTheme(vm.theme) {
                if (!unlocked) { Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) { Text("DevHub locked", style = MaterialTheme.typography.headlineMedium); Button(onClick = { requestUnlock() }) { Text("Unlock with device credential") } } } else AppRoot(vm, onRequestNotifications = {
                    if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                })
            }
        }
    }

    override fun onStart() { super.onStart(); vm.foreground = true }
    override fun onStop() { super.onStop(); vm.foreground = false }
}
