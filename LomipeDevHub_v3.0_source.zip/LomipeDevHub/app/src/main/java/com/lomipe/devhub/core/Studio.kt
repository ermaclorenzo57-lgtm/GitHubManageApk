package com.lomipe.devhub.core

import java.io.File
import java.net.URI
import java.util.Base64
import java.util.zip.ZipFile
import java.util.zip.CRC32
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun repoFromInput(input: String): String {
    val value = input.trim()
    if (!value.contains("://")) return checkRepo(value.removeSuffix(".git"))
    val uri = URI(value)
    require(uri.scheme == "https" && uri.host.equals("github.com", true) && uri.userInfo == null && uri.port == -1 && uri.query == null && uri.fragment == null) { "Use a GitHub HTTPS repository URL" }
    return checkRepo(uri.path.trim('/').removeSuffix(".git"))
}

class StudioApi(private val api: GitHubApi) {
    private val base get() = api.http.policy.apiBase
    private fun repo(r: String) = "/repos/${checkRepo(r)}"
    private suspend fun call(method: String, path: String, data: Any? = null): Any? {
        val bytes = data?.let { Json.write(it).toByteArray() }
        val response = api.http.send(method, base + path, contentType = bytes?.let { "application/json" }, length = bytes?.size?.toLong() ?: -1, body = bytes?.let { b -> { o, _ -> o.write(b) } })
        return if (response.body.isEmpty()) null else response.json()
    }
    private suspend fun obj(method: String, path: String, data: Any? = null) = call(method, path, data).asObj() ?: error("Expected GitHub object")
    private suspend fun list(path: String) = call("GET", path).asList().mapNotNull { it.asObj() }
    private fun name(n: String): String { require(n.matches(Regex("[A-Za-z0-9_.-]{1,100}")) && n !in setOf(".", "..")) { "Invalid repository name" }; return n }
    suspend fun create(n: String, description: String, privateRepo: Boolean, readme: Boolean): Repo = Parse.repo(obj("POST", "/user/repos", mapOf("name" to name(n), "description" to description, "private" to privateRepo, "auto_init" to readme)))
    suspend fun details(r: String) = obj("GET", repo(r))
    suspend fun update(r: String, n: String, description: String, privateRepo: Boolean, archived: Boolean): Repo = Parse.repo(obj("PATCH", repo(r), mapOf("name" to name(n), "description" to description, "private" to privateRepo, "archived" to archived)))
    suspend fun fork(r: String) = Parse.repo(obj("POST", repo(r) + "/forks", mapOf("default_branch_only" to true)))
    suspend fun rate() = obj("GET", "/rate_limit").o("resources")?.o("core") ?: emptyMap()
    suspend fun commits(r: String, branch: String) = list(repo(r) + "/commits?per_page=50&sha=${encodeSegment(branch)}")
    suspend fun commitDetails(r: String, sha: String): JObj { require(sha.matches(Regex("[0-9a-fA-F]{7,40}"))); return obj("GET", repo(r) + "/commits/$sha") }
    suspend fun issues(r: String) = list(repo(r) + "/issues?state=open&per_page=50").filter { it["pull_request"] == null }
    suspend fun createIssue(r: String, title: String, body: String) = obj("POST", repo(r) + "/issues", mapOf("title" to title, "body" to body))
    suspend fun closeIssue(r: String, number: Long) = obj("PATCH", repo(r) + "/issues/$number", mapOf("state" to "closed"))
    suspend fun pulls(r: String) = list(repo(r) + "/pulls?state=open&per_page=50")
    suspend fun createPull(r: String, title: String, head: String, target: String, body: String) = obj("POST", repo(r) + "/pulls", mapOf("title" to title,"head" to head,"base" to target,"body" to body))
    suspend fun merge(r: String, number: Long, sha: String): JObj = obj("PUT", repo(r) + "/pulls/$number/merge", mapOf("sha" to sha, "merge_method" to "merge"))
    suspend fun secretNames(r: String) = obj("GET", repo(r) + "/actions/secrets?per_page=100").a("secrets").mapNotNull { it.s("name") }
    suspend fun downloadZip(r: String, branch: String, dest: File) = withContext(Dispatchers.IO) {
        val part = File(dest.path + ".part"); dest.parentFile?.mkdirs()
        try {
            api.http.download(base + repo(r) + "/zipball/${encodeSegment(branch)}") { input, _, check ->
                part.outputStream().use { out -> val buf = ByteArray(65536); var total = 0L; while (true) { check(); val n = input.read(buf); if(n < 0) break; total += n; require(total <= 100L*1024*1024) { "ZIP exceeds 100 MiB" }; out.write(buf,0,n) } }
            }
            require(part.renameTo(dest)) { "Could not save ZIP" }
        } finally { part.delete() }
    }
    private suspend fun gitCommit(r: String, sha: String) = obj("GET", repo(r) + "/git/commits/$sha")
    private suspend fun publish(r: String, branch: String, parent: String, tree: String, message: String): String {
        val c = obj("POST", repo(r) + "/git/commits", mapOf("message" to message, "tree" to tree, "parents" to listOf(parent))).s("sha")!!
        obj("PATCH", repo(r) + "/git/refs/heads/${encodeRepoPath(branch)}", mapOf("sha" to c, "force" to false))
        return c
    }
    suspend fun restore(r: String, branch: String, oldSha: String): String {
        require(oldSha.matches(Regex("[0-9a-fA-F]{40}")))
        val parent = api.branchHeadSha(r, branch)
        val tree = gitCommit(r, oldSha).o("tree")?.s("sha") ?: error("Missing tree")
        return publish(r, branch, parent, tree, "Restore tree from ${oldSha.take(12)}")
    }
    suspend fun uploadProject(r: String, branch: String, files: List<ProjectFile>, message: String, progress: (String) -> Unit): String {
        require(files.isNotEmpty() && files.size <= 500 && files.sumOf { it.file.length() } <= 100L*1024*1024 && files.all { it.file.length() <= 10L*1024*1024 }) { "Project exceeds upload limits" }
        val parent = api.branchHeadSha(r, branch)
        val tree = gitCommit(r, parent).o("tree")?.s("sha") ?: error("Missing base tree")
        val entries = files.mapIndexed { index, f ->
            val bytes = withContext(Dispatchers.IO) { f.file.readBytes() }
            val sha = obj("POST", repo(r) + "/git/blobs", mapOf("content" to Base64.getEncoder().encodeToString(bytes), "encoding" to "base64")).s("sha")!!
            progress("Uploaded ${index+1}/${files.size} blobs")
            mapOf("path" to validateRepoPath(f.path), "mode" to if(f.path.substringAfterLast('/') == "gradlew") "100755" else "100644", "type" to "blob", "sha" to sha)
        }
        val newTree = obj("POST", repo(r) + "/git/trees", mapOf("base_tree" to tree, "tree" to entries)).s("sha")!!
        return publish(r, branch, parent, newTree, message)
    }
    suspend fun move(r: String, branch: String, from: String, to: String, expectedSha: String): String {
        val old = validateRepoPath(from); val dest = validateRepoPath(to); require(old != dest)
        val parent = api.branchHeadSha(r, branch)
        val tree = gitCommit(r,parent).o("tree")?.s("sha") ?: error("Missing tree")
        val listing = obj("GET", repo(r) + "/git/trees/$tree?recursive=1")
        require(!listing.b("truncated")) { "Tree too large for safe move" }
        val rows = listing.a("tree"); val src = rows.firstOrNull { it.s("path") == old && it.s("type") == "blob" } ?: error("File not found")
        require(src.s("sha") == expectedSha && src.s("mode") in setOf("100644","100755")) { "Source changed or unsupported file type" }
        require(rows.none { it.s("path") == dest || it.s("path")?.startsWith("$dest/") == true }) { "Destination exists" }
        val changes = listOf(mapOf("path" to old,"mode" to src.s("mode"),"type" to "blob","sha" to null),mapOf("path" to dest,"mode" to src.s("mode"),"type" to "blob","sha" to expectedSha))
        val newTree = obj("POST", repo(r)+"/git/trees",mapOf("base_tree" to tree,"tree" to changes)).s("sha")!!
        return publish(r,branch,parent,newTree,"Move $old to $dest")
    }
}

data class ProjectFile(val path: String, val file: File)
data class ProjectScan(val files: List<ProjectFile>, val frameworks: List<String>, val warnings: List<String>)
object ProjectStudio {
    private val excluded = setOf(".git", ".gradle", "node_modules", ".idea", ".dart_tool", "build", "__MACOSX", ".godot")
    private fun sensitive(p: String): Boolean { val n = p.substringAfterLast('/').lowercase(); return n == ".env" || n.startsWith(".env.") || n in setOf("local.properties", "key.properties", "credentials.json", "id_rsa", "id_ed25519") || listOf(".jks", ".keystore", ".p12", ".pem", ".key").any { n.endsWith(it) } }
    fun extract(zip: File, target: File): ProjectScan {
        require(!target.exists()) { "Use a fresh workspace" }; target.mkdirs()
        try {
            ZipFile(zip).use { z ->
                val entries = z.entries().toList(); require(entries.size <= 5000) { "Too many ZIP entries" }
                val seen = HashSet<String>(); entries.forEach { e -> ZipSafe.validateName(e.name); require(seen.add(e.name.lowercase())) { "Duplicate archive path" } }
                val candidates = entries.filter { !it.isDirectory && it.name.split('/').none { s -> s in excluded } && !sensitive(it.name) }
                require(candidates.size <= 500) { "Project limit: 500 files" }
                val root = candidates.firstOrNull()?.name?.substringBefore('/')?.takeIf { p -> candidates.all { it.name.startsWith("$p/") } }
                var total = 0L
                candidates.forEach { e ->
                    val path = validateRepoPath(if(root == null) e.name else e.name.removePrefix("$root/")); val f = File(target,path)
                    require(f.canonicalPath.startsWith(target.canonicalPath + File.separator)); require(e.size in 0..(10L*1024*1024)) { "File exceeds 10 MiB: $path" }
                    f.parentFile.mkdirs(); require(!f.exists())
                    z.getInputStream(e).use { input -> f.outputStream().use { out -> val buf = ByteArray(65536); var written=0L; val crc=CRC32(); while(true){ val n=input.read(buf); if(n<0)break; written+=n; total+=n; require(written<=10L*1024*1024 && total<=100L*1024*1024) { "Project exceeds extraction limit" }; crc.update(buf,0,n); out.write(buf,0,n) }; require(crc.value==e.crc) { "Corrupt ZIP entry" }; require(written==e.size) { "Incomplete ZIP entry" } } }
                }
            }
            return scan(target)
        } catch(e: Throwable) { target.deleteRecursively(); throw e }
    }
    fun scan(root: File): ProjectScan {
        val files = root.walkTopDown().filter { it.isFile }.map { ProjectFile(it.relativeTo(root).invariantSeparatorsPath,it) }.filter { !sensitive(it.path) && it.path.split('/').none { p -> p in excluded } }.sortedBy { it.path }.toList()
        val names = files.map { it.path }; fun has(s: String) = names.any { it == s || it.endsWith("/$s") }
        val frameworks = buildList { if(has("gradlew") || has("build.gradle") || has("build.gradle.kts")) add("Android / Gradle"); if(has("pubspec.yaml")) add("Flutter"); if(has("project.godot")) add("Godot"); if(files.any { it.path.endsWith("package.json") && it.file.length()<1000000 && it.file.readText().contains("react-native") }) add("React Native"); if(has("index.html")) add("HTML"); if(names.any { it.endsWith(".py") }) add("Python"); if(has("ProjectVersion.txt")) add("Unity") }
        val warnings = buildList { if(files.isEmpty()) add("No source files found"); if("Android / Gradle" in frameworks && !has("gradlew")) add("Missing Gradle wrapper script"); if("Android / Gradle" in frameworks && !has("gradle-wrapper.jar")) add("Missing Gradle wrapper JAR"); if("Godot" in frameworks && !has("export_presets.cfg")) add("Missing Godot export presets"); if(frameworks.isEmpty()) add("Unknown project framework"); if(files.size>500 || files.sumOf { it.file.length() }>100L*1024*1024 || files.any { it.file.length()>10L*1024*1024 }) add("Project exceeds upload limits") }
        return ProjectScan(files,frameworks,warnings)
    }
    fun advice(log: String): String = when {
        log.contains("Unresolved reference",true) -> "Check imports, spelling and dependency versions for the unresolved symbol."
        log.contains("SDK location not found",true) -> "Install/configure the Android SDK on the runner. Do not commit local.properties."
        log.contains("Could not resolve",true) -> "Check dependency coordinates, repositories and runner connectivity."
        log.contains("OutOfMemory",true) -> "Review Gradle JVM memory and reduce parallel tasks."
        log.contains("Permission denied",true) -> "Check runner permissions and executable bits."
        log.contains("Manifest merger failed",true) -> "Inspect conflicting manifest attributes or SDK requirements."
        else -> "Inspect the first error and failed step; no known pattern was matched."
    }
}
