package com.lomipe.devhub

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.assertIsDisplayed
import com.lomipe.devhub.ui.MainActivity
import org.junit.Rule
import org.junit.Test

class StudioSmokeTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()
    @Test fun localStudioOpensWithoutGitHub() {
        rule.onNodeWithText("Studio", substring = false).performClick()
        rule.onNodeWithText("DevHub Studio · 3.0").assertIsDisplayed()
        rule.onNodeWithText("UI designer").performClick()
        rule.onNodeWithText("Generate preview and source").assertIsDisplayed()
    }
}
